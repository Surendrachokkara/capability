# Shop Manager — Required + Nice-to-Have Plan

Scope: implement everything in **Necessary & Required** plus **Nice to Have**. Showcase-only items are excluded for now.

## Necessary & Required
These prevent data loss, corruption, or operational blockers as the shop grows.

1. **Relational schema for products, customers, orders, payments, expenses, suppliers**
   - Replace `shop_data` JSON blobs with normalised tables and foreign keys.
   - Products: SKU/name/category/stock/price/cost/discontinued.
   - Customers: name/phone/address/outstanding balance.
   - Orders: customer reference, type, status, total, timestamps.
   - Order items: product reference, quantity, unit price, discount.
   - Payments: order reference, amount, mode, date.
   - Expenses: category, amount, date, note.
   - Suppliers: name, phone, address, credit notes.
   - Reason: JSONB rewrites entire arrays on every edit; normalised rows are smaller, faster, and enforce integrity.

2. **Migrate existing JSONB data into the new tables**
   - One-off migration that parses current `shop_data` rows and inserts into new tables.
   - Reason: owners already have data in the app; we cannot start fresh.

3. **Row-level locking / atomic updates**
   - Wrap order creation + stock deduction + payment recording in a transaction.
   - Reason: prevents overselling and lost payments when two staff act at once.

4. **Database-level constraints and uniqueness**
   - Unique phone per customer per shop, unique SKU per shop, check constraints on prices/quantities/statuses, foreign keys from orders to customers and order_items to products.
   - Reason: app-layer validation can be bypassed by bugs or future clients.

5. **Input validation with Zod on every form and server function**
   - Orders, products, customers, expenses, suppliers, staff invites.
   - Reason: stops malformed data before it reaches the DB or corrupts reports.

6. **Server-side pagination, search, and filters**
   - Stock, Orders, Customers, Finance lists fetch pages from the backend.
   - Reason: the whole dataset currently loads into browser memory; this breaks at scale.

7. **Offline write support with sync queue**
   - Queue mutations locally when offline, then sync with conflict handling when back online.
   - Reason: current offline mode is read-only; a shop with flaky internet cannot record sales.

8. **Secure role model via `user_roles` table**
   - Add `public.user_roles` and a `has_role()` security definer function; use it in RLS policies.
   - Reason: `shop_members` is shop-specific, not a reusable role system, and complicates privilege checks.

9. **Invoice / bill numbering series**
   - Per-shop atomic counter (e.g. `INV-0001`) used on receipts and tax invoices.
   - Reason: every shop needs consistent, non-colliding bill numbers.

10. **Printable receipts and tax invoices**
    - Clean print/PDF layout with shop details, itemised lines, GST fields, totals, payment mode.
    - Reason: the current UI is not a usable customer receipt.

## Nice to Have
These improve day-to-day efficiency and polish once the core is solid.

1. **Complete Hindi and Telugu translations**
   - Cover every label, form, error message, and report; English fallback until done.

2. **Bulk import from CSV/Excel**
   - Upload products or customers with a preview-and-confirm step before saving.

3. **Customer payment reminders**
   - List outstanding invoices and generate a WhatsApp/SMS message draft for each.

4. **Profit and loss report per product / per customer**
   - Show actual profit after discounts and expenses for products and customers.

5. **Low-stock alerts on the dashboard**
   - Highlight items below a reorder level with a quick reorder link.

6. **Reorder point and preferred supplier on products**
   - Tie a product to a supplier and suggest reorders when stock is low.

7. **Keyboard shortcuts**
   - Quick navigation between sections and save/cancel in modals.

8. **Improved product photos**
   - Compress and resize camera uploads, lazy-load thumbnails, offline placeholder.

9. **Date-range filtering on reports**
   - Filter sales, expenses, and profit by custom ranges.

10. **Dashboard summary customisation**
    - Let the user pin the metrics they care about.

## Proposed Phases

**Phase 1 — Foundation (required 1–2)**
Design and migrate to relational tables; update RLS policies so owners and joined staff can still access their data.

**Phase 2 — Integrity (required 3–5)**
Add transactions, DB constraints, and Zod validation across all forms and server functions.

**Phase 3 — Scale (required 6)**
Move list views to server-side pagination, search, and filtering.

**Phase 4 — Operations (required 7–10)**
Offline sync queue, `user_roles` table, atomic invoice numbering, and printable receipts.

**Phase 5 — Polish (nice-to-have 1–10)**
Translations, CSV import, reminders, reports, low-stock alerts, keyboard shortcuts, photo handling, and dashboard customisation.

## First milestone
Start with **Phase 1** (relational schema + data migration). It unlocks every later required item and makes the app truly reliable.

If you approve this plan, I will begin with the schema design and migration.