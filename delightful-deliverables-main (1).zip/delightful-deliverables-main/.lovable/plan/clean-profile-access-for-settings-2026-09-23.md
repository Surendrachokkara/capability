# Clean profile access for Settings

## What will change
- Replace the three mobile header controls (language, Settings, and sign out) with one profile button.
- Use the saved business logo inside the profile button when available, with a person icon fallback.
- Open the complete mobile Settings menu when the profile button is tapped.
- Move language selection into Settings under Preferences.
- Keep sign out inside Your account, so removing it from the header does not remove access.
- Keep every current Settings section and action intact.

## Desktop and mobile
- Mobile: one compact profile button in the header; Settings opens on the organized all-sections list.
- Desktop: preserve the fixed navigation panel, while making the same language and sign-out actions available inside Settings.

## Technical details
- Pass language and sign-out actions into the existing Settings window rather than duplicating account logic.
- Make the initial loading brand state hydration-safe so a cached logo does not differ between server and browser rendering.
- Verify the profile button, language change, sign out placement, light/dark themes, and Settings navigation on phone and desktop.
