# Why the app is slow to open — findings and fixes

## What I checked
The startup path from the moment the page opens: the sign-in check, working out which shop you belong to, the data download, and what has to load before anything appears on screen.

**Where the weight actually is.** Your whole shop's data is tiny: 8 products, 11 orders, 12 order lines, 6 customers, 6 expenses — about 6 KB in total, a fraction of a single photo. So the delay is not your data. It is the app's own program file (roughly 5,400 lines in one piece, plus React and the libraries) that the phone must download and start up, followed by four to six separate trips to the server before the first screen appears.

**How much bigger apps do it.** Amazon, Swiggy or a banking app hold far more data than your shop, yet open in a second or two, because they never load it all:
- The page arrives already drawn from their servers, so you see the layout instantly instead of a blank screen.
- Only the code for the screen you're on is sent; the rest arrives when you tap into it.
- Only the first handful of records is fetched — more load as you scroll.
- Your phone keeps its own copy of what you saw last time and shows it first, refreshing quietly behind it.

We currently do the opposite on the first three, which is the whole difference. The steps below put us on the same pattern.

## Everything slowing down the opening

1. **Nothing is shown until all data arrives.** The screen stayed blank through the whole chain below. (Already improved earlier today: your last saved copy now appears immediately and refreshes behind the scenes.)
2. **The sign-in check asks the server every time.** On each open the app contacts the login service to confirm who you are, instead of reading the session already stored on the device. That is one full round trip before anything else can start.
3. **Two more trips to work out which shop you belong to.** A write, then a read, on the team table — on first open, before any shop data is requested.
4. **The data download happens in two waves, not one.** First products, customers, expenses, orders and settings; only when those come back can the app ask for order items, payments and restocks. Slow connection = both waits stacked.
5. **Everything ever recorded is downloaded on every open.** Every order, every line, every payment, every expense, from day one — with no date limit — even though the screens show 50 at a time. Today that's small; after a year of billing it grows without limit.
6. **Photos attached to order lines travel in that same download.** Right now there are none, but each attached photo is stored inside the order record and would be re-downloaded on every single open.
7. **The whole app is one very large screen file (about 5,400 lines).** None of it can show until that file downloads, unpacks and starts up — on a phone over mobile data this alone is several seconds. Only the chart and the Excel export are separated out.
8. **Live sync re-downloads the entire shop on any change** — including changes you just made yourself, and sometimes while the first load is still running.
9. **The owner's screen fires an extra team-members request** during startup.
10. **After offline changes sync, the whole shop is downloaded again** rather than just the affected records.
11. **Fonts are fetched from Google on first paint**, which can delay text appearing on a slow connection.
12. **The preview is not the real speed.** The preview build is unminified and rebuilt on the fly; the published app is meaningfully faster. Part of your 30 seconds is the preview itself.

## Proposed fixes, in order of impact

**Step 1 — Cut the waiting before the screen appears**
- Read the stored session locally instead of asking the login server, and verify in the background.
- Skip the shop-lookup round trips when the answer is already remembered, and do the invite-claim write only when there is actually an invite to claim.
- Merge the two data waves into one request per screen's worth of data.

**Step 2 — Stop downloading the whole history**
- Load recent orders (last 3 months) plus everything still open, and fetch older ones only when someone searches or scrolls back.
- Leave attached photos out of the main download; fetch a photo only when the order is opened.

**Step 3 — Make the app file smaller to start**
- Split the screens (stock, orders, customers, finance, settings, backup, import) so opening the app only loads the dashboard, and the rest loads as you tap into them.

**Step 4 — Make live sync cheap**
- Ignore events caused by your own device, and refresh only the record that changed instead of re-downloading everything.
- Load the team list only when the Team section is opened.

**Step 5 — Measure honestly**
- Compare the published app against the preview and report real before/after timings on a throttled mobile connection.

## Technical notes
- `supabase.auth.getUser()` (ShopApp.tsx ~1897) → `getSession()` first, `getUser()` in the background.
- `resolveShopId` performs an UPDATE + SELECT on `shop_members` per open; gate the UPDATE behind an invite check and trust the cached id with background revalidation.
- `loadShop` (shopRepo.ts): wave 1 = 5 parallel `fetchAll`, wave 2 = `fetchChildren` for `order_items`/`order_payments`/`product_restocks` — dependent on wave 1. Replace with embedded selects (`orders?select=*,order_items(*),order_payments(*)`) so it is one wave, and add an `order_date` window plus open-status filter.
- Exclude `custom_photo_data_url` from the list select; fetch per order on demand.
- Code-split tab components out of the 5,392-line `ShopApp.tsx` with `React.lazy`.
- Realtime: the 8-table subscription currently calls full `loadShop` on any event (400 ms coalesce) — filter by `shop_owner_id`, ignore self-originated changes, and apply row-level patches.
- No database migration required for steps 1, 3, 4; step 2 may want an index on `(shop_owner_id, order_date desc)`.
