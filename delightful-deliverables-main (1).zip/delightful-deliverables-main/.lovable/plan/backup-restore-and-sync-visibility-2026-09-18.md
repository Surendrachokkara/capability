# Backup, restore and sync visibility

Goal: make it obvious that shop data is safe, give the shop owner a one-click backup they own, and show clearly what is synced and what is still waiting.

## 1. Automatic backups (platform side, nothing to build)

The cloud database already keeps daily automatic backups plus continuous logs, so data can be restored to a point in time. This covers server-side failures. It does not cover "I deleted 40 products by mistake last Tuesday" in a self-service way — that is what the owner-held backup below is for.

## 2. Owner backup button (Settings > Backup)

- "Download full backup" button: fetches every record (products, customers, suppliers, expenses, orders with their items and payments, restocks, shop settings) and saves one `.json` file named `shopname-backup-YYYY-MM-DD.json`.
- The file includes a version number, the shop id, the export date and record counts, so a restore can validate it.
- Also a "Download as Excel" option reusing the existing export code, for people who want to read it in a spreadsheet (Excel is for reading, JSON is for restoring).
- Size: a shop with tens of thousands of orders produces a few MB — fine for a browser download. Photos stored on order lines are the heavy part, so the backup stores them but the button warns when the file goes over ~25 MB.
- No hard limit on how much can be backed up; the download is streamed in pages of 1000 rows using the existing paged fetch.

## 3. Restore

- "Restore from backup" file picker in the same Settings section.
- Reads the file, validates the version and shape, then shows a preview: how many products/orders/customers/expenses it contains, how many already exist, how many are new.
- Two modes, chosen by the owner: **Merge** (add missing records, update matching ones) or **Replace** (wipe current records for this shop, then load the file). Replace asks for a typed confirmation.
- Owner-only. Staff never see this section.
- Every restored record goes through the same validation rules as normal saves, so a corrupt or hand-edited file cannot write bad data.

## 4. Sync visibility

- A small sync status line in the header: "All changes saved" / "Saving..." / "N changes waiting" with the age note already built.
- Settings gets a "Last full backup: 12 Sep 2026" line, and a gentle amber reminder once it is more than 30 days old (or never).
- Optional: a reminder to download a backup when the pending queue clears after a long offline spell.

## 5. Scale

Nothing changes in the database for this. The relational tables, per-record saves and paged reads already handle thousands of shops; each shop only ever reads its own rows and row-level security enforces that in the database, not just in the app.

## Technical notes

- New file `src/components/shop/shopBackup.ts`: `exportBackup(shopId)` (uses the existing paged `fetchAll`), `parseBackup(file)`, `restoreBackup(shopId, data, mode)`.
- Restore writes through the existing `saveKinds` / `saveOrderAtomic` paths so validation, snapshots and realtime all behave normally.
- Replace mode deletes through the owner-only delete policies, so it fails cleanly for staff.
- `lastBackupAt` stored in shop settings (already a JSON blob), so it syncs across devices.
- No schema migration required.
