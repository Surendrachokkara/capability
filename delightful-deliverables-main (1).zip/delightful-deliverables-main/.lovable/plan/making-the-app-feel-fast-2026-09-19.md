# Making the app feel fast

You said it lags everywhere: opening, switching screens, typing and scrolling, and saving. Two different causes are mixed together, so the plan separates them.

## First, an honest note about the preview

You tested inside the Lovable preview. The preview serves the app in ~143 separate unpacked pieces and rebuilds on the fly; the published app ships a handful of packed files. Measured just now on a phone-sized screen, the dashboard draws with your real figures, but the preview adds seconds that your customers would never see. Part of the fix is simply comparing against a published link — I'll do that as step 1 so we stop chasing a number that isn't real.

## What's actually still heavy

1. **The shared piece is still loaded up front.** Last round I split the screens out, but everything they share — all the buttons, inputs, date pickers, money formatting and the full Hindi/Telugu translation tables — sits in one ~97 KB file that loads before anything appears. The dashboard itself is also still inside the main file.
2. **Seven separate server trips on open**, some of which can be merged or delayed.
3. **Every keystroke redraws the whole screen.** The app holds all products, orders, customers and expenses in one place, so typing in a search box or a form re-renders lists that aren't even on screen. This is the likely cause of the typing/scrolling stutter — I'll confirm it with a profile before changing anything.
4. **Saving waits for the server before the screen updates**, so every save feels like a pause even when it succeeds.

## The plan

**Step 1 — Measure the real thing.** Publish, then time the published app and the preview side by side on a throttled mobile connection. Report both numbers so we know what we're fixing.

**Step 2 — Shrink what loads first.**
- Move the translations out of the shared file; load Hindi/Telugu only when that language is chosen.
- Split the shared file into "needed for the first screen" and "needed inside dialogs", so dialog-only pieces load on tap.
- Move the dashboard into its own piece too, so the main file is a thin shell.

**Step 3 — Make typing and scrolling smooth.**
- Profile a real typing session first to confirm the cause.
- Keep each screen's state to itself, memoise the list rows, and debounce search boxes so a keystroke redraws one list, not the whole app.
- For long lists, render only what fits the screen instead of all 50 rows plus their hidden siblings.

**Step 4 — Make saving feel instant.** Show the change on screen immediately and send it in the background, rolling back with a clear message only if the server rejects it (the offline queue already works this way).

**Step 5 — Trim the opening trips.** Merge or defer what can wait, and keep the last-saved copy showing while the refresh happens.

After each step I'll re-measure on the published app and report the before/after, rather than declaring it fixed.

## Technical notes

- `shopShared.tsx` (~97 KB, 78 exports) is imported eagerly by `ShopApp.tsx`; `TRANSLATIONS` moves to `shopI18n.<lang>.ts` behind a dynamic import, form primitives (`SelectInput`, `TextArea`, `OtherableSelect`, `SearchableProductSelect`, `DateFilterControl`, `Modal`, `resizeImageToDataUrl`) move to a `shopForms.tsx` chunk only the lazy modals pull in.
- Extract `DashboardTab` from `ShopApp.tsx` into its own lazy module, leaving auth + shell + data wiring in the entry file.
- React profiler run on the Stock search and the order form before any state change; expected fix is per-screen `useState`, `React.memo` on row components, `useDeferredValue` on search input, and windowing long lists.
- Optimistic writes: apply to local state, then `saveKind`/`saveOrderAtomic`, revert on error — snapshots in `shopRepo` already support a revert path.
- Startup requests: 7 responses to `supabase.co` on open (session, shop lookup, five data reads) — candidates for merging into fewer round trips.
- No database migration required.
