# Warn about unsynced offline changes

Right now the app counts the changes waiting to sync, but it doesn't say how old they are, and the warning only shows once you're back online. If someone works offline on Monday and doesn't reopen the app until Wednesday, nothing tells them those changes are still sitting on the device.

## What changes

1. **Remember when the first offline change was made.** Each waiting batch gets a timestamp the first time something is queued, cleared once everything syncs.

2. **Age shown in the waiting banner.** Instead of "5 changes made offline are waiting to sync", it reads "5 changes made offline 2 days ago are waiting to sync" (today / yesterday / N days ago).

3. **Warning on opening the app while still offline.** If there are waiting changes and there's no connection, a prominent amber notice appears at the top: how many changes, how old, and a plain reminder not to clear browsing data or switch device before reconnecting.

4. **Nudge when the changes are stale.** Once waiting changes are more than a day old, the banner turns amber (rather than the calm neutral style) and gains a "Sync now" button so it can be retried by hand instead of waiting for the automatic attempt.

5. **Confirmation after sync.** The existing "N offline changes synced" message stays, and the age note disappears with it.

## Technical notes

- `src/components/shop/shopQueue.ts`: add `queuedAt` (epoch ms) to the stored queue object, set in `enqueue` only when not already present, removed in `clear`/after a successful `flush`. Add `pendingSince(shopId)` returning the timestamp or null. Existing queues without the field are treated as "just now" so nothing breaks.
- `src/components/shop/ShopApp.tsx`: new `pendingSince` state alongside `pendingCount`, refreshed everywhere `setPendingCount` is already called; banner block at ~2855-2865 gains the age text, the amber variant, and the manual "Sync now" button reusing the existing `flush` handler at ~2010.
- No database or schema change — this is device-local only.
