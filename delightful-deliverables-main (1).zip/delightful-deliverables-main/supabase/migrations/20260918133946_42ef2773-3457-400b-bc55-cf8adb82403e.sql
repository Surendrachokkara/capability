-- Owner-or-staff read/write, owner-only delete, for top-level records
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['products','customers','suppliers','expenses','orders','order_counters'] LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', 'Owner or staff can access ' ||
      CASE t WHEN 'order_counters' THEN 'order counters' ELSE t END, t);
    EXECUTE format($f$CREATE POLICY "Owner or staff can read %1$s" ON public.%1$I FOR SELECT TO authenticated USING (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id))$f$, t);
    EXECUTE format($f$CREATE POLICY "Owner or staff can add %1$s" ON public.%1$I FOR INSERT TO authenticated WITH CHECK (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id))$f$, t);
    EXECUTE format($f$CREATE POLICY "Owner or staff can edit %1$s" ON public.%1$I FOR UPDATE TO authenticated USING (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id)) WITH CHECK (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id))$f$, t);
  END LOOP;
END $$;

-- Deletes: owner only for records that represent real history
CREATE POLICY "Only the owner can delete products" ON public.products FOR DELETE TO authenticated USING (auth.uid() = shop_owner_id);
CREATE POLICY "Only the owner can delete customers" ON public.customers FOR DELETE TO authenticated USING (auth.uid() = shop_owner_id);
CREATE POLICY "Only the owner can delete suppliers" ON public.suppliers FOR DELETE TO authenticated USING (auth.uid() = shop_owner_id);
CREATE POLICY "Only the owner can delete expenses" ON public.expenses FOR DELETE TO authenticated USING (auth.uid() = shop_owner_id);
CREATE POLICY "Only the owner can delete orders" ON public.orders FOR DELETE TO authenticated USING (auth.uid() = shop_owner_id);
-- Counters are internal bookkeeping; owner only
CREATE POLICY "Only the owner can delete order counters" ON public.order_counters FOR DELETE TO authenticated USING (auth.uid() = shop_owner_id);

-- Shop settings row: staff may read, only the owner may change it
DROP POLICY IF EXISTS "Owner or joined staff can access shop data" ON public.shop_data;
CREATE POLICY "Owner or staff can read shop data" ON public.shop_data FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_shop_member(user_id));
CREATE POLICY "Only the owner can create shop data" ON public.shop_data FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Only the owner can change shop data" ON public.shop_data FOR UPDATE TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Only the owner can delete shop data" ON public.shop_data FOR DELETE TO authenticated
  USING (auth.uid() = user_id);
