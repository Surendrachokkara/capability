-- ============ value constraints ============
ALTER TABLE public.products
  ADD CONSTRAINT products_cost_price_nonneg CHECK (cost_price >= 0) NOT VALID,
  ADD CONSTRAINT products_selling_price_nonneg CHECK (selling_price >= 0) NOT VALID,
  ADD CONSTRAINT products_opening_stock_nonneg CHECK (opening_stock >= 0) NOT VALID,
  ADD CONSTRAINT products_reorder_level_nonneg CHECK (reorder_level >= 0) NOT VALID,
  ADD CONSTRAINT products_gst_rate_range CHECK (gst_rate IS NULL OR (gst_rate >= 0 AND gst_rate <= 100)) NOT VALID,
  ADD CONSTRAINT products_name_not_blank CHECK (length(btrim(name)) > 0) NOT VALID;

ALTER TABLE public.customers
  ADD CONSTRAINT customers_name_not_blank CHECK (length(btrim(name)) > 0) NOT VALID,
  ADD CONSTRAINT customers_phone_not_blank CHECK (length(btrim(phone)) > 0) NOT VALID;

ALTER TABLE public.expenses
  ADD CONSTRAINT expenses_amount_nonneg CHECK (amount >= 0) NOT VALID;

ALTER TABLE public.orders
  ADD CONSTRAINT orders_discount_value_nonneg CHECK (discount_value >= 0) NOT VALID,
  ADD CONSTRAINT orders_advance_nonneg CHECK (advance >= 0) NOT VALID,
  ADD CONSTRAINT orders_order_no_not_blank CHECK (length(btrim(order_no)) > 0) NOT VALID,
  ADD CONSTRAINT orders_percent_discount_max CHECK (discount_type IS DISTINCT FROM 'percent' OR discount_value <= 100) NOT VALID;

ALTER TABLE public.order_items
  ADD CONSTRAINT order_items_qty_positive CHECK (qty > 0) NOT VALID,
  ADD CONSTRAINT order_items_unit_price_nonneg CHECK (unit_price >= 0) NOT VALID,
  ADD CONSTRAINT order_items_unit_cost_nonneg CHECK (unit_cost IS NULL OR unit_cost >= 0) NOT VALID;

ALTER TABLE public.order_payments
  ADD CONSTRAINT order_payments_amount_nonneg CHECK (amount >= 0) NOT VALID;

ALTER TABLE public.product_restocks
  ADD CONSTRAINT product_restocks_qty_positive CHECK (qty > 0) NOT VALID;

-- ============ atomic order number series ============
CREATE TABLE IF NOT EXISTS public.order_counters (
  shop_owner_id uuid NOT NULL REFERENCES public.shop_data(user_id) ON DELETE CASCADE,
  series text NOT NULL,
  last_no integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (shop_owner_id, series)
);

GRANT SELECT, INSERT, UPDATE ON public.order_counters TO authenticated;
GRANT ALL ON public.order_counters TO service_role;

ALTER TABLE public.order_counters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owner or staff can access order counters"
  ON public.order_counters FOR ALL TO authenticated
  USING (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id))
  WITH CHECK (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id));

-- Financial-year short code, matching the app: 1 April start, e.g. 2526
CREATE OR REPLACE FUNCTION public.financial_year_short(_d date)
RETURNS text LANGUAGE sql IMMUTABLE SET search_path = public AS $$
  SELECT CASE WHEN EXTRACT(MONTH FROM _d) >= 4
    THEN right(EXTRACT(YEAR FROM _d)::int::text, 2) || right((EXTRACT(YEAR FROM _d)::int + 1)::text, 2)
    ELSE right((EXTRACT(YEAR FROM _d)::int - 1)::text, 2) || right(EXTRACT(YEAR FROM _d)::int::text, 2)
  END
$$;

-- Hands out the next order number for a shop, one caller at a time.
CREATE OR REPLACE FUNCTION public.next_order_no(_shop_owner_id uuid, _order_date date)
RETURNS text LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE
  _series text;
  _next integer;
  _existing integer;
BEGIN
  _series := 'ORD-' || public.financial_year_short(_order_date);

  INSERT INTO public.order_counters (shop_owner_id, series, last_no)
  VALUES (_shop_owner_id, _series, 0)
  ON CONFLICT (shop_owner_id, series) DO NOTHING;

  SELECT last_no INTO _next FROM public.order_counters
   WHERE shop_owner_id = _shop_owner_id AND series = _series FOR UPDATE;

  IF _next IS NULL THEN
    RAISE EXCEPTION 'Not allowed to allocate order numbers for this shop';
  END IF;

  -- Respect numbers already in use from before the counter existed.
  SELECT COALESCE(MAX(NULLIF(regexp_replace(order_no, '^' || _series || '-', ''), order_no)::int), 0)
    INTO _existing
    FROM public.orders
   WHERE shop_owner_id = _shop_owner_id
     AND order_no ~ ('^' || _series || '-[0-9]+$');

  _next := GREATEST(_next, COALESCE(_existing, 0)) + 1;

  UPDATE public.order_counters
     SET last_no = _next, updated_at = now()
   WHERE shop_owner_id = _shop_owner_id AND series = _series;

  RETURN _series || '-' || lpad(_next::text, 4, '0');
END;
$$;

-- Saves an order plus its lines and payments as one all-or-nothing operation.
CREATE OR REPLACE FUNCTION public.save_order(
  _shop_owner_id uuid,
  _order jsonb,
  _items jsonb,
  _payments jsonb,
  _assign_order_no boolean DEFAULT false
) RETURNS jsonb LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE
  _id text := _order->>'id';
  _order_date date := COALESCE(NULLIF(_order->>'order_date','')::date, CURRENT_DATE);
  _order_no text := NULLIF(_order->>'order_no','');
BEGIN
  IF _id IS NULL OR length(btrim(_id)) = 0 THEN
    RAISE EXCEPTION 'Order id is required';
  END IF;

  IF _assign_order_no OR _order_no IS NULL THEN
    _order_no := public.next_order_no(_shop_owner_id, _order_date);
  END IF;

  INSERT INTO public.orders (
    id, shop_owner_id, customer_id, order_no, order_date, customer_name, customer_phone,
    order_type, status, discount_type, discount_value, advance, payment_mode,
    split_payment, delivery_date, notes
  ) VALUES (
    _id, _shop_owner_id, NULLIF(_order->>'customer_id',''), _order_no, _order_date,
    NULLIF(_order->>'customer_name',''), NULLIF(_order->>'customer_phone',''),
    COALESCE(NULLIF(_order->>'order_type',''), 'Walk-in'),
    COALESCE(NULLIF(_order->>'status',''), 'Pending'),
    NULLIF(_order->>'discount_type',''),
    COALESCE((_order->>'discount_value')::numeric, 0),
    COALESCE((_order->>'advance')::numeric, 0),
    NULLIF(_order->>'payment_mode',''),
    COALESCE((_order->>'split_payment')::boolean, false),
    NULLIF(_order->>'delivery_date','')::date,
    NULLIF(_order->>'notes','')
  )
  ON CONFLICT (id) DO UPDATE SET
    customer_id = EXCLUDED.customer_id,
    order_date = EXCLUDED.order_date,
    customer_name = EXCLUDED.customer_name,
    customer_phone = EXCLUDED.customer_phone,
    order_type = EXCLUDED.order_type,
    status = EXCLUDED.status,
    discount_type = EXCLUDED.discount_type,
    discount_value = EXCLUDED.discount_value,
    advance = EXCLUDED.advance,
    payment_mode = EXCLUDED.payment_mode,
    split_payment = EXCLUDED.split_payment,
    delivery_date = EXCLUDED.delivery_date,
    notes = EXCLUDED.notes,
    updated_at = now();

  DELETE FROM public.order_items WHERE order_id = _id;
  IF _items IS NOT NULL AND jsonb_typeof(_items) = 'array' THEN
    INSERT INTO public.order_items (
      order_id, product_id, name, category, sku, qty, unit_price, unit_cost,
      custom_photo, custom_photo_note, custom_photo_data_url
    )
    SELECT _id, NULLIF(it->>'product_id',''), COALESCE(it->>'name',''), NULLIF(it->>'category',''),
           NULLIF(it->>'sku',''), GREATEST(COALESCE((it->>'qty')::int, 1), 1),
           COALESCE((it->>'unit_price')::numeric, 0),
           NULLIF(it->>'unit_cost','')::numeric,
           COALESCE((it->>'custom_photo')::boolean, false),
           NULLIF(it->>'custom_photo_note',''), NULLIF(it->>'custom_photo_data_url','')
      FROM jsonb_array_elements(_items) AS it;
  END IF;

  DELETE FROM public.order_payments WHERE order_id = _id;
  IF _payments IS NOT NULL AND jsonb_typeof(_payments) = 'array' THEN
    INSERT INTO public.order_payments (order_id, mode, amount)
    SELECT _id, p->>'mode', COALESCE((p->>'amount')::numeric, 0)
      FROM jsonb_array_elements(_payments) AS p
     WHERE NULLIF(p->>'mode','') IS NOT NULL;
  END IF;

  RETURN jsonb_build_object('id', _id, 'order_no', _order_no);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.next_order_no(uuid, date) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.save_order(uuid, jsonb, jsonb, jsonb, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.next_order_no(uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.save_order(uuid, jsonb, jsonb, jsonb, boolean) TO authenticated;