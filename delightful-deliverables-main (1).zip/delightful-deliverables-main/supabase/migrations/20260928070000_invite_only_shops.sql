-- New shops open only for an email the seller added, or for staff invited into
-- an existing shop. Sign-in for accounts that already exist is unchanged.

create table if not exists public.platform_admins (
  email text primary key,
  user_id uuid references auth.users (id) on delete set null,
  claimed_at timestamptz not null default now()
);

create table if not exists public.platform_invites (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  note text,
  invited_at timestamptz not null default now()
);

alter table public.platform_admins enable row level security;
alter table public.platform_invites enable row level security;

grant select on public.platform_admins to authenticated;
grant select, insert, update, delete on public.platform_invites to authenticated;
grant all on public.platform_admins to service_role;
grant all on public.platform_invites to service_role;

create or replace function public.is_platform_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.platform_admins
    where email = lower(trim(coalesce(auth.jwt() ->> 'email', '')))
  );
$$;

create or replace function public.platform_has_seller()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.platform_admins);
$$;

create or replace function public.claim_platform_admin()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  caller_email text := lower(trim(coalesce(auth.jwt() ->> 'email', '')));
begin
  if auth.uid() is null or caller_email = '' then
    raise exception 'Sign in with an email account first.';
  end if;

  perform pg_advisory_xact_lock(814275);

  if exists (select 1 from public.platform_admins where email = caller_email) then
    update public.platform_admins
      set user_id = auth.uid()
      where email = caller_email and user_id is null;
    return true;
  end if;

  if exists (select 1 from public.platform_admins) then
    return false;
  end if;

  insert into public.platform_admins (email, user_id)
  values (caller_email, auth.uid());
  return true;
end;
$$;

create or replace function public.email_can_join(check_email text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select lower(trim(coalesce(check_email, ''))) <> ''
    and (
      exists (
        select 1
        from public.platform_invites
        where email = lower(trim(check_email))
      )
      or exists (
        select 1
        from public.shop_members
        where lower(invited_email) = lower(trim(check_email))
      )
      or (
        not exists (select 1 from auth.users)
        and not exists (select 1 from public.platform_admins)
      )
    );
$$;

create or replace function public.normalize_platform_invite_email()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.email := lower(trim(coalesce(new.email, '')));
  if new.email !~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' then
    raise exception 'Enter a valid email.';
  end if;
  return new;
end;
$$;

drop trigger if exists platform_invites_normalize_email on public.platform_invites;
create trigger platform_invites_normalize_email
  before insert or update of email on public.platform_invites
  for each row execute function public.normalize_platform_invite_email();

create or replace function public.block_uninvited_signup()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  normalized text := lower(trim(coalesce(new.email, '')));
begin
  if normalized = '' then
    raise exception 'A new shop needs an invited email. Phone sign-in is only for a number that already has an account.'
      using errcode = '42501';
  end if;

  if exists (select 1 from public.platform_invites where email = normalized)
     or exists (select 1 from public.shop_members where lower(invited_email) = normalized) then
    return new;
  end if;

  -- First account on an empty project becomes the seller. After that, only invites.
  perform pg_advisory_xact_lock(814275);
  if not exists (select 1 from auth.users)
     and not exists (select 1 from public.platform_admins) then
    return new;
  end if;

  raise exception 'This email is not invited. The seller has to add it before you can create a shop.'
    using errcode = '42501';
end;
$$;

create or replace function public.promote_first_seller()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  normalized text := lower(trim(coalesce(new.email, '')));
begin
  if normalized = '' then
    return new;
  end if;

  if (select count(*) from auth.users) = 1
     and not exists (select 1 from public.platform_admins) then
    insert into public.platform_admins (email, user_id)
    values (normalized, new.id)
    on conflict (email) do nothing;
  end if;

  return new;
end;
$$;

drop trigger if exists block_uninvited_signup on auth.users;
create trigger block_uninvited_signup
  before insert on auth.users
  for each row execute function public.block_uninvited_signup();

drop trigger if exists promote_first_seller on auth.users;
create trigger promote_first_seller
  after insert on auth.users
  for each row execute function public.promote_first_seller();

drop policy if exists "A person can see their own seller row" on public.platform_admins;
create policy "A person can see their own seller row"
  on public.platform_admins
  for select
  to authenticated
  using (email = lower(trim(coalesce(auth.jwt() ->> 'email', ''))));

drop policy if exists "Sellers manage shop invites" on public.platform_invites;
create policy "Sellers manage shop invites"
  on public.platform_invites
  for all
  to authenticated
  using (public.is_platform_admin())
  with check (public.is_platform_admin());

revoke all on function public.block_uninvited_signup() from public;
revoke all on function public.promote_first_seller() from public;
revoke all on function public.normalize_platform_invite_email() from public;
revoke all on function public.is_platform_admin() from public;
revoke all on function public.platform_has_seller() from public;
revoke all on function public.claim_platform_admin() from public;
revoke all on function public.email_can_join(text) from public;

grant execute on function public.is_platform_admin() to authenticated, service_role;
grant execute on function public.platform_has_seller() to authenticated, service_role;
grant execute on function public.claim_platform_admin() to authenticated, service_role;
grant execute on function public.email_can_join(text) to anon, authenticated, service_role;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'supabase_auth_admin') then
    grant execute on function public.block_uninvited_signup() to supabase_auth_admin;
    grant execute on function public.promote_first_seller() to supabase_auth_admin;
  end if;
end $$;
