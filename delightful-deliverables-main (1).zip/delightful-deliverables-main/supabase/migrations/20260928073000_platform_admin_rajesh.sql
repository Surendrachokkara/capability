-- The seller is one account. Other people cannot claim that role or see invite controls.

insert into public.platform_admins (email)
values ('rajeshhyd278@gmail.com')
on conflict (email) do nothing;

delete from public.platform_admins
where email <> 'rajeshhyd278@gmail.com';

alter table public.platform_invites
  add column if not exists blocked boolean not null default false;

create or replace function public.claim_platform_admin()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  caller_email text := lower(trim(coalesce(auth.jwt() ->> 'email', '')));
begin
  if auth.uid() is null or caller_email <> 'rajeshhyd278@gmail.com' then
    return false;
  end if;

  update public.platform_admins
    set user_id = auth.uid()
    where email = caller_email;
  return found;
end;
$$;

create or replace function public.email_can_join(check_email text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select lower(trim(coalesce(check_email, ''))) <> ''
    and (
      exists (
        select 1
        from public.platform_admins
        where email = lower(trim(check_email))
      )
      or exists (
        select 1
        from public.platform_invites
        where email = lower(trim(check_email))
          and blocked = false
      )
      or exists (
        select 1
        from public.shop_members
        where lower(invited_email) = lower(trim(check_email))
      )
    );
$$;

create or replace function public.block_uninvited_signup()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  normalized text := lower(trim(coalesce(new.email, '')));
begin
  if normalized = '' then
    raise exception 'A new shop needs an invited email. Phone sign-in is only for a number that already has an account.'
      using errcode = '42501';
  end if;

  if exists (select 1 from public.platform_admins where email = normalized) then
    return new;
  end if;

  if exists (
    select 1 from public.platform_invites
    where email = normalized and blocked = false
  ) or exists (
    select 1 from public.shop_members
    where lower(invited_email) = normalized
  ) then
    return new;
  end if;

  if exists (select 1 from public.platform_invites where email = normalized and blocked) then
    raise exception 'This email is blocked. The seller has to allow it before a shop can open.'
      using errcode = '42501';
  end if;

  raise exception 'This email is not invited. The seller has to add it before you can create a shop.'
    using errcode = '42501';
end;
$$;

drop trigger if exists promote_first_seller on auth.users;

create or replace function public.platform_admin_report()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  result jsonb;
begin
  if not public.is_platform_admin() then
    raise exception 'Only the seller can see this.'
      using errcode = '42501';
  end if;

  select jsonb_build_object(
    'invited', (select count(*) from public.platform_invites),
    'opened', (
      select count(*)
      from public.platform_invites i
      where i.blocked = false
        and exists (select 1 from auth.users u where lower(u.email) = i.email)
    ),
    'waiting', (
      select count(*)
      from public.platform_invites i
      where i.blocked = false
        and not exists (select 1 from auth.users u where lower(u.email) = i.email)
    ),
    'blocked', (select count(*) from public.platform_invites where blocked),
    'rows', (
      select coalesce(jsonb_agg(to_jsonb(r) order by r.invited_at desc), '[]'::jsonb)
      from (
        select
          i.id,
          i.email,
          i.note,
          i.invited_at,
          i.blocked,
          u.created_at as opened_at,
          nullif(sd.settings ->> 'shopName', '') as shop_name
        from public.platform_invites i
        left join auth.users u on lower(u.email) = i.email
        left join public.shop_data sd on sd.user_id = u.id
      ) r
    )
  ) into result;

  return result;
end;
$$;

create or replace function public.set_platform_invite_blocked(invite_id uuid, is_blocked boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  target_email text;
begin
  if not public.is_platform_admin() then
    raise exception 'Only the seller can change this.'
      using errcode = '42501';
  end if;

  select email into target_email
  from public.platform_invites
  where id = invite_id;

  if target_email is null then
    raise exception 'That email is not on the list.';
  end if;

  if target_email = 'rajeshhyd278@gmail.com' then
    raise exception 'The seller account cannot be blocked.';
  end if;

  update public.platform_invites
    set blocked = is_blocked
    where id = invite_id;

  if is_blocked then
    update auth.users
      set banned_until = timestamptz '2999-01-01'
      where lower(email) = target_email;
  else
    update auth.users
      set banned_until = null
      where lower(email) = target_email;
  end if;
end;
$$;

revoke all on function public.claim_platform_admin() from public;
revoke all on function public.email_can_join(text) from public;
revoke all on function public.block_uninvited_signup() from public;
revoke all on function public.platform_admin_report() from public;
revoke all on function public.set_platform_invite_blocked(uuid, boolean) from public;

grant execute on function public.claim_platform_admin() to authenticated, service_role;
grant execute on function public.email_can_join(text) to anon, authenticated, service_role;
grant execute on function public.platform_admin_report() to authenticated, service_role;
grant execute on function public.set_platform_invite_blocked(uuid, boolean) to authenticated, service_role;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'supabase_auth_admin') then
    grant execute on function public.block_uninvited_signup() to supabase_auth_admin;
  end if;
end $$;
