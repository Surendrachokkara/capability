create table if not exists public.shop_members (
  id uuid primary key default gen_random_uuid(),
  shop_owner_id uuid not null references auth.users(id) on delete cascade,
  member_user_id uuid references auth.users(id) on delete cascade,
  invited_email text not null,
  role text not null default 'staff' check (role in ('staff')),
  invited_at timestamptz not null default now(),
  joined_at timestamptz,
  unique (shop_owner_id, invited_email)
);

grant select, insert, update, delete on public.shop_members to authenticated;
grant all on public.shop_members to service_role;

alter table public.shop_members enable row level security;

create policy "Owners manage their own shop's members"
  on public.shop_members for all
  to authenticated
  using (auth.uid() = shop_owner_id)
  with check (auth.uid() = shop_owner_id);

create policy "A person can see their own membership"
  on public.shop_members for select
  to authenticated
  using (auth.uid() = member_user_id or auth.email() = invited_email);

create policy "A person can claim a pending invite addressed to their email"
  on public.shop_members for update
  to authenticated
  using (auth.email() = invited_email and member_user_id is null)
  with check (member_user_id = auth.uid());

drop policy if exists "Users can manage their own shop data" on public.shop_data;

create policy "Owner or joined staff can access shop data"
  on public.shop_data for all
  to authenticated
  using (
    auth.uid() = user_id
    or auth.uid() in (
      select member_user_id from public.shop_members
      where shop_owner_id = shop_data.user_id and member_user_id is not null
    )
  )
  with check (
    auth.uid() = user_id
    or auth.uid() in (
      select member_user_id from public.shop_members
      where shop_owner_id = shop_data.user_id and member_user_id is not null
    )
  );