-- Phase 1: relational schema + data migration
-- Keeps shop_data JSONB columns as backup until app integration is complete.

-- 1. Products
CREATE TABLE public.products (
  id text PRIMARY KEY,
  shop_owner_id uuid NOT NULL REFERENCES public.shop_data(user_id) ON DELETE CASCADE,
  sku text NOT NULL,
  category text NOT NULL,
  name text NOT NULL,
  size text,
  customization text,
  cost_price numeric(12,2) NOT NULL DEFAULT 0,
  selling_price numeric(12,2) NOT NULL DEFAULT 0,
  opening_stock integer NOT NULL DEFAULT 0,
  reorder_level integer NOT NULL DEFAULT 5,
  active boolean NOT NULL DEFAULT true,
  gst_rate numeric(5,2) DEFAULT 0,
  hsn_code text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 2. Customers
CREATE TABLE public.customers (
  id text PRIMARY KEY,
  shop_owner_id uuid NOT NULL REFERENCES public.shop_data(user_id) ON DELETE CASCADE,
  name text NOT NULL,
  phone text NOT NULL,
  address text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 3. Suppliers
CREATE TABLE public.suppliers (
  id text PRIMARY KEY,
  shop_owner_id uuid NOT NULL REFERENCES public.shop_data(user_id) ON DELETE CASCADE,
  name text NOT NULL,
  phone text,
  address text,
  notes text,
  supplies text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 4. Expenses
CREATE TABLE public.expenses (
  id text PRIMARY KEY,
  shop_owner_id uuid NOT NULL REFERENCES public.shop_data(user_id) ON DELETE CASCADE,
  supplier_id text REFERENCES public.suppliers(id) ON DELETE SET NULL,
  spent_at date NOT NULL,
  category text NOT NULL,
  description text,
  amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_mode text NOT NULL DEFAULT 'Cash',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 5. Orders
CREATE TABLE public.orders (
  id text PRIMARY KEY,
  shop_owner_id uuid NOT NULL REFERENCES public.shop_data(user_id) ON DELETE CASCADE,
  customer_id text REFERENCES public.customers(id) ON DELETE SET NULL,
  order_no text NOT NULL,
  order_date date NOT NULL,
  customer_name text,
  customer_phone text,
  order_type text NOT NULL CHECK (order_type IN ('Walk-in', 'Custom')),
  status text NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'In Progress', 'Ready', 'Delivered', 'Cancelled', 'Returned')),
  discount_type text,
  discount_value numeric(12,2) NOT NULL DEFAULT 0,
  advance numeric(12,2) NOT NULL DEFAULT 0,
  payment_mode text,
  split_payment boolean NOT NULL DEFAULT false,
  delivery_date date,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 6. Order items
CREATE TABLE public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id text NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id text REFERENCES public.products(id) ON DELETE SET NULL,
  name text NOT NULL,
  category text,
  sku text,
  qty integer NOT NULL DEFAULT 1,
  unit_price numeric(12,2) NOT NULL DEFAULT 0,
  unit_cost numeric(12,2),
  custom_photo boolean NOT NULL DEFAULT false,
  custom_photo_note text,
  custom_photo_data_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 7. Order payments
CREATE TABLE public.order_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id text NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  mode text NOT NULL CHECK (mode IN ('Cash', 'UPI', 'Card')),
  amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_at timestamptz NOT NULL DEFAULT now()
);

-- 8. Product restocks
CREATE TABLE public.product_restocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id text NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  restocked_at date NOT NULL,
  qty integer NOT NULL DEFAULT 0,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX idx_products_shop_owner ON public.products (shop_owner_id);
CREATE INDEX idx_products_category ON public.products (category);
CREATE INDEX idx_customers_shop_owner ON public.customers (shop_owner_id);
CREATE INDEX idx_customers_phone ON public.customers (shop_owner_id, phone);
CREATE INDEX idx_suppliers_shop_owner ON public.suppliers (shop_owner_id);
CREATE INDEX idx_expenses_shop_owner ON public.expenses (shop_owner_id);
CREATE INDEX idx_expenses_spent_at ON public.expenses (spent_at);
CREATE INDEX idx_orders_shop_owner ON public.orders (shop_owner_id);
CREATE INDEX idx_orders_order_date ON public.orders (order_date);
CREATE INDEX idx_orders_status ON public.orders (status);
CREATE INDEX idx_order_items_order ON public.order_items (order_id);
CREATE INDEX idx_order_payments_order ON public.order_payments (order_id);
CREATE INDEX idx_product_restocks_product ON public.product_restocks (product_id);

-- Grants
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.customers TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.suppliers TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.expenses TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.orders TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.order_items TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.order_payments TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.product_restocks TO authenticated;

GRANT ALL ON public.products TO service_role;
GRANT ALL ON public.customers TO service_role;
GRANT ALL ON public.suppliers TO service_role;
GRANT ALL ON public.expenses TO service_role;
GRANT ALL ON public.orders TO service_role;
GRANT ALL ON public.order_items TO service_role;
GRANT ALL ON public.order_payments TO service_role;
GRANT ALL ON public.product_restocks TO service_role;

-- Enable RLS
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_restocks ENABLE ROW LEVEL SECURITY;

-- Helper: is the current user a member of the owner's shop?
CREATE OR REPLACE FUNCTION public.is_shop_member(_shop_owner_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.shop_members
    WHERE shop_owner_id = _shop_owner_id
      AND member_user_id = auth.uid()
  )
$$;

-- Policies: owner or joined staff can access everything on a shop's data
CREATE POLICY "Owner or staff can access products"
ON public.products
FOR ALL
TO authenticated
USING (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id))
WITH CHECK (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id));

CREATE POLICY "Owner or staff can access customers"
ON public.customers
FOR ALL
TO authenticated
USING (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id))
WITH CHECK (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id));

CREATE POLICY "Owner or staff can access suppliers"
ON public.suppliers
FOR ALL
TO authenticated
USING (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id))
WITH CHECK (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id));

CREATE POLICY "Owner or staff can access expenses"
ON public.expenses
FOR ALL
TO authenticated
USING (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id))
WITH CHECK (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id));

CREATE POLICY "Owner or staff can access orders"
ON public.orders
FOR ALL
TO authenticated
USING (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id))
WITH CHECK (auth.uid() = shop_owner_id OR public.is_shop_member(shop_owner_id));

CREATE POLICY "Owner or staff can access order items"
ON public.order_items
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.orders
    WHERE orders.id = order_items.order_id
      AND (auth.uid() = orders.shop_owner_id OR public.is_shop_member(orders.shop_owner_id))
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.orders
    WHERE orders.id = order_items.order_id
      AND (auth.uid() = orders.shop_owner_id OR public.is_shop_member(orders.shop_owner_id))
  )
);

CREATE POLICY "Owner or staff can access order payments"
ON public.order_payments
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.orders
    WHERE orders.id = order_payments.order_id
      AND (auth.uid() = orders.shop_owner_id OR public.is_shop_member(orders.shop_owner_id))
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.orders
    WHERE orders.id = order_payments.order_id
      AND (auth.uid() = orders.shop_owner_id OR public.is_shop_member(orders.shop_owner_id))
  )
);

CREATE POLICY "Owner or staff can access product restocks"
ON public.product_restocks
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.products
    WHERE products.id = product_restocks.product_id
      AND (auth.uid() = products.shop_owner_id OR public.is_shop_member(products.shop_owner_id))
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.products
    WHERE products.id = product_restocks.product_id
      AND (auth.uid() = products.shop_owner_id OR public.is_shop_member(products.shop_owner_id))
  )
);

-- updated_at triggers
CREATE TRIGGER update_products_updated_at
BEFORE UPDATE ON public.products
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_customers_updated_at
BEFORE UPDATE ON public.customers
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_suppliers_updated_at
BEFORE UPDATE ON public.suppliers
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_orders_updated_at
BEFORE UPDATE ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Migrate existing JSONB data from shop_data into the new tables
DO $$
DECLARE
  shop_row public.shop_data%ROWTYPE;
  prod jsonb;
  cust jsonb;
  supp jsonb;
  exp jsonb;
  ord jsonb;
  it jsonb;
  pay jsonb;
  rs jsonb;
  matched_customer_id text;
BEGIN
  FOR shop_row IN SELECT * FROM public.shop_data LOOP
    -- products
    FOR prod IN SELECT * FROM jsonb_array_elements(COALESCE(shop_row.products, '[]'::jsonb)) LOOP
      INSERT INTO public.products (
        id, shop_owner_id, sku, category, name, size, customization,
        cost_price, selling_price, opening_stock, reorder_level, active,
        gst_rate, hsn_code
      ) VALUES (
        prod->>'id',
        shop_row.user_id,
        COALESCE(NULLIF(prod->>'sku',''), prod->>'id'),
        prod->>'category',
        prod->>'name',
        prod->>'size',
        prod->>'customization',
        COALESCE((prod->>'costPrice')::numeric, 0),
        COALESCE((prod->>'sellingPrice')::numeric, 0),
        COALESCE((prod->>'openingStock')::int, 0),
        COALESCE((prod->>'reorderLevel')::int, 5),
        COALESCE((prod->>'active')::boolean, true),
        COALESCE((prod->>'gstRate')::numeric, 0),
        prod->>'hsnCode'
      )
      ON CONFLICT (id) DO NOTHING;

      FOR rs IN SELECT * FROM jsonb_array_elements(COALESCE(prod->'restocks', '[]'::jsonb)) LOOP
        INSERT INTO public.product_restocks (product_id, restocked_at, qty, note)
        VALUES (
          prod->>'id',
          COALESCE(NULLIF(rs->>'date','')::date, CURRENT_DATE),
          COALESCE((rs->>'qty')::int, 0),
          rs->>'note'
        );
      END LOOP;
    END LOOP;

    -- customers
    FOR cust IN SELECT * FROM jsonb_array_elements(COALESCE(shop_row.customers, '[]'::jsonb)) LOOP
      INSERT INTO public.customers (
        id, shop_owner_id, name, phone, address, notes
      ) VALUES (
        cust->>'id',
        shop_row.user_id,
        cust->>'name',
        cust->>'phone',
        cust->>'address',
        cust->>'notes'
      )
      ON CONFLICT (id) DO NOTHING;
    END LOOP;

    -- suppliers
    FOR supp IN SELECT * FROM jsonb_array_elements(COALESCE(shop_row.suppliers, '[]'::jsonb)) LOOP
      INSERT INTO public.suppliers (
        id, shop_owner_id, name, phone, address, notes, supplies
      ) VALUES (
        supp->>'id',
        shop_row.user_id,
        supp->>'name',
        supp->>'phone',
        supp->>'address',
        supp->>'notes',
        supp->>'supplies'
      )
      ON CONFLICT (id) DO NOTHING;
    END LOOP;

    -- expenses
    FOR exp IN SELECT * FROM jsonb_array_elements(COALESCE(shop_row.expenses, '[]'::jsonb)) LOOP
      INSERT INTO public.expenses (
        id, shop_owner_id, supplier_id, spent_at, category, description,
        amount, payment_mode
      ) VALUES (
        exp->>'id',
        shop_row.user_id,
        NULLIF(exp->>'supplierId',''),
        COALESCE(NULLIF(exp->>'date','')::date, CURRENT_DATE),
        exp->>'category',
        exp->>'description',
        COALESCE((exp->>'amount')::numeric, 0),
        COALESCE(exp->>'paymentMode','Cash')
      )
      ON CONFLICT (id) DO NOTHING;
    END LOOP;

    -- orders
    FOR ord IN SELECT * FROM jsonb_array_elements(COALESCE(shop_row.orders, '[]'::jsonb)) LOOP
      SELECT id INTO matched_customer_id
      FROM public.customers
      WHERE shop_owner_id = shop_row.user_id
        AND phone = ord->>'customerPhone'
      LIMIT 1;

      INSERT INTO public.orders (
        id, shop_owner_id, customer_id, order_no, order_date, customer_name,
        customer_phone, order_type, status, discount_type, discount_value,
        advance, payment_mode, split_payment, delivery_date, notes
      ) VALUES (
        ord->>'id',
        shop_row.user_id,
        matched_customer_id,
        ord->>'orderNo',
        COALESCE(NULLIF(ord->>'date','')::date, CURRENT_DATE),
        ord->>'customerName',
        ord->>'customerPhone',
        COALESCE(ord->>'orderType','Walk-in'),
        COALESCE(ord->>'status','Pending'),
        NULLIF(ord->>'discountType',''),
        COALESCE((ord->>'discountValue')::numeric, 0),
        COALESCE((ord->>'advance')::numeric, 0),
        ord->>'paymentMode',
        COALESCE((ord->>'splitPayment')::boolean, false),
        NULLIF(ord->>'deliveryDate','')::date,
        ord->>'notes'
      )
      ON CONFLICT (id) DO NOTHING;

      FOR it IN SELECT * FROM jsonb_array_elements(COALESCE(ord->'items', '[]'::jsonb)) LOOP
        INSERT INTO public.order_items (
          order_id, product_id, name, category, sku, qty, unit_price,
          unit_cost, custom_photo, custom_photo_note, custom_photo_data_url
        ) VALUES (
          ord->>'id',
          it->>'productId',
          it->>'name',
          it->>'category',
          it->>'sku',
          COALESCE((it->>'qty')::int, 1),
          COALESCE((it->>'unitPrice')::numeric, 0),
          CASE
            WHEN it->>'unitCost' IS NULL OR it->>'unitCost' = '' THEN NULL
            ELSE (it->>'unitCost')::numeric
          END,
          COALESCE((it->>'customPhoto')::boolean, false),
          it->>'customPhotoNote',
          it->>'customPhotoDataUrl'
        );
      END LOOP;

      FOR pay IN SELECT * FROM jsonb_array_elements(COALESCE(ord->'payments', '[]'::jsonb)) LOOP
        INSERT INTO public.order_payments (order_id, mode, amount)
        VALUES (
          ord->>'id',
          COALESCE(pay->>'mode','Cash'),
          COALESCE((pay->>'amount')::numeric, 0)
        );
      END LOOP;
    END LOOP;
  END LOOP;
END $$;

-- Add uniqueness / constraints now that data is migrated
ALTER TABLE public.products
  ADD CONSTRAINT products_shop_sku_unique UNIQUE (shop_owner_id, sku);

ALTER TABLE public.customers
  ADD CONSTRAINT customers_shop_phone_unique UNIQUE (shop_owner_id, phone);

-- Ensure order numbers are unique within a shop
ALTER TABLE public.orders
  ADD CONSTRAINT orders_shop_order_no_unique UNIQUE (shop_owner_id, order_no);
