CREATE OR REPLACE FUNCTION public.is_shop_member(_shop_owner_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.shop_members
    WHERE shop_owner_id = _shop_owner_id
      AND member_user_id = auth.uid()
  )
$$;

REVOKE EXECUTE ON FUNCTION public.is_shop_member(uuid) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.is_shop_member(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.is_shop_member(uuid) TO authenticated;