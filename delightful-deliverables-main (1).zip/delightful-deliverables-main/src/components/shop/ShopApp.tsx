// @ts-nocheck
import React, { useState, useEffect, useMemo, useCallback, useRef, lazy, Suspense } from "react";
import { Users, Plus, AlertTriangle, Frame, Clock, PackageCheck, CircleCheck, RefreshCw, ChevronRight, Phone, Upload, UserRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import * as shopRepo from "./shopRepo";
import * as shopQueue from "./shopQueue";
import * as shopBackup from "./shopBackup";
import { firstError, productSchema, customerSchema, expenseSchema, orderFormSchema, restockSchema, settingsSchema } from "./shopSchemas";
import { T, FONT_DISPLAY, PAYMENT_MODES, NAV, genId, useLanguage, toLocalISODate, todayStr, fmtMoney, fmtDate, fmtShortDate, num, orderPayments, orderDiscount, normalizePhone, waDigits, orderWaMessage, DATA_COLUMNS, activeUserId, setActiveUserId, isConnectionError, cacheShopData, readCachedShopData, cacheShopBrand, readCachedShopBrand, clearLastCachedShopBrand, cachedShopIdFor, cacheShopIdFor, Badge, CategoryTag, StatusBadge, ContactActions, PrimaryButton, GhostButton, Field, TextInput, ConfirmDialog, EmptyState, StatCard, MiniStat, pendingAge, loadKey, saveKey, saveMultipleKeys } from "./shopShared";

// Each screen and dialog is its own download, fetched the first time it's opened,
// so starting the app only loads the dashboard. Each one carries its own loading
// boundary, so nothing else has to change at the places they're used.
const deferredDefault = (load) => {
  const C = lazy(load);
  const Wrapped = (props) => (
    <Suspense fallback={null}>
      <C {...props} />
    </Suspense>
  );
  return Wrapped;
};
const DashboardTab = deferredDefault(() => import("./ShopDashboard"));

const deferred = (load, name) => {
  const C = lazy(() => load().then((m) => ({ default: m[name] })));
  const Wrapped = (props) => (
    <Suspense fallback={null}>
      <C {...props} />
    </Suspense>
  );
  return Wrapped;
};
const screens = () => import("./ShopScreens");
const modals = () => import("./ShopModals");

const StockTab = deferred(screens, "StockTab");
const OrdersTab = deferred(screens, "OrdersTab");
const CustomersTab = deferred(screens, "CustomersTab");
const FinanceTab = deferred(screens, "FinanceTab");
const ImportModal = deferred(modals, "ImportModal");
const ProductModal = deferred(modals, "ProductModal");
const RestockModal = deferred(modals, "RestockModal");
const OrderModal = deferred(modals, "OrderModal");
const CustomerModal = deferred(modals, "CustomerModal");
const CustomerDetailModal = deferred(modals, "CustomerDetailModal");
const ProductDetailModal = deferred(modals, "ProductDetailModal");
const ReceiptModal = deferred(modals, "ReceiptModal");
const ReturnModal = deferred(modals, "ReturnModal");
const ExpenseModal = deferred(modals, "ExpenseModal");
const RestoreModal = deferred(modals, "RestoreModal");
const SettingsModal = deferred(modals, "SettingsModal");


function ResetPasswordScreen({ onDone }) {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    setMessage("");
    if (password.length < 6) { setMessage("Use at least 6 characters."); return; }
    if (password !== confirm) { setMessage("Both passwords must match."); return; }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) { setMessage(error.message); return; }
    onDone();
  };

  return (
    <main className="min-h-screen flex items-center justify-center px-5" style={{ backgroundColor: T.bg }}>
      <div className="w-full max-w-sm rounded-lg border p-6" style={{ backgroundColor: T.surface, borderColor: T.border }}>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-md flex items-center justify-center" style={{ backgroundColor: T.brassSoft }}>
            <Frame size={20} style={{ color: T.brass }} />
          </div>
          <div>
            <h1 className="text-lg font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>Choose a new password</h1>
            <p className="text-xs" style={{ color: T.inkFaint }}>You're signed in from a reset link</p>
          </div>
        </div>
        <form onSubmit={submit} className="flex flex-col gap-3.5">
          <Field label="New password" required><TextInput type="password" required minLength={6} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
          <Field label="Confirm new password" required><TextInput type="password" required minLength={6} autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} /></Field>
          {message && <p className="text-xs leading-5" style={{ color: T.danger }}>{message}</p>}
          <PrimaryButton type="submit" full>{busy ? "Please wait…" : "Save new password"}</PrimaryButton>
        </form>
      </div>
    </main>
  );
}

function AuthScreen() {
  const [mode, setMode] = useState("signin");
  const [view, setView] = useState("form");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const from = (raw) => new URLSearchParams(raw.startsWith("#") ? raw.slice(1) : raw);
    const desc =
      from(window.location.hash).get("error_description") ||
      from(window.location.search).get("error_description");
    if (desc) setMessage(desc);
  }, []);

  const submit = async (event) => {
    event.preventDefault();
    setMessage("");
    if (mode === "signup" && password !== confirmPassword) {
      setMessage("Both passwords must match.");
      return;
    }
    setBusy(true);
    if (mode === "signup") {
      const { data: allowed, error: gateError } = await supabase.rpc("email_can_join", {
        check_email: email.trim(),
      });
      if (gateError || allowed !== true) {
        setBusy(false);
        setMessage(
          gateError
            ? "New shops are invite only. Ask the seller to add your email, then try again."
            : "This email is not invited. The seller has to add it before you can create a shop.",
        );
        return;
      }
    }
    const result = mode === "signup"
      ? await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin } })
      : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (result.error) {
      setMessage(result.error.message);
    } else if (mode === "signup" && !result.data.session) {
      setMessage("Check your email to confirm your account, then sign in.");
    }
  };

  const signInWithGoogle = async () => {
    setBusy(true);
    setMessage("");
    // A successful call normally navigates the page away immediately. If it doesn't
    // (a blocked popup, e.g.), this stops the button being stuck on "Please wait…" forever.
    const stuckTimer = setTimeout(() => {
      setBusy(false);
      setMessage("Google sign-in didn't open — check if your browser blocked a popup, then try again.");
    }, 8000);
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (result?.error) {
      clearTimeout(stuckTimer);
      setMessage(result.error.message || "Google sign-in could not be completed.");
      setBusy(false);
    }
  };

  const sendReset = async (event) => {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });
    setBusy(false);
    if (error) { setMessage(error.message); return; }
    setMessage("Reset link sent — check your email and open the link to set a new password.");
  };

  // Same country-code assumption as waDigits elsewhere in this app: a plain 10-digit
  // number is almost always an Indian mobile, so fill in +91 rather than force the
  // person to type a country code most of them wouldn't think to add.
  const toE164 = (raw) => {
    const trimmed = raw.trim();
    if (trimmed.startsWith("+")) return trimmed.replace(/[\s\-()]/g, "");
    const digits = waDigits(trimmed);
    return digits ? "+" + digits : "";
  };

  const sendPhoneOtp = async (event) => {
    event.preventDefault();
    setMessage("");
    const formatted = toE164(phoneNumber);
    if (!formatted || formatted.length < 11) { setMessage("Enter a valid phone number."); return; }
    setBusy(true);
    const { error } = await supabase.auth.signInWithOtp({ phone: formatted });
    setBusy(false);
    if (error) { setMessage(error.message); return; }
    setPhoneNumber(formatted);
    setOtp("");
    setView("phone-otp");
  };

  const verifyPhoneOtp = async (event) => {
    event.preventDefault();
    setMessage("");
    if (!otp.trim()) { setMessage("Enter the code you received."); return; }
    setBusy(true);
    const { error } = await supabase.auth.verifyOtp({ phone: phoneNumber, token: otp.trim(), type: "sms" });
    setBusy(false);
    if (error) { setMessage(error.message); return; }
    // On success the auth-state listener elsewhere in the app picks up the new
    // session on its own — nothing further to do here.
  };

  const resendPhoneOtp = async () => {
    setBusy(true);
    setMessage("");
    const { error } = await supabase.auth.signInWithOtp({ phone: phoneNumber });
    setBusy(false);
    setMessage(error ? error.message : "Code resent.");
  };

  if (view === "forgot") {
    return (
      <main className="min-h-screen flex items-center justify-center px-5" style={{ backgroundColor: T.bg }}>
        <div className="w-full max-w-sm rounded-lg border p-6" style={{ backgroundColor: T.surface, borderColor: T.border }}>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-md flex items-center justify-center" style={{ backgroundColor: T.brassSoft }}>
              <Frame size={20} style={{ color: T.brass }} />
            </div>
            <div>
              <h1 className="text-lg font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>Reset password</h1>
              <p className="text-xs" style={{ color: T.inkFaint }}>We'll email you a reset link</p>
            </div>
          </div>
          <form onSubmit={sendReset} className="flex flex-col gap-3.5">
            <Field label="Email" required><TextInput type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
            {message && <p className="text-xs leading-5" style={{ color: message.startsWith("Reset link sent") ? T.success : T.danger }}>{message}</p>}
            <PrimaryButton type="submit" full>{busy ? "Please wait…" : "Send reset link"}</PrimaryButton>
            <GhostButton type="button" full onClick={() => { setView("form"); setMessage(""); }}>Back to sign in</GhostButton>
          </form>
        </div>
      </main>
    );
  }

  if (view === "phone-entry") {
    return (
      <main className="min-h-screen flex items-center justify-center px-5" style={{ backgroundColor: T.bg }}>
        <div className="w-full max-w-sm rounded-lg border p-6" style={{ backgroundColor: T.surface, borderColor: T.border }}>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-md flex items-center justify-center" style={{ backgroundColor: T.brassSoft }}>
              <Frame size={20} style={{ color: T.brass }} />
            </div>
            <div>
              <h1 className="text-lg font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>Sign in with phone</h1>
              <p className="text-xs" style={{ color: T.inkFaint }}>For a number that already has an account</p>
            </div>
          </div>
          <form onSubmit={sendPhoneOtp} className="flex flex-col gap-3.5">
            <Field label="Phone number" required>
              <TextInput type="tel" required autoComplete="tel" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="e.g. 98765 43210" />
            </Field>
            {message && <p className="text-xs leading-5" style={{ color: T.danger }}>{message}</p>}
            <PrimaryButton type="submit" full>{busy ? "Sending…" : "Send code"}</PrimaryButton>
            <GhostButton type="button" full onClick={() => { setView("form"); setMessage(""); }}>Back to sign in</GhostButton>
          </form>
        </div>
      </main>
    );
  }

  if (view === "phone-otp") {
    return (
      <main className="min-h-screen flex items-center justify-center px-5" style={{ backgroundColor: T.bg }}>
        <div className="w-full max-w-sm rounded-lg border p-6" style={{ backgroundColor: T.surface, borderColor: T.border }}>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-md flex items-center justify-center" style={{ backgroundColor: T.brassSoft }}>
              <Frame size={20} style={{ color: T.brass }} />
            </div>
            <div>
              <h1 className="text-lg font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>Enter the code</h1>
              <p className="text-xs" style={{ color: T.inkFaint }}>Sent to {phoneNumber}</p>
            </div>
          </div>
          <form onSubmit={verifyPhoneOtp} className="flex flex-col gap-3.5">
            <Field label="6-digit code" required>
              <TextInput type="text" inputMode="numeric" autoComplete="one-time-code" required value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="123456" />
            </Field>
            {message && <p className="text-xs leading-5" style={{ color: message === "Code resent." ? T.success : T.danger }}>{message}</p>}
            <PrimaryButton type="submit" full>{busy ? "Verifying…" : "Verify and sign in"}</PrimaryButton>
            <div className="flex items-center justify-between">
              <button type="button" onClick={resendPhoneOtp} className="text-xs font-medium" style={{ color: T.brass }} disabled={busy}>Resend code</button>
              <button type="button" onClick={() => { setView("phone-entry"); setOtp(""); setMessage(""); }} className="text-xs font-medium" style={{ color: T.inkFaint }}>Change number</button>
            </div>
          </form>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-5" style={{ backgroundColor: T.bg }}>
      <div className="w-full max-w-sm rounded-lg border p-6" style={{ backgroundColor: T.surface, borderColor: T.border }}>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-md flex items-center justify-center" style={{ backgroundColor: T.brassSoft }}>
            <Frame size={20} style={{ color: T.brass }} />
          </div>
          <div>
            <h1 className="text-lg font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>Frame &amp; Gifts Shop</h1>
            <p className="text-xs" style={{ color: T.inkFaint }}>
              {mode === "signup" ? "Use the email the seller added" : "Private shop manager"}
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-1 p-1 rounded-md mb-5" style={{ backgroundColor: T.bg }}>
          {["signin", "signup"].map((item) => (
            <button key={item} type="button" onClick={() => { setMode(item); setMessage(""); setConfirmPassword(""); }} className="py-2 rounded text-sm font-medium" style={{ color: mode === item ? T.ink : T.inkSoft, backgroundColor: mode === item ? T.border : "transparent" }}>
              {item === "signin" ? "Sign in" : "Create account"}
            </button>
          ))}
        </div>
        <form onSubmit={submit} className="flex flex-col gap-3.5">
          <Field label="Email" required><TextInput type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
          <Field label="Password" required><TextInput type="password" required minLength={6} autoComplete={mode === "signin" ? "current-password" : "new-password"} value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
          {mode === "signup" && (
            <Field label="Confirm password" required><TextInput type="password" required minLength={6} autoComplete="new-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} /></Field>
          )}
          {mode === "signin" && (
            <button type="button" onClick={() => { setView("forgot"); setMessage(""); }} className="self-end -mt-1 text-xs font-medium" style={{ color: T.brass }}>
              Forgot password?
            </button>
          )}
          {mode === "signup" && (
            <p className="text-xs leading-5" style={{ color: T.inkFaint }}>
              A new shop opens only if the seller already added this email.
            </p>
          )}
          {message && <p className="text-xs leading-5" style={{ color: message.startsWith("Check") ? T.success : T.danger }}>{message}</p>}
          <PrimaryButton type="submit" full>{busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}</PrimaryButton>
        </form>
        <div className="flex items-center gap-3 my-4"><span className="h-px flex-1" style={{ backgroundColor: T.borderSoft }} /><span className="text-xs" style={{ color: T.inkFaint }}>or</span><span className="h-px flex-1" style={{ backgroundColor: T.borderSoft }} /></div>
        <div className="flex flex-col gap-2">
          <GhostButton onClick={signInWithGoogle} full>Continue with Google</GhostButton>
          <GhostButton onClick={() => { setView("phone-entry"); setMessage(""); }} full>Continue with phone</GhostButton>
        </div>
        <p className="text-xs text-center mt-5 leading-5" style={{ color: T.inkFaint }}>
          Google works only for an email the seller added. Phone is for a number that already has an account.
        </p>
      </div>
    </main>
  );
}


export default function ShopApp() {
  const [theme, setThemeState] = useState(() => {
    if (typeof window === "undefined") return "dark";
    return window.localStorage.getItem("shop-theme") === "light" ? "light" : "dark";
  });
  const setTheme = useCallback((nextTheme) => {
    const next = nextTheme === "light" ? "light" : "dark";
    setThemeState(next);
    try { window.localStorage.setItem("shop-theme", next); } catch {}
  }, []);
  useEffect(() => {
    document.documentElement.classList.add("shop-theme");
    document.documentElement.dataset.shopTheme = theme;
    return () => {
      document.documentElement.classList.remove("shop-theme");
      delete document.documentElement.dataset.shopTheme;
    };
  }, [theme]);
  const [user, setUser] = useState(null);
  const [loadingBrand, setLoadingBrand] = useState(null);
  const viewerIdRef = useRef("");
  useEffect(() => {
    // Hydration starts from the server's empty value; restore the last signed-in
    // business mark immediately, before the session or shop request completes.
    setLoadingBrand(readCachedShopBrand());
  }, []);
  const [authLoading, setAuthLoading] = useState(true);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  // navigator.onLine is a best-effort signal (it can say "online" when you're on a
  // wifi network with no real internet), but it correctly catches the common case —
  // airplane mode, a dropped connection — which is what this is actually for.
  const { lang, setLang, t } = useLanguage();
  const [isOnline, setIsOnline] = useState(typeof navigator === "undefined" ? true : navigator.onLine);
  const [viewingOffline, setViewingOffline] = useState(false);
  // Changes made while disconnected, waiting on this device until they can be sent.
  const [pendingCount, setPendingCount] = useState(0);
  const [pendingSince, setPendingSince] = useState(null);
  const [syncing, setSyncing] = useState(false);
  // Keeps the count and the "how old" stamp in step wherever the queue changes.
  const refreshPending = useCallback((shopId) => {
    if (!shopId) return;
    setPendingCount(shopQueue.pendingCount(shopId));
    setPendingSince(shopQueue.pendingSince(shopId));
  }, []);

  useEffect(() => {
    const goOnline = () => setIsOnline(true);
    const goOffline = () => setIsOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => { window.removeEventListener("online", goOnline); window.removeEventListener("offline", goOffline); };
  }, []);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [settings, setSettings] = useState({ shopName: "Frame & Gifts Shop", shopPhone: "", shopAddress: "" });

  const [tab, setTab] = useState("dashboard");
  const [toast, setToast] = useState(null);
  const [exportingExcel, setExportingExcel] = useState(false);
  const [backupBusy, setBackupBusy] = useState(false);
  const [restoreOpen, setRestoreOpen] = useState(false);
  // How many saves are in flight right now, so the header can say plainly whether
  // everything is stored or something is still on its way up.
  const [savingCount, setSavingCount] = useState(0);
  // Same count, readable from inside callbacks that were created before the latest
  // render — used to hold off live-sync refreshes while your own save is in flight.
  const savingRef = useRef(0);
  const [savedAt, setSavedAt] = useState(null);

  const [productModal, setProductModal] = useState(null);
  const [orderModal, setOrderModal] = useState(null);
  const [customerModal, setCustomerModal] = useState(null);
  const [importKind, setImportKind] = useState(null);
  const [expenseModal, setExpenseModal] = useState(null);
  const [restockModal, setRestockModal] = useState(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [customerDetail, setCustomerDetail] = useState(null);
  const [productDetail, setProductDetail] = useState(null);
  const [receiptOrder, setReceiptOrder] = useState(null);
  const [returnOrder, setReturnOrder] = useState(null);
  const [confirmState, setConfirmState] = useState(null);

  const [stockCatFilter, setStockCatFilter] = useState("All");
  const [stockLevelFilter, setStockLevelFilter] = useState("All");
  const [stockSort, setStockSort] = useState("recent");
  const [orderStatusFilterTab, setOrderStatusFilterTab] = useState("All");
  const [orderDateFilter, setOrderDateFilter] = useState("All time");
  const [orderRangeStart, setOrderRangeStart] = useState("");
  const [orderRangeEnd, setOrderRangeEnd] = useState("");
  const [orderPaymentFilter, setOrderPaymentFilter] = useState("All");
  const [orderProductFilter, setOrderProductFilter] = useState("");
  const [customerBalanceFilter, setCustomerBalanceFilter] = useState("All");
  const [customerSort, setCustomerSort] = useState("spend");
  const [expenseCatFilter, setExpenseCatFilter] = useState("All");
  const [financeDateFilter, setFinanceDateFilter] = useState("All time");
  const [financeRangeStart, setFinanceRangeStart] = useState("");
  const [financeRangeEnd, setFinanceRangeEnd] = useState("");

  const [recovery, setRecovery] = useState(false);
  // The shop's actual data lives under its owner's auth id (unchanged — this is exactly
  // today's key). A staff member's own auth id is different from that, so this tracks
  // which id to actually load/save/subscribe against. Defaults to "myself", which is
  // correct for every solo owner and is also the safe fallback if the staff-logins
  // migration hasn't been run yet — this function never assumes shop_members exists.
  const [effectiveShopId, setEffectiveShopId] = useState(null);
  const isOwner = !!user && effectiveShopId === user.id;
  const [showInviteShops, setShowInviteShops] = useState(false);
  useEffect(() => {
    if (!user?.email) {
      setShowInviteShops(false);
      return;
    }
    let cancelled = false;
    supabase.rpc("is_platform_admin").then(({ data, error }) => {
      if (cancelled) return;
      setShowInviteShops(!error && data === true);
    });
    return () => {
      cancelled = true;
    };
  }, [user]);
  const signOut = useCallback(() => {
    clearLastCachedShopBrand();
    return supabase.auth.signOut();
  }, []);

  const resolveShopId = useCallback(async (uid, email) => {
    try {
      // One request instead of two: ask who this person belongs to, and only write
      // anything back if there is genuinely an unclaimed invite for their email.
      // Claiming an invite happens once in a lifetime; it used to cost a write on
      // every single app open.
      const { data: rows, error } = await supabase
        .from("shop_members")
        .select("shop_owner_id, member_user_id, invited_email")
        .or(email ? `member_user_id.eq.${uid},and(invited_email.eq.${email},member_user_id.is.null)` : `member_user_id.eq.${uid}`);
      if (error) throw error;
      const joined = (rows || []).find((r) => r.member_user_id === uid);
      const pending = (rows || []).find((r) => !r.member_user_id);
      if (!joined && pending) {
        await supabase
          .from("shop_members")
          .update({ member_user_id: uid, joined_at: new Date().toISOString() })
          .eq("invited_email", email)
          .is("member_user_id", null);
      }
      const resolved = (joined || pending)?.shop_owner_id || uid;
      cacheShopIdFor(uid, resolved);
      return resolved;
    } catch {
      // Couldn't actually verify — offline, migration not run, or some other hiccup.
      // Signal "unknown" (null) rather than guessing uid: a caller sitting on a known
      // good cached value (a staff member, say) must not mistake "I couldn't check
      // right now" for "you're not staff after all" and discard perfectly good data.
      return null;
    }
  }, []);

  useEffect(() => {
    // The session already on this device answers "who is signed in" with no network
    // call at all, so the app can start loading immediately. getUser() still runs
    // right after to re-verify with the server, just not in anyone's way.
    supabase.auth.getSession().then(({ data }) => {
      const sessionUser = data.session?.user || null;
      if (sessionUser) {
        viewerIdRef.current = sessionUser.id;
        setActiveUserId(sessionUser.id);
        setLoadingBrand(readCachedShopBrand(sessionUser.id));
        setUser((prev) => prev || sessionUser);
        setAuthLoading(false);
      }
    });
    supabase.auth.getUser().then(({ data }) => {
      viewerIdRef.current = data.user?.id || "";
      setActiveUserId(data.user?.id || "");
      if (data.user?.id) setLoadingBrand(readCachedShopBrand(data.user.id));
      setUser(data.user || null);
      setAuthLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY") setRecovery(true);
      viewerIdRef.current = session?.user?.id || "";
      setActiveUserId(session?.user?.id || "");
      setLoadingBrand(session?.user?.id ? readCachedShopBrand(session.user.id) : null);
      setLoading(Boolean(session?.user));
      setUser(session?.user || null);
      setAuthLoading(false);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  // A stable function (not just inline in the effect) so the "Try again" button on a
  // failed load can call the exact same logic instead of duplicating it.
  const loadShopData = useCallback(async (uid) => {
    setLoadError(false);
    // Paint the last known good copy immediately so the shop is usable in a blink,
    // then quietly refresh it from the server. Waiting on the network before showing
    // anything is what made opening the app feel slow on a phone connection.
    const snapshot = readCachedShopData(uid);
    if (snapshot && (snapshot.products?.length || snapshot.orders?.length || snapshot.customers?.length || snapshot.expenses?.length)) {
      setProducts(snapshot.products || []);
      setOrders(snapshot.orders || []);
      setCustomers(snapshot.customers || []);
      setExpenses(snapshot.expenses || []);
      if (snapshot.settings) setSettings(snapshot.settings);
      if (snapshot.settings) cacheShopBrand(viewerIdRef.current || uid, snapshot.settings);
      shopRepo.primeSnapshots(snapshot);
      setViewingOffline(false);
      setLoading(false);
    }
    try {
      // Everything comes from the normalised tables now; shopRepo reassembles the
      // rows into the same arrays the screens have always worked with.
      const loaded = await shopRepo.loadShop(uid);
      const isEmpty =
        !loaded.products.length && !loaded.orders.length && !loaded.customers.length && !loaded.expenses.length;
      if (isEmpty) {
        // Brand-new account. A prior purely-local build of this app (before accounts
        // existed) may have left data in this browser; pull it in once as a starting
        // point rather than silently discarding it.
        const localValue = (key, fallback) => {
          try {
            const raw = window.localStorage.getItem(key);
            return raw ? JSON.parse(raw) : fallback;
          } catch {
            return fallback;
          }
        };
        loaded.products = localValue("shop-products", []);
        loaded.orders = localValue("shop-orders", []);
        loaded.customers = localValue("shop-customers", []);
        loaded.expenses = localValue("shop-expenses", []);
        loaded.settings = loaded.settings || localValue("shop-settings", { shopName: "Frame & Gifts Shop", shopPhone: "", shopAddress: "" });
        await shopRepo.ensureShopRow(uid, loaded.settings);
        if (loaded.products.length || loaded.orders.length || loaded.customers.length || loaded.expenses.length) {
          await shopRepo.saveKinds(uid, {
            products: loaded.products,
            customers: loaded.customers,
            expenses: loaded.expenses,
            orders: loaded.orders,
          });
        }
      }
      shopRepo.primeSnapshots(loaded);
      setProducts(loaded.products);
      setOrders(loaded.orders);
      setCustomers(loaded.customers);
      setExpenses(loaded.expenses);
      setSettings(loaded.settings);
      cacheShopBrand(viewerIdRef.current || uid, loaded.settings);
      cacheShopData(uid, loaded);
      setViewingOffline(false);
      setLoading(false);
    } catch (e) {
      // Previously a failed load fell through to empty arrays with no error shown —
      // on a bad connection that looked exactly like "you have no data", which is a
      // much scarier thing to see than "couldn't connect, try again". Now: if there's
      // a local cache from a prior successful load, show that (clearly marked as
      // offline/cached) instead of either a scary error or a blank shop. Only fall
      // back to the hard error screen if there's truly nothing to show at all.
      const cached = readCachedShopData(uid);
      if (cached) {
        setProducts(cached.products || []);
        setOrders(cached.orders || []);
        setCustomers(cached.customers || []);
        setExpenses(cached.expenses || []);
        setSettings(cached.settings || { shopName: "Frame & Gifts Shop", shopPhone: "", shopAddress: "" });
        setViewingOffline(true);
        setLoadError(false);
      } else {
        setLoadError(true);
      }
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    setLoading(true);
    let cancelled = false;
    (async () => {
      const cached = cachedShopIdFor(user.id);
      if (cached) {
        // Skip straight to loading real data with what we learned last time — no
        // reason to make every single app open wait on two round trips whose answer
        // hasn't changed since the last time we checked.
        setEffectiveShopId(cached);
        setActiveUserId(cached);
        loadShopData(cached);
      }
      const resolved = await resolveShopId(user.id, user.email);
      if (cancelled) return;
      if (resolved === null) {
        // Couldn't verify right now (offline, migration not run, etc). If we had no
        // cache to begin with, fall back to "I own my own shop" — the same default
        // this app has always used when resolution can't be determined. If we did
        // have a cache, it's already loading above; a failed verification attempt is
        // not evidence the cached answer was wrong, so leave it alone.
        if (!cached) {
          setEffectiveShopId(user.id);
          setActiveUserId(user.id);
          loadShopData(user.id);
        }
      } else if (resolved !== cached) {
        // Either this is the very first sign-in ever (no cache yet), or something
        // genuinely changed since last time (newly invited to a shop, removed from
        // one) — reload with the correct id rather than silently keep using a stale
        // guess.
        setEffectiveShopId(resolved);
        setActiveUserId(resolved);
        loadShopData(resolved);
      }
    })();
    return () => { cancelled = true; };
  }, [user?.id, resolveShopId, loadShopData]);

  // Connectivity returning is the moment to actually go fetch what changed — without
  // this, coming back online would silently leave the app showing whatever was cached
  // from before the disconnect until the person happened to refresh the page.
  useEffect(() => {
    if (isOnline && (viewingOffline || loadError) && effectiveShopId) {
      loadShopData(effectiveShopId);
    }
  }, [isOnline, effectiveShopId, loadShopData]);

  // Anything saved while disconnected is sent the moment the connection is back,
  // record by record, and the shop is reloaded afterwards so everyone's changes
  // (yours and anyone else's from that period) are shown together.
  const syncPending = useCallback(async (shopId) => {
    if (!shopId || !shopQueue.hasPending(shopId)) return;
    setSyncing(true);
    try {
      const sent = await shopQueue.flush(shopId);
      refreshPending(shopId);
      if (sent) {
        await loadShopData(shopId);
        showToastRef.current?.(`${sent} offline change${sent === 1 ? "" : "s"} synced`);
      }
    } catch {
      // Still no usable connection — the queue is untouched and will be retried.
      refreshPending(shopId);
    } finally {
      setSyncing(false);
    }
  }, [loadShopData]);

  useEffect(() => {
    if (!effectiveShopId) return;
    refreshPending(effectiveShopId);
    if (isOnline) syncPending(effectiveShopId);
  }, [isOnline, effectiveShopId, syncPending]);


  // Separate from the load effect above so the realtime channel only gets torn down
  // and rebuilt when the resolved shop id actually changes, not on every render.
  // Each list is its own table now, so one action on another device can produce a
  // burst of row events — they're coalesced into a single refresh a moment later
  // instead of refetching the shop once per row.
  useEffect(() => {
    if (!effectiveShopId) return;
    let timer = null;
    const refresh = () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(async () => {
        // The row events caused by your own save are already on screen — refetching
        // the shop for them is pure waste (and can briefly flicker in stale values).
        // Wait until your own writes have finished, then do one refresh.
        if (savingRef.current > 0) { refresh(); return; }
        try {
          const updated = await shopRepo.loadShop(effectiveShopId);
          shopRepo.primeSnapshots(updated);
          setProducts(updated.products);
          setOrders(updated.orders);
          setCustomers(updated.customers);
          setExpenses(updated.expenses);
          setSettings(updated.settings);
          cacheShopData(effectiveShopId, updated);
        } catch {
          // A missed live update is not worth interrupting anyone over; the next
          // change (or a reload) will bring things back in sync.
        }
      }, 400);
    };
    let channel = supabase.channel(`shop-live-${effectiveShopId}`);
    shopRepo.REALTIME_TABLES.forEach((table) => {
      channel = channel.on("postgres_changes", { event: "*", schema: "public", table }, refresh);
    });
    channel.subscribe();
    return () => {
      if (timer) clearTimeout(timer);
      supabase.removeChannel(channel);
    };
  }, [effectiveShopId]);

  const showToast = useCallback((message, kind = "success") => {
    setToast({ message, kind });
    setTimeout(() => setToast(null), 2600);
  }, []);
  const showToastRef = useRef(null);
  useEffect(() => { showToastRef.current = showToast; }, [showToast]);

  // Every save goes through here: saved, kept on the device for later, or failed.
  const reportSave = useCallback((ok) => {
    if (ok === true) return;
    if (ok === "queued") {
      refreshPending(activeUserId);
      showToast("Saved on this device — will sync when you're back online");
      return;
    }
    showToast(saveFailedMessage(), "error");
  }, [showToast]);


  // A save can fail two very different ways: the session dropped (needs signing back
  // in) or the network hiccuped (usually resolves itself). Telling them apart matters —
  // one needs the person to act, the other doesn't.
  const saveFailedMessage = () => (!activeUserId ? "You've been signed out — please sign in again to keep saving" : "Could not save — check your connection");

  // Wraps any save so the header can show "Saving…" while it's in flight and
  // "All changes saved" the moment it lands.
  const tracked = useCallback(async (run) => {
    setSavingCount((n) => n + 1);
    savingRef.current += 1;
    try {
      const ok = await run();
      if (ok === true) setSavedAt(Date.now());
      return ok;
    } finally {
      setSavingCount((n) => Math.max(0, n - 1));
      savingRef.current = Math.max(0, savingRef.current - 1);
    }
  }, []);

  const persist = useCallback(async (key, value, setter) => {
    setter(value);
    const ok = await tracked(() => saveKey(key, value));
    reportSave(ok);
  }, [reportSave, tracked]);

  // entries: array of [storageKey, value, setter]. Applies every setter immediately
  // (same optimistic feel as persist()), then writes all the columns in one upsert —
  // see saveMultipleKeys for why this matters over calling persist() several times.
  const persistMultiple = useCallback(async (entries) => {
    entries.forEach(([, value, setter]) => setter(value));
    const payload = {};
    entries.forEach(([key, value]) => { payload[DATA_COLUMNS[key]] = value; });
    const ok = await tracked(() => saveMultipleKeys(payload));
    reportSave(ok);
  }, [reportSave, tracked]);

  // For *new* records specifically: re-fetch the latest saved list right before
  // appending, instead of trusting local state. Two people adding orders at the
  // same time from different devices (phone + laptop) is a normal way to use a
  // shop tool, and storage is last-write-wins — refetching just before the append
  // means device B's save merges onto device A's addition instead of erasing it.
  // (Simultaneous *edits* to the exact same record can still overwrite each other —
  // there's no true conflict resolution here, just a mitigation for the common case.)
  const addItem = useCallback(async (key, newItem, setter, localArray) => {
    // Show it straight away, then reconcile with the server copy in the background,
    // so adding a record never waits on a round trip.
    const optimistic = [...localArray, newItem];
    setter(optimistic);
    tracked(async () => {
      const latest = await loadKey(key, localArray);
      const merged = latest.some((x) => x.id === newItem.id) ? latest : [...latest, newItem];
      setter(merged);
      return await saveKey(key, merged);
    }).then(reportSave);
    return optimistic;
  }, [reportSave, tracked]);


  /* ---------------- computed data ---------------- */
  // "Live" (counted) orders exclude Cancelled ones from every stock/financial total —
  // a cancelled order still exists in the Orders list (so history isn't lost) but
  // shouldn't reduce stock, count toward sales, or inflate a customer's spend.
  const isLive = (o) => o.status !== "Cancelled" && o.status !== "Returned";

  const productsComputed = useMemo(() => {
    return products.map((p) => {
      let sold = 0;
      orders.forEach((o) => {
        if (!isLive(o)) return;
        (o.items || []).forEach((it) => { if (it.productId === p.id) sold += num(it.qty); });
      });
      const restocked = (p.restocks || []).reduce((s, r) => s + num(r.qty), 0);
      const received = num(p.openingStock) + restocked;
      const current = received - sold;
      return { ...p, sold, received, restocked, current, value: current * num(p.costPrice), low: current <= num(p.reorderLevel) };
    });
  }, [products, orders]);

  const orderSubtotal = useCallback((o) => (o.items || []).reduce((s, it) => s + num(it.qty) * num(it.unitPrice), 0), []);
  // Cost is read from a snapshot taken on the order item at the moment it was sold
  // (it.unitCost). This keeps historical profit accurate even if a product's cost
  // price changes later, or the product is discontinued/deleted — both would otherwise
  // silently rewrite past P&L if cost were looked up live from the current catalogue.
  const orderCOGS = useCallback(
    (o) => (o.items || []).reduce((s, it) => {
      if (it.unitCost !== undefined && it.unitCost !== "" && it.unitCost !== null) {
        return s + num(it.qty) * num(it.unitCost);
      }
      const prod = it.productId ? products.find((p) => p.id === it.productId) : null;
      return s + (prod ? num(it.qty) * num(prod.costPrice) : 0);
    }, 0),
    [products]
  );

  const ordersComputed = useMemo(
    () => orders.map((o) => {
      const subtotal = orderSubtotal(o);
      const discount = orderDiscount(o, subtotal);
      const total = subtotal - discount;
      return { ...o, subtotal, discount, total, balance: total - num(o.advance) };
    }),
    [orders, orderSubtotal]
  );

  const customersComputed = useMemo(() => {
    return customers.map((c) => {
      const own = ordersComputed.filter((o) => normalizePhone(o.customerPhone) === normalizePhone(c.phone) && isLive(o));
      const totalSpent = own.reduce((s, o) => s + o.total, 0);
      const outstanding = own.reduce((s, o) => s + o.balance, 0);
      const lastOrderDate = own.reduce((max, o) => (!max || o.date > max ? o.date : max), "");
      return { ...c, totalOrders: own.length, totalSpent, outstanding, lastOrderDate };
    });
  }, [customers, ordersComputed]);

  const finance = useMemo(() => {
    const live = ordersComputed.filter(isLive);
    const totalSales = live.reduce((s, o) => s + o.total, 0);
    const totalAdvance = live.reduce((s, o) => s + num(o.advance), 0);
    const totalOutstanding = live.reduce((s, o) => s + o.balance, 0);
    const cogs = orders.filter(isLive).reduce((s, o) => s + orderCOGS(o), 0);
    const totalExpenses = expenses.reduce((s, e) => s + num(e.amount), 0);
    const grossProfit = totalSales - cogs;
    const netProfit = grossProfit - totalExpenses;
    return { totalSales, totalAdvance, totalOutstanding, cogs, totalExpenses, grossProfit, netProfit };
  }, [ordersComputed, orders, orderCOGS, expenses]);

  const dashboard = useMemo(() => {
    const today = todayStr();
    const monthKey = today.slice(0, 7);
    const live = ordersComputed.filter(isLive);
    const todaysOrders = live.filter((o) => o.date === today);
    const todaySales = todaysOrders.reduce((s, o) => s + o.total, 0);
    const monthSales = live.filter((o) => (o.date || "").slice(0, 7) === monthKey).reduce((s, o) => s + o.total, 0);
    const pending = live.filter((o) => o.status === "Pending" || o.status === "In Progress").length;
    const ready = live.filter((o) => o.status === "Ready").length;
    const cancelled = ordersComputed.filter((o) => o.status === "Cancelled").length;
    const lowStock = productsComputed.filter((p) => p.low);
    const soon = new Date();
    soon.setDate(soon.getDate() + 3);
    const soonStr = toLocalISODate(soon);
    const dueSoon = live
      .filter((o) => o.status !== "Delivered" && o.deliveryDate && o.deliveryDate <= soonStr)
      .sort((a, b) => (a.deliveryDate > b.deliveryDate ? 1 : -1));

    // Oldest outstanding balance first — the natural order for "who should I actually
    // follow up with today", not just a list of who owes money.
    const paymentReminders = live
      .filter((o) => o.balance > 0)
      .sort((a, b) => (a.date < b.date ? -1 : 1))
      .map((o) => ({ ...o, daysOutstanding: Math.max(0, Math.floor((new Date(today) - new Date(o.date)) / 86400000)) }));

    // Money actually taken in today, split by payment mode — for closing the cash
    // drawer. Note: this only reflects payments recorded against orders *placed*
    // today. A balance paid off today for an older order isn't timestamped
    // separately in this data model, so it won't appear here — see Settings notes.
    const collectionsToday = { Cash: 0, UPI: 0, Card: 0 };
    todaysOrders.forEach((o) => { orderPayments(o).forEach((p) => { collectionsToday[p.mode] = (collectionsToday[p.mode] || 0) + num(p.amount); }); });

    const week = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = toLocalISODate(d);
      const total = live.filter((o) => o.date === key).reduce((s, o) => s + o.total, 0);
      week.push({ day: d.toLocaleDateString("en-IN", { weekday: "short" }), sales: total });
    }
    return { todaySales, monthSales, pending, ready, cancelled, lowStock, dueSoon, paymentReminders, week, collectionsToday };
  }, [ordersComputed, productsComputed]);

  const customerOptions = useMemo(
    () => customers.map((c) => ({ name: c.name, phone: c.phone })),
    [customers]
  );

  /* ---------------- CRUD ---------------- */
  // Every form's details are checked against the same rules the database enforces,
  // so a mistake comes back as a plain sentence instead of a failed save.
  const invalid = (schema, data) => {
    const err = firstError(schema, data);
    if (err) showToast(err, "error");
    return Boolean(err);
  };

  const saveProduct = async (data) => {
    if (invalid(productSchema, data)) return;
    const exists = products.some((p) => p.id === data.id);
    if (exists) {
      persist("shop-products", products.map((p) => (p.id === data.id ? data : p)), setProducts);
    } else {
      await addItem("shop-products", data, setProducts, products);
    }
    showToast(exists ? "Product updated" : "Product added");
    setProductModal(null);
  };
  // Removing records is owner-only: staff bill and update orders all day, but a
  // deleted product, order, customer or expense is gone from the shop's history.
  // Cost prices and profit are the owner's business figures; staff see stock,
  // orders and customers but not what the shop pays or earns.
  const canSeeMoney = isOwner;
  const visibleNav = canSeeMoney ? NAV : NAV.filter((n) => n.id !== "finance");
  useEffect(() => { if (!canSeeMoney && tab === "finance") setTab("dashboard"); }, [canSeeMoney, tab]);

  const canDelete = () => {
    if (isOwner) return true;
    showToast("Only the shop owner can delete records", "error");
    return false;
  };

  const deleteProduct = (id) => {
    if (!canDelete()) return;
    persist("shop-products", products.filter((p) => p.id !== id), setProducts);
    showToast("Product deleted");
    setConfirmState(null);
  };

  const saveRestock = async (product, entry) => {
    if (invalid(restockSchema, entry)) return;
    const addEntry = (list) => list.map((p) => (p.id === product.id ? { ...p, restocks: [...(p.restocks || []), entry] } : p));
    setProducts(addEntry(products));
    showToast(`+${entry.qty} added to ${product.name}`);
    setRestockModal(null);
    tracked(async () => {
      const latest = await loadKey("shop-products", products);
      const next = addEntry(latest);
      setProducts(next);
      return await saveKey("shop-products", next);
    }).then(reportSave);
  };


  const ensureCustomer = (name, phone, existingList) => {
    const norm = normalizePhone(phone);
    if (!norm) return existingList;
    const found = existingList.find((c) => normalizePhone(c.phone) === norm);
    if (found) return existingList;
    return [...existingList, { id: genId("CUST"), name, phone: norm, address: "", notes: "" }];
  };

  const saveOrder = async (data) => {
    if (invalid(orderFormSchema, data)) return;
    const exists = orders.some((o) => o.id === data.id);
    // The order, its items and its payments now go to the server as one
    // all-or-nothing operation, and a new order's number is handed out by the
    // shop's own counter — so a half-saved order or two orders sharing a number
    // can't happen, even with several people saving at the same moment.
    // On an edit the number is never reissued: once it's gone out on a receipt
    // it has to stay fixed, even if the order's date is changed afterwards.
    let queued = false;
    const offline = typeof navigator !== "undefined" && navigator.onLine === false;
    try {
      if (offline) throw new Error("offline");
      const saved = await shopRepo.saveOrderAtomic(activeUserId, data, { assignOrderNo: !exists });
      data = saved;
      setOrders(exists ? orders.map((o) => (o.id === saved.id ? saved : o)) : [...orders, saved]);
    } catch (e) {
      if (!offline && !isConnectionError(e)) {
        showToast(e?.message || saveFailedMessage(), "error");
        return;
      }
      // No connection: the order is kept on this device. A brand new one can't be
      // given its real number yet — that comes from the shop's counter on the
      // server — so it's marked pending until it syncs.
      queued = true;
      const local = exists ? data : { ...data, orderNo: shopRepo.PENDING_ORDER_NO };
      const nextOrders = exists ? orders.map((o) => (o.id === local.id ? local : o)) : [...orders, local];
      data = local;
      setOrders(nextOrders);
      shopQueue.enqueue(activeUserId, "orders", nextOrders);
      refreshPending(activeUserId);
    }
    if (data.customerPhone) {
      // Adding the customer to the address book happens behind the scenes — the
      // order is already saved, so the dialog shouldn't wait for it.
      const orderData = data;
      (async () => {
        const latestCustomers = await loadKey("shop-customers", customers);
        const nextCustomers = ensureCustomer(orderData.customerName, orderData.customerPhone, latestCustomers);
        if (nextCustomers !== latestCustomers) {
          setCustomers(nextCustomers);
          saveKey("shop-customers", nextCustomers);
        } else {
          setCustomers(latestCustomers);
        }
      })();
    }

    showToast(queued ? "Saved on this device — will sync when you're back online" : exists ? "Order updated" : "Order created");
    setOrderModal(null);
  };
  const deleteOrder = (id) => {
    if (!canDelete()) return;
    persist("shop-orders", orders.filter((o) => o.id !== id), setOrders);
    showToast("Order deleted");
    setConfirmState(null);
  };
  // Opens the order form pre-filled from an existing order — for a repeat customer
  // ordering the same thing again — but as a genuinely new, separate order: fresh id
  // (so isEdit is false and it saves as a new record, not overwriting the original),
  // today's date, no payment carried over, and nothing return-specific inherited.
  const duplicateOrder = (order) => {
    setOrderModal({
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      orderType: order.orderType,
      items: (order.items || []).map((it) => ({ ...it, rowId: genId("ROW") })),
      discountType: order.discountType,
      discountValue: order.discountValue,
      date: todayStr(),
      advance: "",
      paymentMode: "Cash",
      payments: [],
      status: "Pending",
      deliveryDate: "",
      notes: "",
    });
  };
  const quickStatus = (order, status, extra = {}) => {
    persist("shop-orders", orders.map((o) => (o.id === order.id ? { ...o, status, ...extra } : o)), setOrders);
  };
  // Every other status change is low-stakes and instant. Cancelled pulls an order out
  // of sales/stock/customer totals with one click, so it gets a confirmation. Returned
  // does the same *and* needs real data captured (how much came back, why) — a plain
  // yes/no would lose that, so it gets its own small form instead.
  const handleQuickStatus = (order, status) => {
    if (status === "Cancelled" && order.status !== "Cancelled") {
      setConfirmState({
        type: "cancelOrder",
        text: `Mark order ${order.orderNo} as Cancelled? It'll stay in your records but won't count toward stock, sales or customer totals anymore.`,
        payload: { order, status },
      });
    } else if (status === "Returned" && order.status !== "Returned") {
      setReturnOrder(order);
    } else {
      quickStatus(order, status);
    }
  };

  const saveCustomer = async (data) => {
    if (invalid(customerSchema, data)) return;
    const exists = customers.some((c) => c.id === data.id);
    if (exists) {
      persist("shop-customers", customers.map((c) => (c.id === data.id ? data : c)), setCustomers);
    } else {
      await addItem("shop-customers", data, setCustomers, customers);
    }
    showToast(exists ? "Customer updated" : "Customer added");
    setCustomerModal(null);
  };
  const deleteCustomer = (id) => {
    if (!canDelete()) return;
    persist("shop-customers", customers.filter((c) => c.id !== id), setCustomers);
    showToast("Customer deleted");
    setConfirmState(null);
  };

  // Bulk import: the preview has already decided, row by row, what is new and what
  // matches an existing record, so here we only merge and save the whole list once.
  const runImport = async (kind, accepted) => {
    if (!accepted.length) { setImportKind(null); return; }
    const isProducts = kind === "products";
    const list = isProducts ? products : customers;
    const byId = new Map(list.map((r) => [r.id, r]));
    accepted.forEach(({ rec }) => byId.set(rec.id, rec));
    const merged = Array.from(byId.values());
    await persist(isProducts ? "shop-products" : "shop-customers", merged, isProducts ? setProducts : setCustomers);
    const added = accepted.filter((r) => r.status === "new").length;
    const updated = accepted.length - added;
    showToast(`Imported ${added} new and updated ${updated} ${isProducts ? "product" : "customer"}${accepted.length === 1 ? "" : "s"}`);
    setImportKind(null);
  };



  const saveExpense = async (data) => {
    if (invalid(expenseSchema, data)) return;
    const exists = expenses.some((e) => e.id === data.id);
    if (exists) {
      persist("shop-expenses", expenses.map((e) => (e.id === data.id ? data : e)), setExpenses);
    } else {
      await addItem("shop-expenses", data, setExpenses, expenses);
    }
    showToast(exists ? "Expense updated" : "Expense added");
    setExpenseModal(null);
  };
  const deleteExpense = (id) => {
    if (!canDelete()) return;
    persist("shop-expenses", expenses.filter((e) => e.id !== id), setExpenses);
    showToast("Expense deleted");
    setConfirmState(null);
  };

  const saveSettings = (data) => {
    // Shop settings (name, logo, receipt details) belong to the owner — a staff
    // member signed into the same shop can use it, not rebrand it.
    if (!isOwner) { showToast("Only the shop owner can change shop settings", "error"); return; }
    if (invalid(settingsSchema, data)) return;
    cacheShopBrand(user?.id, data);
    setLoadingBrand(data);
    persist("shop-settings", data, setSettings);
    showToast("Settings saved");
    setSettingsOpen(false);
  };

  // Separate from saveSettings so uploading a logo doesn't snap the Settings modal
  // shut — the person should see the preview land before deciding what's next.
  const saveLogo = async (dataUrl) => {
    const next = { ...settings, logoDataUrl: dataUrl };
    setSettings(next);
    cacheShopBrand(user?.id, next);
    setLoadingBrand(next);
    const ok = await saveKey("shop-settings", next);
    if (!ok) showToast("Could not save the logo — check your connection", "error");
    else showToast(dataUrl ? "Logo updated" : "Logo removed");
  };

  const clearAllData = () => {
    persistMultiple([
      ["shop-products", [], setProducts],
      ["shop-orders", [], setOrders],
      ["shop-customers", [], setCustomers],
      ["shop-expenses", [], setExpenses],
    ]);
    showToast("All data cleared");
    setConfirmState(null);
    setSettingsOpen(false);
  };

  const [teamMembers, setTeamMembers] = useState([]);
  const [teamBusy, setTeamBusy] = useState(false);
  const loadTeamMembers = useCallback(async () => {
    if (!effectiveShopId) return;
    try {
      const { data, error } = await supabase.from("shop_members").select("*").eq("shop_owner_id", effectiveShopId).order("invited_at", { ascending: true });
      if (error) throw error;
      setTeamMembers(data || []);
    } catch {
      // shop_members likely doesn't exist yet (migration not run) — the Team section
      // itself explains this rather than failing silently, see SettingsModal.
      setTeamMembers(null);
    }
  }, [effectiveShopId]);
  // The team list is only ever shown inside Settings, so it's fetched when Settings
  // is opened rather than adding a request to every app open.
  useEffect(() => { if (isOwner && settingsOpen) loadTeamMembers(); }, [isOwner, settingsOpen, loadTeamMembers]);

  const inviteStaff = async (email) => {
    setTeamBusy(true);
    try {
      const { error } = await supabase.from("shop_members").insert({ shop_owner_id: effectiveShopId, invited_email: email.trim().toLowerCase() });
      if (error) throw error;
      await loadTeamMembers();
      showToast("Invited — ask them to sign up using this exact email");
    } catch (e) {
      showToast(e?.message?.includes("duplicate") ? "Already invited" : "Could not add — check the migration has been run", "error");
    } finally {
      setTeamBusy(false);
    }
  };
  const removeStaff = async (id) => {
    setTeamBusy(true);
    try {
      const { error } = await supabase.from("shop_members").delete().eq("id", id);
      if (error) throw error;
      await loadTeamMembers();
      showToast("Removed");
    } catch {
      showToast("Could not remove — try again", "error");
    } finally {
      setTeamBusy(false);
    }
  };

  const seedSampleData = () => {
    const d = (offset) => {
      const dt = new Date();
      dt.setDate(dt.getDate() + offset);
      return toLocalISODate(dt);
    };
    const demoProducts = [
      { id: "DEMO-P1", sku: "WF-001", category: "Wooden Frame", name: "Classic Wooden Photo Frame", size: "8x10 inch", customization: "Name engraving available", costPrice: 250, sellingPrice: 450, openingStock: 20, reorderLevel: 5, restocks: [{ id: "DEMO-RS1", date: d(-8), qty: 10, note: "From supplier, invoice #45" }] },
      { id: "DEMO-P2", sku: "WF-002", category: "Wooden Frame", name: "Rustic Barnwood Frame", size: "5x7 inch", customization: "Distressed finish", costPrice: 180, sellingPrice: 350, openingStock: 15, reorderLevel: 5, restocks: [] },
      { id: "DEMO-P3", sku: "AF-001", category: "Acrylic Frame", name: "Crystal Clear Acrylic Frame", size: "6x8 inch", customization: "Floating mount", costPrice: 200, sellingPrice: 380, openingStock: 12, reorderLevel: 4, restocks: [] },
      { id: "DEMO-P4", sku: "AF-002", category: "Acrylic Frame", name: "Acrylic Block Frame", size: "4x6 inch", customization: "—", costPrice: 150, sellingPrice: 300, openingStock: 3, reorderLevel: 5, restocks: [] },
      { id: "DEMO-P5", sku: "LF-001", category: "LED Frame", name: "LED Photo Frame with Remote", size: "10x12 inch", customization: "Colour-changing lights", costPrice: 600, sellingPrice: 1100, openingStock: 8, reorderLevel: 3, restocks: [] },
      { id: "DEMO-P6", sku: "LF-002", category: "LED Frame", name: "LED Marquee Name Sign", size: "Custom", customization: "Custom text", costPrice: 450, sellingPrice: 900, openingStock: 2, reorderLevel: 3, restocks: [] },
      { id: "DEMO-P7", sku: "GI-001", category: "Gift Item", name: "Personalized Photo Mug", size: "Standard", customization: "Photo printing", costPrice: 120, sellingPrice: 250, openingStock: 25, reorderLevel: 8, restocks: [] },
      { id: "DEMO-P8", sku: "GI-002", category: "Gift Item", name: "Engraved Keychain", size: "Small", customization: "Name engraving", costPrice: 40, sellingPrice: 120, openingStock: 30, reorderLevel: 10, restocks: [] },
    ];
    const costOf = (id) => demoProducts.find((p) => p.id === id).costPrice;
    const demoCustomers = [
      { id: "DEMO-C1", name: "Rahul Sharma", phone: "9876543210", address: "MG Road, Pune", notes: "Prefers wooden frames" },
      { id: "DEMO-C2", name: "Priya Patel", phone: "9823456712", address: "Baner, Pune", notes: "" },
      { id: "DEMO-C3", name: "Amit Verma", phone: "9765432109", address: "Kothrud, Pune", notes: "Repeat customer — gifts for office" },
      { id: "DEMO-C4", name: "Sneha Iyer", phone: "9654321098", address: "Viman Nagar, Pune", notes: "" },
    ];
    const item = (productId, name, category, qty, unitPrice, row) => ({ rowId: "DEMO-ROW-" + row, productId, name, category, qty, unitPrice, unitCost: costOf(productId) });
    const demoOrders = [
      { id: "DEMO-O1", orderNo: "ORD-1001", date: d(0), customerName: "Rahul Sharma", customerPhone: "9876543210", orderType: "Walk-in", items: [item("DEMO-P1", "Classic Wooden Photo Frame", "Wooden Frame", 1, 450, 1)], discountType: "percent", discountValue: 10, advance: 405, paymentMode: "Cash", deliveryDate: "", status: "Delivered", notes: "" },
      { id: "DEMO-O2", orderNo: "ORD-1002", date: d(0), customerName: "Priya Patel", customerPhone: "9823456712", orderType: "Walk-in", items: [item("DEMO-P7", "Personalized Photo Mug", "Gift Item", 2, 250, 2)], advance: 500, paymentMode: "UPI", deliveryDate: "", status: "Delivered", notes: "" },
      { id: "DEMO-O3", orderNo: "ORD-1003", date: d(-1), customerName: "Amit Verma", customerPhone: "9765432109", orderType: "Custom", items: [item("DEMO-P5", "LED Photo Frame with Remote", "LED Frame", 1, 1100, 3), item("DEMO-P8", "Engraved Keychain", "Gift Item", 3, 120, 4)], advance: 1000, paymentMode: "Split", payments: [{ id: "DEMO-PAY1", mode: "UPI", amount: 600 }, { id: "DEMO-PAY2", mode: "Cash", amount: 400 }], deliveryDate: d(2), status: "In Progress", notes: "Anniversary gift set" },
      { id: "DEMO-O4", orderNo: "ORD-1004", date: d(-2), customerName: "Sneha Iyer", customerPhone: "9654321098", orderType: "Walk-in", items: [item("DEMO-P3", "Crystal Clear Acrylic Frame", "Acrylic Frame", 2, 380, 5)], advance: 760, paymentMode: "Card", deliveryDate: "", status: "Delivered", notes: "" },
      { id: "DEMO-O5", orderNo: "ORD-1005", date: d(-3), customerName: "Rahul Sharma", customerPhone: "9876543210", orderType: "Custom", items: [item("DEMO-P6", "LED Marquee Name Sign", "LED Frame", 1, 900, 6)], advance: 400, paymentMode: "Cash", deliveryDate: d(1), status: "Ready", notes: '"Sharma Family" text' },
      { id: "DEMO-O6", orderNo: "ORD-1006", date: d(-4), customerName: "Priya Patel", customerPhone: "9823456712", orderType: "Walk-in", items: [item("DEMO-P4", "Acrylic Block Frame", "Acrylic Frame", 1, 300, 7)], advance: 300, paymentMode: "Cash", deliveryDate: "", status: "Delivered", notes: "" },
      { id: "DEMO-O7", orderNo: "ORD-1007", date: d(-5), customerName: "Amit Verma", customerPhone: "9765432109", orderType: "Walk-in", items: [item("DEMO-P2", "Rustic Barnwood Frame", "Wooden Frame", 2, 350, 8)], advance: 700, paymentMode: "UPI", deliveryDate: "", status: "Delivered", notes: "" },
      { id: "DEMO-O8", orderNo: "ORD-1008", date: d(-6), customerName: "Sneha Iyer", customerPhone: "9654321098", orderType: "Custom", items: [item("DEMO-P1", "Classic Wooden Photo Frame", "Wooden Frame", 3, 450, 9)], advance: 900, paymentMode: "Cash", deliveryDate: d(3), status: "Pending", notes: "Family portrait set of 3" },
      { id: "DEMO-O9", orderNo: "ORD-1009", date: d(-1), customerName: "New Walk-in", customerPhone: "9911223344", orderType: "Walk-in", items: [item("DEMO-P8", "Engraved Keychain", "Gift Item", 5, 120, 10)], advance: 300, paymentMode: "Cash", deliveryDate: "", status: "Delivered", notes: "" },
      { id: "DEMO-O10", orderNo: "ORD-1010", date: d(-2), customerName: "Amit Verma", customerPhone: "9765432109", orderType: "Custom", items: [item("DEMO-P6", "LED Marquee Name Sign", "LED Frame", 1, 900, 11)], advance: 300, paymentMode: "UPI", deliveryDate: d(-1), status: "Cancelled", notes: "Customer cancelled — changed mind on text" },
      { id: "DEMO-O11", orderNo: "ORD-1011", date: d(-7), customerName: "Sneha Iyer", customerPhone: "9654321098", orderType: "Walk-in", items: [item("DEMO-P4", "Acrylic Block Frame", "Acrylic Frame", 1, 300, 12)], advance: 300, paymentMode: "Cash", deliveryDate: "", status: "Returned", returnRefund: 300, returnReason: "Frame arrived with a crack", returnDate: d(-5), notes: "" },
    ];
    const demoExpenses = [
      { id: "DEMO-E1", date: d(-12), category: "Raw Material", description: "Wood planks & acrylic sheets", amount: 8000, paymentMode: "Cash" },
      { id: "DEMO-E2", date: d(-10), category: "Rent", description: "Shop rent — monthly", amount: 15000, paymentMode: "UPI" },
      { id: "DEMO-E3", date: d(-6), category: "Electricity", description: "Electricity bill", amount: 2200, paymentMode: "Cash" },
      { id: "DEMO-E4", date: d(-4), category: "Packaging", description: "Gift boxes & bubble wrap", amount: 1300, paymentMode: "Cash" },
    ];

    const stripDemo = (arr) => arr.filter((x) => !String(x.id).startsWith("DEMO-"));
    const knownPhones = new Set(demoCustomers.map((c) => c.phone));
    const extraCustomers = [];
    demoOrders.forEach((o) => {
      if (o.customerPhone && !knownPhones.has(o.customerPhone)) {
        knownPhones.add(o.customerPhone);
        extraCustomers.push({ id: "DEMO-C-" + o.customerPhone, name: o.customerName, phone: o.customerPhone, address: "", notes: "" });
      }
    });
    persistMultiple([
      ["shop-products", [...stripDemo(products), ...demoProducts], setProducts],
      ["shop-customers", [...stripDemo(customers), ...demoCustomers, ...extraCustomers], setCustomers],
      ["shop-orders", [...stripDemo(orders), ...demoOrders], setOrders],
      ["shop-expenses", [...stripDemo(expenses), ...demoExpenses], setExpenses],
    ]);
    showToast("Sample data loaded — explore, then clear it any time from Settings");
    setSettingsOpen(false);
  };

  const removeSampleData = () => {
    const stripDemo = (arr) => arr.filter((x) => !String(x.id).startsWith("DEMO-"));
    persistMultiple([
      ["shop-products", stripDemo(products), setProducts],
      ["shop-customers", stripDemo(customers), setCustomers],
      ["shop-orders", stripDemo(orders), setOrders],
      ["shop-expenses", stripDemo(expenses), setExpenses],
    ]);
    showToast("Sample data removed");
  };

  // A backup the owner holds themselves. Read fresh from the server whenever we can
  // (so it includes anything another device saved), falling back to what's on screen
  // when there's no connection.
  const exportData = async () => {
    if (backupBusy) return;
    setBackupBusy(true);
    try {
      const payload = isOnline && effectiveShopId
        ? await shopBackup.buildBackup(effectiveShopId)
        : {
            version: shopBackup.BACKUP_VERSION,
            shopId: effectiveShopId,
            exportedAt: new Date().toISOString(),
            counts: { products: products.length, customers: customers.length, expenses: expenses.length, orders: orders.length },
            data: { products, customers, expenses, orders, settings },
          };
      const size = shopBackup.downloadJson(payload, `${settings.shopName.replace(/\s+/g, "_")}_backup_${todayStr()}.json`);
      const next = { ...settings, lastBackupAt: new Date().toISOString() };
      setSettings(next);
      if (isOwner) saveKey("shop-settings", next);
      showToast(
        size > 25 * 1024 * 1024
          ? `Backup downloaded (${shopBackup.humanSize(size)}) — it's large because of order photos; store it somewhere safe`
          : `Backup downloaded (${shopBackup.humanSize(size)}) — keep a copy somewhere safe`
      );
    } catch (e) {
      showToast("Could not create the backup — check your connection and try again", "error");
    } finally {
      setBackupBusy(false);
    }
  };

  // Loading a backup back in. Merge adds and updates; replace makes the shop match
  // the file exactly. Owner only — staff can't overwrite a whole shop.
  const runRestore = async (parsed, mode) => {
    if (!isOwner) { showToast("Only the shop owner can restore a backup", "error"); return; }
    try {
      const current = { products, customers, expenses, orders };
      const res = await tracked(async () => {
        const out = await shopBackup.restoreBackup(effectiveShopId, parsed, current, mode, settings);
        return out;
      });
      const restored = res && res.products ? res : null;
      if (!restored) throw new Error("Restore did not complete");
      setProducts(restored.products);
      setCustomers(restored.customers);
      setExpenses(restored.expenses);
      setOrders(restored.orders);
      setSettings(restored.settings);
      shopRepo.primeSnapshots(restored);
      setRestoreOpen(false);
      showToast(mode === "replace" ? "Shop replaced from your backup" : "Backup merged into your shop");
    } catch (e) {
      showToast(e?.message || "Could not restore that backup", "error");
    }
  };

  // Spreadsheet export mirrors what's on screen (computed stock levels, order totals,
  // customer spend) rather than the raw stored fields — so it matches the app, not
  // just the database. Built with the same numbers Dashboard/Finance use, so a figure
  // here should never disagree with a figure in the app.
  const exportSpreadsheet = async () => {
    setExportingExcel(true);
    try {
      // xlsx is a large library only ever needed for this one button — importing it
      // dynamically keeps it out of the app's initial bundle entirely, so nobody pays
      // for it just to open their dashboard.
      const XLSX = await import("xlsx");
      const wb = XLSX.utils.book_new();
      const sheet = (rows, widths) => {
        const ws = XLSX.utils.json_to_sheet(rows.length ? rows : [{ Note: "No data yet" }]);
        if (widths) ws["!cols"] = widths.map((wch) => ({ wch }));
        return ws;
      };

      const summaryRows = [
        { Metric: "Report generated", Value: fmtDate(todayStr()) },
        { Metric: "Total sales (₹)", Value: finance.totalSales },
        { Metric: "Advance collected (₹)", Value: finance.totalAdvance },
        { Metric: "Outstanding balance (₹)", Value: finance.totalOutstanding },
        { Metric: "Estimated cost of goods sold (₹)", Value: finance.cogs },
        { Metric: "Gross profit (₹)", Value: finance.grossProfit },
        { Metric: "Total expenses (₹)", Value: finance.totalExpenses },
        { Metric: "Net profit (₹)", Value: finance.netProfit },
      ];
      XLSX.utils.book_append_sheet(wb, sheet(summaryRows, [32, 16]), "Summary");

      const stockRows = productsComputed.map((p) => ({
        SKU: p.sku, Category: p.category, "Item Name": p.name, Size: p.size, Customization: p.customization,
        "Cost Price (₹)": p.costPrice, "Selling Price (₹)": p.sellingPrice,
        "Opening Stock": p.openingStock, Restocked: p.restocked, Sold: p.sold, "Current Stock": p.current,
        "Stock Value (₹)": p.value, Status: p.current < 0 ? "Oversold" : p.low ? "Low stock" : "In stock",
      }));
      XLSX.utils.book_append_sheet(wb, sheet(stockRows, [10, 14, 26, 12, 22, 12, 12, 12, 10, 8, 12, 12, 10]), "Stock");

      const orderRows = ordersComputed.map((o) => ({
        "Order No": o.orderNo, Date: o.date, Customer: o.customerName || "Walk-in", Phone: o.customerPhone,
        "Order Type": o.orderType, Items: (o.items || []).map((it) => `${it.qty}x ${it.name}`).join("; "),
        "Subtotal (₹)": o.subtotal, "Discount (₹)": o.discount,
        "Total (₹)": o.total, "Advance Paid (₹)": num(o.advance), "Balance Due (₹)": o.balance,
        "Payment Mode": o.paymentMode, "Payment Breakdown": orderPayments(o).map((p) => `${p.mode}: ${fmtMoney(p.amount)}`).join(", "),
        Status: o.status, "Delivery Date": o.deliveryDate || "", Notes: o.notes || "",
        "Refund Amount (₹)": o.status === "Returned" ? num(o.returnRefund) : "", "Return Reason": o.returnReason || "",
      }));
      XLSX.utils.book_append_sheet(wb, sheet(orderRows, [12, 12, 18, 13, 11, 34, 12, 12, 12, 13, 13, 12, 30, 12, 13, 24, 14, 26]), "Orders");

      const itemRows = [];
      ordersComputed.forEach((o) => (o.items || []).forEach((it) => {
        const prod = it.productId ? products.find((p) => p.id === it.productId) : null;
        itemRows.push({
          "Order No": o.orderNo, Date: o.date, Customer: o.customerName || "Walk-in", SKU: it.sku || (prod?.sku || ""), Item: it.name, Category: it.category,
          Qty: num(it.qty), "Unit Price (₹)": num(it.unitPrice), "Line Total (₹)": num(it.qty) * num(it.unitPrice), Status: o.status,
          "Custom Photo?": it.customPhoto ? "Yes" : "No", "Custom Photo Notes": it.customPhotoNote || "",
        });
      }));
      XLSX.utils.book_append_sheet(wb, sheet(itemRows, [12, 12, 18, 10, 26, 14, 6, 12, 12, 12, 12, 30]), "Order Items");

      const customerRows = customersComputed.map((c) => ({
        Name: c.name, Phone: c.phone, Address: c.address || "", "Total Orders": c.totalOrders,
        "Total Spent (₹)": c.totalSpent, "Outstanding (₹)": c.outstanding, "Last Order": c.lastOrderDate || "", Notes: c.notes || "",
      }));
      XLSX.utils.book_append_sheet(wb, sheet(customerRows, [18, 13, 28, 11, 13, 12, 12, 24]), "Customers");

      const expenseRows = expenses.map((e) => ({
        Date: e.date, Category: e.category, Description: e.description || "", "Amount (₹)": num(e.amount), "Payment Mode": e.paymentMode,
      }));
      XLSX.utils.book_append_sheet(wb, sheet(expenseRows, [12, 16, 30, 12, 13]), "Expenses");

      XLSX.writeFile(wb, `${settings.shopName.replace(/\s+/g, "_")}_export_${todayStr()}.xlsx`);
    } catch (e) {
      showToast("Could not create the spreadsheet — check your connection and try again", "error");
    } finally {
      setExportingExcel(false);
    }
  };

  const isEmpty = !products.length && !orders.length && !customers.length && !expenses.length;
  const cachedLoadingSettings = (() => {
    const shopId = effectiveShopId || (user ? cachedShopIdFor(user.id) : null);
    return shopId ? readCachedShopData(shopId)?.settings : null;
  })();
  const loadingSettings = settings.logoDataUrl ? settings : (loadingBrand || cachedLoadingSettings || settings);

  /* ---------------- render ---------------- */
  if (recovery && user) {
    return (
      <ResetPasswordScreen
        onDone={() => {
          setRecovery(false);
          showToast("Password updated — you're signed in");
        }}
      />
    );
  }

  if (user && loadError) {
    return (
      <div className="min-h-screen flex items-center justify-center px-5" style={{ backgroundColor: T.bg }}>
        <div className="flex flex-col items-center gap-3 text-center max-w-xs">
          <AlertTriangle size={28} style={{ color: T.danger }} />
          <p className="text-sm font-semibold" style={{ color: T.ink }}>Couldn't load your shop data</p>
          <p className="text-xs" style={{ color: T.inkFaint }}>This usually means a weak or dropped connection — your data is safe, it just didn't come through this time.</p>
          <PrimaryButton onClick={() => { setLoading(true); loadShopData(effectiveShopId || user.id); }}>Try again</PrimaryButton>
        </div>
      </div>
    );
  }

  if (authLoading || (user && loading)) {
    return (
      <div className="shop-theme min-h-screen flex items-center justify-center px-5" data-shop-theme={theme} style={{ backgroundColor: T.bg }}>
        <div className="flex flex-col items-center gap-3 text-center">
          <BusinessMark settings={loadingSettings} size="large" loading />
          <div>
            <p className="text-sm font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>
              {loadingSettings.shopName || "Your business"}
            </p>
            <p className="mt-1 flex items-center justify-center gap-1.5 text-xs" style={{ color: T.inkSoft }}>
              <RefreshCw size={12} className="animate-spin" />
              Connecting to your shop…
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (!user) return <AuthScreen />;

  return (
    <div className="shop-theme min-h-screen flex" data-shop-theme={theme} style={{ backgroundColor: T.bg, color: T.ink, fontFamily: "Inter, sans-serif" }}>
      <style>{`
        @keyframes slideUp { from { transform: translateY(24px); opacity: 0 } to { transform: translateY(0); opacity: 1 } }
        * { font-family: 'Inter', sans-serif; }
        ::selection { background: ${T.tealSoft}; color: ${T.ink}; }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: ${T.bg}; }
        ::-webkit-scrollbar-thumb { background: ${T.border}; border-radius: 4px; }
        input::placeholder, textarea::placeholder { color: ${T.inkFaint}; }
        select { color-scheme: ${theme}; }
        .tabular-nums { font-family: 'Space Mono', monospace; }
        @media print {
          body * { visibility: hidden; }
          .receipt-print, .receipt-print * { visibility: visible; }
          .receipt-print { position: fixed !important; inset: 0 !important; width: 100% !important; margin: 0 !important; border: none !important; border-radius: 0 !important; }
          .no-print { display: none !important; }
        }
      `}</style>

      {/* Desktop sidebar */}
      <aside className="hidden md:flex md:w-60 shrink-0 flex-col border-r sticky top-0 h-screen overflow-y-auto" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
        <div className="px-5 py-5 flex items-center gap-2.5 border-b" style={{ borderColor: T.borderSoft }}>
          <BusinessMark settings={settings} />
          <div className="min-w-0">
            <p className="text-sm font-semibold truncate" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>
              {settings.shopName}
            </p>
            <p className="text-xs" style={{ color: T.inkFaint }}>Shop manager</p>
          </div>
        </div>
        <nav className="flex-1 px-3 py-4 flex flex-col gap-1">
          {visibleNav.map((n) => {
            const active = tab === n.id;
            return (
              <button
                key={n.id}
                onClick={() => setTab(n.id)}
                className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors focus:outline-none"
                style={{
                  color: active ? T.teal : T.inkSoft,
                  backgroundColor: active ? T.tealSoft : "transparent",
                }}
              >
                <n.icon size={17} />
                {t(`nav.${n.id}`, n.label)}
              </button>
            );
          })}
        </nav>
      </aside>

      {/* Main column */}
      <div className="flex-1 flex flex-col min-w-0 pb-16 md:pb-0">
        {/* Top header */}
        <header className="sticky top-0 z-30 flex items-center justify-between gap-3 px-4 md:px-8 py-4 border-b backdrop-blur" style={{ borderColor: T.borderSoft, backgroundColor: `color-mix(in oklab, ${T.bg} 95%, transparent)` }}>
          <div className="flex items-center gap-2 md:hidden">
            {settings.logoDataUrl ? (
              <img src={settings.logoDataUrl} alt="" className="w-5 h-5 rounded object-cover" />
            ) : (
              <Frame size={18} style={{ color: T.brass }} />
            )}
            <span className="text-sm font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>{settings.shopName}</span>
          </div>
          <h1 className="hidden md:block text-lg font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>
            {t(`nav.${tab}`, NAV.find((n) => n.id === tab)?.label)}
          </h1>
          <div className="flex items-center gap-2">
            {tab === "stock" && (
              <>
                <GhostButton onClick={() => setImportKind("products")}><Upload size={16} /> <span className="hidden sm:inline">{t("import.button", "Import")}</span></GhostButton>
                <PrimaryButton onClick={() => setProductModal({})}><Plus size={16} /> <span className="hidden sm:inline">Add product</span></PrimaryButton>
              </>
            )}
            {tab === "orders" && (
              <PrimaryButton onClick={() => setOrderModal({})}><Plus size={16} /> <span className="hidden sm:inline">New order</span></PrimaryButton>
            )}
            {tab === "customers" && (
              <>
                <GhostButton onClick={() => setImportKind("customers")}><Upload size={16} /> <span className="hidden sm:inline">{t("import.button", "Import")}</span></GhostButton>
                <PrimaryButton onClick={() => setCustomerModal({})}><Plus size={16} /> <span className="hidden sm:inline">Add customer</span></PrimaryButton>
              </>
            )}
            {tab === "finance" && (
              <PrimaryButton onClick={() => setExpenseModal({})}><Plus size={16} /> <span className="hidden sm:inline">Add expense</span></PrimaryButton>
            )}
            <SyncStatus
              online={isOnline}
              saving={savingCount > 0}
              savedAt={savedAt}
              pending={pendingCount}
                logo={settings.logoDataUrl}
            />
            {showInviteShops && (
              <a href="/admin" className="text-sm font-semibold px-1" style={{ color: T.teal }} aria-label="Invite shops">
                <span className="sm:hidden">Invite</span>
                <span className="hidden sm:inline">Invite shops</span>
              </a>
            )}
            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              aria-label={t("settings.openProfile", "Open profile and settings")}
              title={t("settings.openProfile", "Open profile and settings")}
              className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border transition-colors focus:outline-none focus:ring-2"
              style={{ color: T.teal, backgroundColor: T.tealSoft, borderColor: T.border, ["--tw-ring-color"]: T.teal }}
            >
              {settings.logoDataUrl
                ? <img src={settings.logoDataUrl} alt="" className="h-full w-full object-cover" />
                : <UserRound size={19} />}
            </button>
          </div>
        </header>

        {(!isOnline || viewingOffline) && (
          <div className="px-4 md:px-8 py-2 text-xs font-medium flex items-start gap-2" style={{ backgroundColor: T.warnSoft, color: T.warn }}>
            <AlertTriangle size={14} className="mt-[2px] shrink-0" />
            <span>
              You're offline — showing your last synced data. Keep working: new orders, edits and payments are saved on this device and sync automatically when you're back online.
              {pendingCount > 0 && (
                <>
                  {" "}
                  <b>{pendingCount} change{pendingCount === 1 ? "" : "s"} made {pendingAge(pendingSince)} {pendingCount === 1 ? "is" : "are"} still waiting on this device.</b>{" "}
                  Reconnect on this same phone/browser, and don't clear your browsing data until they've synced.
                </>
              )}
            </span>
          </div>
        )}
        {isOnline && pendingCount > 0 && (() => {
          const stale = pendingSince ? Date.now() - pendingSince > 24 * 60 * 60 * 1000 : false;
          return (
            <div
              className="px-4 md:px-8 py-2 text-xs font-medium flex items-center gap-2 flex-wrap"
              style={stale ? { backgroundColor: T.warnSoft, color: T.warn } : { backgroundColor: T.tealSoft, color: T.teal }}
            >
              {syncing && settings.logoDataUrl
                ? <img src={settings.logoDataUrl} alt={`${settings.shopName || "Business"} logo`} className="h-5 w-5 shrink-0 rounded object-cover" />
                : <AlertTriangle size={14} />}
              {syncing
                ? `Syncing ${pendingCount} change${pendingCount === 1 ? "" : "s"} made offline…`
                : `${pendingCount} change${pendingCount === 1 ? "" : "s"} made offline ${pendingAge(pendingSince)} ${pendingCount === 1 ? "is" : "are"} waiting to sync.`}
              {!syncing && stale && (
                <button
                  type="button"
                  onClick={() => syncPending(effectiveShopId)}
                  className="underline underline-offset-2"
                  style={{ color: T.warn }}
                >
                  Sync now
                </button>
              )}
            </div>
          );
        })()}


        <main className="flex-1 px-4 md:px-8 py-5 max-w-6xl w-full mx-auto">
          {isEmpty && tab === "dashboard" ? (
            <EmptyState
              icon={Frame}
              title={t("dashboard.welcomeTitle", "Welcome to your shop dashboard")}
              subtitle={t("dashboard.welcomeSubtitle", "Add your first product to start tracking stock, orders, customers and profit — all in one place.")}
              actionLabel={t("dashboard.addFirstProduct", "Add your first product")}
              onAction={() => { setTab("stock"); setProductModal({}); }}
              secondaryLabel={t("dashboard.loadSampleData", "Or load sample data to explore first")}
              onSecondary={seedSampleData}
            />
          ) : tab === "dashboard" ? (
            <DashboardTab dashboard={dashboard} finance={finance} customers={customersComputed} setTab={setTab} shopName={settings.shopName} t={t} canSeeMoney={canSeeMoney} />
          ) : tab === "stock" ? (
            <StockTab
              canSeeMoney={canSeeMoney}
              products={productsComputed}
              t={t}
              catFilter={stockCatFilter} setCatFilter={setStockCatFilter}
              stockFilter={stockLevelFilter} setStockFilter={setStockLevelFilter}
              sortBy={stockSort} setSortBy={setStockSort}
              onEdit={(p) => setProductModal(p)}
              onRestock={(p) => setRestockModal(p)}
              onView={(p) => setProductDetail(p)}
              onDelete={(p) => setConfirmState({
                type: "product",
                id: p.id,
                text: p.sold > 0
                  ? `"${p.name}" has ${p.sold} past sale${p.sold === 1 ? "" : "s"} on record. Deleting it removes it from Stock, but past orders keep their own copy of the details — profit history won't change. Delete anyway?`
                  : `Delete "${p.name}" from stock? This can't be undone.`,
              })}
              onAdd={() => setProductModal({})}
            />
          ) : tab === "orders" ? (
            <OrdersTab
              orders={ordersComputed}
              products={productsComputed}
              t={t}
              statusFilter={orderStatusFilterTab} setStatusFilter={setOrderStatusFilterTab}
              dateFilter={orderDateFilter} setDateFilter={setOrderDateFilter}
              rangeStart={orderRangeStart} setRangeStart={setOrderRangeStart}
              rangeEnd={orderRangeEnd} setRangeEnd={setOrderRangeEnd}
              paymentFilter={orderPaymentFilter} setPaymentFilter={setOrderPaymentFilter}
              productFilter={orderProductFilter} setProductFilter={setOrderProductFilter}
              shopName={settings.shopName}
              onEdit={(o) => setOrderModal(o)}
              onDelete={(o) => setConfirmState({ type: "order", id: o.id, text: `Delete order ${o.orderNo}? This can't be undone.` })}
              onAdd={() => setOrderModal({})}
              onQuickStatus={handleQuickStatus}
              onReceipt={(o) => setReceiptOrder(o)}
              onDuplicate={duplicateOrder}
            />
          ) : tab === "customers" ? (
            <CustomersTab
              customers={customersComputed}
              t={t}
              balanceFilter={customerBalanceFilter} setBalanceFilter={setCustomerBalanceFilter}
              sortBy={customerSort} setSortBy={setCustomerSort}
              shopName={settings.shopName}
              onEdit={(c) => setCustomerModal(c)}
              onDelete={(c) => setConfirmState({ type: "customer", id: c.id, text: `Delete customer "${c.name}"? Their past orders will stay in Orders.` })}
              onAdd={() => setCustomerModal({})}
              onView={(c) => setCustomerDetail(c)}
            />
          ) : (
            <FinanceTab
              expenses={expenses}
              ordersComputed={ordersComputed}
              orderCOGS={orderCOGS}
              products={products}
              t={t}
              onViewProduct={(productId) => {
                const p = productsComputed.find((pc) => pc.id === productId);
                if (p) setProductDetail(p);
              }}
              catFilter={expenseCatFilter} setCatFilter={setExpenseCatFilter}
              dateFilter={financeDateFilter} setDateFilter={setFinanceDateFilter}
              rangeStart={financeRangeStart} setRangeStart={setFinanceRangeStart}
              rangeEnd={financeRangeEnd} setRangeEnd={setFinanceRangeEnd}
              onEdit={(e) => setExpenseModal(e)}
              onDelete={(e) => setConfirmState({ type: "expense", id: e.id, text: `Delete this expense entry?` })}
              onAdd={() => setExpenseModal({})}
            />
          )}
        </main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 flex items-stretch border-t" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
        {visibleNav.map((n) => {
          const active = tab === n.id;
          return (
            <button
              key={n.id}
              onClick={() => setTab(n.id)}
              className="flex-1 flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium"
              style={{ color: active ? T.teal : T.inkFaint }}
            >
              <n.icon size={19} />
              {t(`nav.${n.id}`, n.label)}
            </button>
          );
        })}
      </nav>

      {/* Modals */}
      {productModal && (
        <ProductModal
          product={productModal}
          products={products}
          t={t}
          onClose={() => setProductModal(null)}
          onSave={saveProduct}
        />
      )}
      {restockModal && (
        <RestockModal
          product={restockModal}
          t={t}
          onClose={() => setRestockModal(null)}
          onSave={(entry) => saveRestock(restockModal, entry)}
        />
      )}
      {orderModal && (
        <OrderModal
          order={orderModal}
          products={products}
          productsComputed={productsComputed}
          customerOptions={customerOptions}
          shopName={settings.shopName}
          settings={settings}
          t={t}
          onClose={() => setOrderModal(null)}
          onSave={saveOrder}
        />
      )}
      {customerModal && (
        <CustomerModal
          customer={customerModal}
          customers={customers}
          t={t}
          onClose={() => setCustomerModal(null)}
          onSave={saveCustomer}
        />
      )}
      {importKind && (
        <ImportModal
          kind={importKind}
          existing={importKind === "products" ? products : customers}
          t={t}
          onClose={() => setImportKind(null)}
          onConfirm={(accepted) => runImport(importKind, accepted)}
        />
      )}
      {expenseModal && (
        <ExpenseModal
          expense={expenseModal}
          t={t}
          onClose={() => setExpenseModal(null)}
          onSave={saveExpense}
        />
      )}
      {settingsOpen && (
        <SettingsModal
          settings={settings}
          user={user}
          t={t}
          onClose={() => setSettingsOpen(false)}
          onSave={saveSettings}
          onLogoChange={saveLogo}
          onExportExcel={exportSpreadsheet}
          exportingExcel={exportingExcel}
          onExportJson={exportData}
          backupBusy={backupBusy}
          onRestore={() => { setSettingsOpen(false); setRestoreOpen(true); }}
          onSeed={seedSampleData}
          onUnseed={removeSampleData}
          hasDemoData={[...products, ...orders, ...customers, ...expenses].some((x) => String(x.id).startsWith("DEMO-"))}
          onClearAll={() => setConfirmState({ type: "clearAll", text: t("settings.clearAllConfirm", "Delete ALL shop data — stock, orders, customers and expenses? This can't be undone.") })}
          isOwner={isOwner}
          teamMembers={teamMembers}
          teamBusy={teamBusy}
          onInviteStaff={inviteStaff}
          onRemoveStaff={removeStaff}
          theme={theme}
          onThemeChange={setTheme}
          lang={lang}
          onLanguageChange={setLang}
          onSignOut={signOut}
        />
      )}
      {restoreOpen && (
        <RestoreModal
          t={t}
          current={{ products, customers, expenses, orders }}
          onClose={() => setRestoreOpen(false)}
          onConfirm={runRestore}
        />
      )}
      {customerDetail && (
        <CustomerDetailModal
          customer={customerDetail}
          orders={ordersComputed.filter((o) => normalizePhone(o.customerPhone) === normalizePhone(customerDetail.phone))}
          shopName={settings.shopName}
          t={t}
          onClose={() => setCustomerDetail(null)}
          onEdit={() => { setCustomerModal(customerDetail); setCustomerDetail(null); }}
        />
      )}
      {productDetail && (() => {
        const relevantOrders = ordersComputed
          .map((o) => ({ o, items: (o.items || []).filter((it) => it.productId === productDetail.id) }))
          .filter((x) => x.items.length > 0)
          .map(({ o, items }) => {
            const discountRate = o.subtotal > 0 ? o.discount / o.subtotal : 0;
            const qty = items.reduce((s, it) => s + num(it.qty), 0);
            const revenue = items.reduce((s, it) => {
              const inclusive = num(it.qty) * num(it.unitPrice) * (1 - discountRate);
              return s + inclusive;
            }, 0);
            const cost = items.reduce((s, it) => s + num(it.qty) * (it.unitCost !== undefined && it.unitCost !== "" ? num(it.unitCost) : num(productDetail.costPrice)), 0);
            return { ...o, _qty: qty, _revenue: revenue, _cost: cost };
          })
          .sort((a, b) => (a.date < b.date ? 1 : -1));
        const liveOrders = relevantOrders.filter((o) => o.status !== "Cancelled" && o.status !== "Returned");
        const revenue = liveOrders.reduce((s, o) => s + o._revenue, 0);
        const cost = liveOrders.reduce((s, o) => s + o._cost, 0);
        return (
          <ProductDetailModal
            product={productDetail}
            orders={relevantOrders}
            revenue={revenue}
            profit={revenue - cost}
            t={t}
            onClose={() => setProductDetail(null)}
            onEdit={() => { setProductModal(productDetail); setProductDetail(null); }}
            onRestock={() => { setRestockModal(productDetail); setProductDetail(null); }}
          />
        );
      })()}
      {receiptOrder && (
        <ReceiptModal order={receiptOrder} settings={settings} onClose={() => setReceiptOrder(null)} />
      )}
      {returnOrder && (
        <ReturnModal
          order={returnOrder}
          onClose={() => setReturnOrder(null)}
          onConfirm={async (extra) => {
            quickStatus(returnOrder, "Returned", extra);
            setReturnOrder(null);
          }}
        />
      )}
      {confirmState && (
        <ConfirmDialog
          text={confirmState.text}
          t={t}
          onCancel={() => setConfirmState(null)}
          onConfirm={() => {
            if (confirmState.type === "product") deleteProduct(confirmState.id);
            else if (confirmState.type === "order") deleteOrder(confirmState.id);
            else if (confirmState.type === "customer") deleteCustomer(confirmState.id);
            else if (confirmState.type === "expense") deleteExpense(confirmState.id);
            else if (confirmState.type === "clearAll") clearAllData();
            else if (confirmState.type === "cancelOrder") quickStatus(confirmState.payload.order, confirmState.payload.status);
          }}
        />
      )}

      {/* Toast */}
      {toast && (
        <div
          className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-[70] px-4 py-2.5 rounded-md text-sm font-medium shadow-lg border"
          style={
            toast.kind === "error"
              ? { backgroundColor: T.danger, color: T.bg, borderColor: T.danger }
              : { backgroundColor: T.surface, color: T.ink, borderColor: T.success }
          }
        >
          {toast.message}
        </div>
      )}
    </div>
  );
}



// Quiet one-line answer to "is my work actually stored?" — nothing to click, just
// the truth at a glance.
function BusinessMark({ settings, size = "normal", loading = false }) {
  const large = size === "large";
  const boxClass = large ? "h-20 w-20 rounded-lg" : "h-9 w-9 rounded-md";
  return (
    <div
      className={`${boxClass} relative shrink-0 overflow-hidden flex items-center justify-center border`}
      style={{ backgroundColor: T.brassSoft, borderColor: T.border }}
    >
      {settings?.logoDataUrl
        ? <img src={settings.logoDataUrl} alt={`${settings.shopName || "Business"} logo`} className="h-full w-full object-cover" />
        : <Frame size={large ? 32 : 18} style={{ color: T.brass }} />}
    </div>
  );
}

function SyncStatus({ online, saving, savedAt, pending, logo }) {
  if (!online) return null;
  const state = saving ? "saving" : pending > 0 ? "waiting" : savedAt ? "saved" : null;
  if (!state) return null;
  const look = {
    saving: { icon: RefreshCw, color: T.inkFaint, text: "Saving…" },
    waiting: { icon: Clock, color: T.warn, text: `${pending} waiting` },
    saved: { icon: CircleCheck, color: T.success, text: "All changes saved" },
  }[state];
  const Icon = look.icon;
  return (
    <span className="hidden lg:flex items-center gap-1.5 text-xs mr-1" style={{ color: look.color }} title={look.text}>
      {state === "saving" && logo
        ? <img src={logo} alt="Business logo" className="h-4 w-4 rounded object-cover" />
        : <Icon size={14} className={state === "saving" ? "animate-spin" : ""} />}
      {look.text}
    </span>
  );
}

