// @ts-nocheck
// Owner-held backup and restore.
//
// The platform keeps its own automatic backups of the database, but those belong
// to the platform. This module gives the shop owner a copy they hold themselves:
// one file with every product, customer, expense and order (including order lines
// and payments), and a way to load it back — either merged into what's there now
// or as a straight replacement.
import { loadShop, saveKinds } from "./shopRepo";

export const BACKUP_VERSION = 1;

const KINDS = ["products", "customers", "expenses", "orders"];

// Reads the whole shop through the normal paged loader, so there's no row limit:
// a shop with 50,000 orders backs up as completely as one with 50.
export async function buildBackup(shopId) {
  const shop = await loadShop(shopId);
  return {
    version: BACKUP_VERSION,
    shopId,
    exportedAt: new Date().toISOString(),
    counts: {
      products: shop.products.length,
      customers: shop.customers.length,
      expenses: shop.expenses.length,
      orders: shop.orders.length,
    },
    data: {
      products: shop.products,
      customers: shop.customers,
      expenses: shop.expenses,
      orders: shop.orders,
      settings: shop.settings,
    },
  };
}

export function downloadJson(payload, filename) {
  const text = JSON.stringify(payload, null, 2);
  const blob = new Blob([text], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  return blob.size;
}

export const humanSize = (bytes) =>
  bytes > 1024 * 1024 ? `${(bytes / (1024 * 1024)).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;

// A backup file could be anything a person picked off their computer, so the shape
// is checked before a single record is touched.
export async function parseBackup(file) {
  let raw;
  try {
    raw = JSON.parse(await file.text());
  } catch {
    throw new Error("That file isn't a backup file — pick the .json file the app created.");
  }
  const data = raw?.data && typeof raw.data === "object" ? raw.data : raw;
  if (!data || typeof data !== "object") throw new Error("That backup file looks empty or damaged.");
  if (raw?.version && raw.version > BACKUP_VERSION) {
    throw new Error("That backup was made by a newer version of the app — update the app first.");
  }
  const out = { settings: data.settings && typeof data.settings === "object" ? data.settings : null };
  let any = false;
  for (const kind of KINDS) {
    const list = Array.isArray(data[kind]) ? data[kind].filter((r) => r && typeof r === "object" && r.id) : [];
    if (list.length) any = true;
    out[kind] = list;
  }
  if (!any) throw new Error("There are no records in that backup file.");
  return { version: raw?.version || 1, exportedAt: raw?.exportedAt || null, data: out };
}

// What loading this file would actually do, per kind, so the owner sees the effect
// before agreeing to it.
export function previewBackup(parsed, current, mode) {
  const rows = [];
  for (const kind of KINDS) {
    const incoming = parsed.data[kind] || [];
    const haveIds = new Set((current[kind] || []).map((r) => r.id));
    const added = incoming.filter((r) => !haveIds.has(r.id)).length;
    const updated = incoming.length - added;
    const removed = mode === "replace" ? (current[kind] || []).filter((r) => !incoming.some((i) => i.id === r.id)).length : 0;
    rows.push({ kind, incoming: incoming.length, added, updated, removed });
  }
  return rows;
}

// Merge keeps everything that's here and layers the file on top. Replace makes the
// shop match the file exactly — anything not in the file is deleted.
export function mergeLists(parsed, current, mode) {
  const out = {};
  for (const kind of KINDS) {
    const incoming = parsed.data[kind] || [];
    if (mode === "replace") {
      out[kind] = incoming;
    } else {
      const byId = new Map((current[kind] || []).map((r) => [r.id, r]));
      incoming.forEach((r) => byId.set(r.id, r));
      out[kind] = Array.from(byId.values());
    }
  }
  return out;
}

// Every restored record goes through the same validation and the same write path
// as a normal save, so a hand-edited file can't put bad data in the database.
export async function restoreBackup(shopId, parsed, current, mode, currentSettings) {
  const lists = mergeLists(parsed, current, mode);
  const settings = mode === "replace" && parsed.data.settings ? { ...currentSettings, ...parsed.data.settings } : currentSettings;
  await saveKinds(shopId, { ...lists, settings });
  return { ...lists, settings };
}
