// @ts-nocheck
import React, { useState, useEffect, useMemo, useCallback, useRef, useDeferredValue, lazy, Suspense } from "react";
import { Package, ShoppingBag, Users, Wallet, Pencil, Trash2, Search, Phone, PackagePlus, ChevronDown, Camera, Printer, Copy } from "lucide-react";
import { T, FONT_DISPLAY, FONT_MONO, CATEGORIES, PAYMENT_MODES, ORDER_STATUSES, STATUS_COLORS, EXPENSE_CATEGORIES, resolveDateRange, fmtMoney, fmtDate, fmtShortDate, num, orderPayments, orderWaMessage, customerWaMessage, Badge, CategoryTag, IconBtn, ContactActions, SearchableProductSelect, TextInput, SelectInput, DateFilterControl, usePagedList, ShowMore, EmptyState } from "./shopShared";

/* ============================== STOCK ============================== */
export function StockTab({ products, t, canSeeMoney = true, catFilter, setCatFilter, stockFilter, setStockFilter, sortBy, setSortBy, onEdit, onRestock, onView, onDelete, onAdd }) {
  // The search box owns its own text, so a keystroke redraws this list only — not the
  // whole app — and the filtering runs at lower priority than the typing itself.
  const [search, setSearch] = useState("");
  const dq = useDeferredValue(search);
  // Category chips include any custom category someone has actually typed via "Other",
  // not just the four defaults — otherwise a custom category would be unfilterable.
  const allCategories = useMemo(
    () => Array.from(new Set([...CATEGORIES, ...products.map((p) => p.category).filter(Boolean)])),
    [products]
  );
  const filtered = products
    .filter((p) => {
      const matchesCat = catFilter === "All" || p.category === catFilter;
      const matchesStock =
        stockFilter === "All" ||
        (stockFilter === "Low" && p.low && p.current >= 0) ||
        (stockFilter === "Oversold" && p.current < 0) ||
        (stockFilter === "Healthy" && !p.low);
      const q = dq.trim().toLowerCase();
      const matchesSearch = !q || p.name.toLowerCase().includes(q) || (p.sku || "").toLowerCase().includes(q);
      return matchesCat && matchesStock && matchesSearch;
    })
    .sort((a, b) => {
      if (sortBy === "bestsellers") return b.sold - a.sold;
      if (sortBy === "value") return b.value - a.value;
      if (sortBy === "name") return a.name.localeCompare(b.name);
      if (sortBy === "lowstock") return a.current - b.current;
      return 0; // "recent" — keep whatever order products already come in
    });
  const page = usePagedList(filtered, `${dq}|${catFilter}|${stockFilter}|${sortBy}|${filtered.length}`);


  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between">
        <div className="relative w-full sm:w-64">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: T.inkFaint }} />
          <TextInput placeholder={t("stock.searchPlaceholder", "Search by name or SKU")} value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <div className="flex gap-2">
          <SelectInput value={stockFilter} onChange={(e) => setStockFilter(e.target.value)} className="flex-1 sm:flex-none sm:w-36">
            <option value="All">{t("stock.allStockLevels", "All stock levels")}</option>
            <option value="Healthy">{t("stock.inStock", "In stock")}</option>
            <option value="Low">{t("stock.lowStock", "Low stock")}</option>
            <option value="Oversold">{t("stock.oversold", "Oversold")}</option>
          </SelectInput>
          <SelectInput value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="flex-1 sm:flex-none sm:w-40">
            <option value="recent">{t("stock.sortRecent", "Sort: Recently added")}</option>
            <option value="bestsellers">{t("stock.sortBestsellers", "Sort: Best sellers")}</option>
            <option value="value">{t("stock.sortValue", "Sort: Highest value")}</option>
            <option value="name">{t("stock.sortName", "Sort: Name (A–Z)")}</option>
            <option value="lowstock">{t("stock.sortLowStock", "Sort: Lowest stock first")}</option>
          </SelectInput>
        </div>
      </div>
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {["All", ...allCategories].map((c) => (
          <button
            key={c}
            onClick={() => setCatFilter(c)}
            className="px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap border transition-colors"
            style={{
                borderColor: catFilter === c ? T.teal : T.borderSoft,
                color: catFilter === c ? T.teal : T.inkSoft,
                backgroundColor: catFilter === c ? T.tealSoft : T.surface,
              }}
            >
              {c === "All" ? t("stock.all", "All") : c}
            </button>
          ))}
        </div>

      {products.length === 0 ? (
        <EmptyState icon={Package} title={t("stock.noProductsYet", "No products yet")} subtitle={t("stock.noProductsSubtitle", "Add wooden, acrylic, LED frames or gift items to start tracking stock.")} actionLabel={t("stock.addProduct", "Add product")} onAction={onAdd} />
      ) : filtered.length === 0 ? (
        <p className="text-sm text-center py-10" style={{ color: T.inkFaint }}>{t("stock.noMatch", "No products match your search.")}</p>
      ) : (
        <div className="rounded-lg border overflow-hidden" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
          <div className="hidden md:grid grid-cols-[2fr_1fr_1fr_0.7fr_1fr_1fr_auto] gap-3 px-5 py-3 text-[11px] font-semibold uppercase border-b" style={{ borderColor: T.borderSoft, color: T.inkFaint, letterSpacing: "0.06em" }}>
            <span>{t("stock.colProduct", "Product")}</span><span>{t("stock.colCostPrice", "Cost / Price")}</span><span>{t("stock.colStock", "Stock")}</span><span>{t("stock.colSold", "Sold")}</span><span>{t("stock.colValue", "Value")}</span><span>{t("stock.colStatus", "Status")}</span><span></span>
          </div>
          <div className="divide-y" style={{ borderColor: T.borderSoft }}>
            {page.visible.map((p) => (
              <div
                key={p.id}
                onClick={() => onView(p)}
                className="grid grid-cols-1 md:grid-cols-[2fr_1fr_1fr_0.7fr_1fr_1fr_auto] gap-2 md:gap-3 px-5 py-3.5 items-center cursor-pointer transition-colors"
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = `color-mix(in oklab, ${T.borderSoft} 25%, transparent)`)}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
              >
                <div className="min-w-0" style={{ opacity: p.active === false ? 0.6 : 1 }}>
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-medium truncate" style={{ color: T.ink }}>{p.name}</p>
                    {p.active === false && <Badge text={t("stock.discontinued", "Discontinued")} color={T.inkFaint} soft={T.borderSoft} />}
                  </div>
                  <div className="flex items-center gap-2 flex-wrap mt-0.5">
                    <CategoryTag category={p.category} />
                    {p.size && <span className="text-xs" style={{ color: T.inkFaint }}>· {p.size}</span>}
                    {p.sku && <span className="text-xs" style={{ color: T.inkFaint, fontFamily: FONT_MONO }}>· {p.sku}</span>}
                  </div>
                </div>
                <div className="text-sm" style={{ color: T.inkSoft }}>{canSeeMoney ? `${fmtMoney(p.costPrice)} / ${fmtMoney(p.sellingPrice)}` : fmtMoney(p.sellingPrice)}</div>
                <div>
                  <span className="text-sm font-semibold tabular-nums" style={{ color: p.current < 0 ? T.danger : p.low ? T.warn : T.ink }}>
                    {p.current} {t("stock.pcs", "pcs")}
                  </span>
                  {p.current < 0 && <p className="text-xs" style={{ color: T.danger }}>{t("stock.oversoldBy", "Oversold by {n}", { n: Math.abs(p.current) })}</p>}
                  {p.restocked > 0 && <p className="text-xs" style={{ color: T.inkFaint }}>{t("stock.restocked", "+{n} restocked", { n: p.restocked })}</p>}
                </div>
                <div className="text-sm tabular-nums" style={{ color: T.inkSoft }}>{p.sold}</div>
                <div className="text-sm tabular-nums" style={{ color: T.inkSoft }}>{fmtMoney(p.value)}</div>
                <div>
                  {p.current < 0
                    ? <Badge text={t("stock.oversold", "Oversold")} color={T.danger} soft={T.dangerSoft} />
                    : p.low
                    ? <Badge text={t("stock.lowStock", "Low stock")} color={T.warn} soft={T.warnSoft} />
                    : <Badge text={t("stock.inStock", "In stock")} color={T.success} soft={T.successSoft} />}
                </div>
                <div className="flex gap-1 justify-start md:justify-end" onClick={(e) => e.stopPropagation()}>
                  <IconBtn onClick={() => onRestock(p)} label={t("stock.restock", "Restock")}><PackagePlus size={15} /></IconBtn>
                  <IconBtn onClick={() => onEdit(p)} label={t("stock.edit", "Edit")}><Pencil size={15} /></IconBtn>
                  <IconBtn onClick={() => onDelete(p)} label={t("stock.delete", "Delete")} danger><Trash2 size={15} /></IconBtn>
                </div>
              </div>
            ))}
          </div>
          <ShowMore page={page} t={t} />
        </div>
      )}
    </div>
  );
}


/* ============================== ORDERS ============================== */
export function OrdersTab({ orders, products, t, statusFilter, setStatusFilter, dateFilter, setDateFilter, rangeStart, setRangeStart, rangeEnd, setRangeEnd, paymentFilter, setPaymentFilter, productFilter, setProductFilter, shopName, onEdit, onDelete, onAdd, onQuickStatus, onReceipt, onDuplicate }) {
  const [search, setSearch] = useState("");
  const dq = useDeferredValue(search);
  const allPaymentModes = useMemo(
    () => Array.from(new Set([...PAYMENT_MODES, ...orders.map((o) => o.paymentMode).filter(Boolean)])),
    [orders]
  );
  const dateRange = resolveDateRange(dateFilter, rangeStart, rangeEnd);
  const filtered = orders
    .filter((o) => statusFilter === "All" || o.status === statusFilter)
    .filter((o) => paymentFilter === "All" || o.paymentMode === paymentFilter || orderPayments(o).some((p) => p.mode === paymentFilter))
    .filter((o) => !productFilter || (o.items || []).some((it) => it.productId === productFilter))
    .filter((o) => !dateRange || (o.date >= dateRange[0] && o.date <= dateRange[1]))
    .filter((o) => {
      const q = dq.trim().toLowerCase();
      if (!q) return true;
      return (o.customerName || "").toLowerCase().includes(q) || (o.customerPhone || "").includes(q) || (o.orderNo || "").toLowerCase().includes(q);
    })
    .sort((a, b) => (a.date < b.date ? 1 : -1));
  const isFiltered = dateFilter !== "All time" || statusFilter !== "All" || paymentFilter !== "All" || !!productFilter || dq.trim();
  const periodSales = filtered.filter((o) => o.status !== "Cancelled" && o.status !== "Returned").reduce((s, o) => s + o.total, 0);
  const periodOutstanding = filtered.filter((o) => o.status !== "Cancelled" && o.status !== "Returned").reduce((s, o) => s + o.balance, 0);
  const page = usePagedList(filtered, `${dq}|${statusFilter}|${paymentFilter}|${productFilter}|${dateFilter}|${rangeStart}|${rangeEnd}|${filtered.length}`);



  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between">
        <div className="relative w-full sm:w-64">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: T.inkFaint }} />
          <TextInput placeholder={t("orders.searchPlaceholder", "Search customer or order #")} value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <div className="flex gap-2 flex-wrap">
          <DateFilterControl preset={dateFilter} setPreset={setDateFilter} start={rangeStart} setStart={setRangeStart} end={rangeEnd} setEnd={setRangeEnd} t={t} />
          <SelectInput value={paymentFilter} onChange={(e) => setPaymentFilter(e.target.value)} className="flex-1 sm:flex-none sm:w-36">
            <option value="All">{t("orders.allPayments", "All payments")}</option>
            {allPaymentModes.map((m) => <option key={m} value={m}>{m}</option>)}
          </SelectInput>
        </div>
      </div>
      <div className="w-full sm:w-72">
        <SearchableProductSelect products={products} value={productFilter} onChange={setProductFilter} allLabel={t("orders.allProducts", "All products")} />
      </div>
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {["All", ...ORDER_STATUSES].map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className="px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap border transition-colors"
            style={{
              borderColor: statusFilter === s ? T.teal : T.borderSoft,
              color: statusFilter === s ? T.teal : T.inkSoft,
              backgroundColor: statusFilter === s ? T.tealSoft : T.surface,
            }}
          >
            {s === "All" ? t("orders.all", "All") : t(`status.${s}`, s)}
          </button>
        ))}
      </div>

      {orders.length > 0 && isFiltered && filtered.length > 0 && (
        <div className="flex items-center justify-between px-4 py-2.5 rounded-md text-xs font-medium" style={{ backgroundColor: T.tealSoft, color: T.teal }}>
          <span className="font-mono tabular-nums">{filtered.length} {t("orders.ordersWord", filtered.length === 1 ? "order" : "orders")} · {fmtMoney(periodSales)} {t("orders.sales", "sales")}</span>
          {periodOutstanding > 0 && <span className="font-mono tabular-nums">{fmtMoney(periodOutstanding)} {t("orders.outstandingWord", "outstanding")}</span>}
        </div>
      )}

      {orders.length === 0 ? (
        <EmptyState icon={ShoppingBag} title={t("orders.noOrdersYet", "No orders yet")} subtitle={t("orders.noOrdersSubtitle", "Log a walk-in sale or a custom order to see it tracked here.")} actionLabel={t("orders.newOrder", "New order")} onAction={onAdd} />
      ) : filtered.length === 0 ? (
        <p className="text-sm text-center py-10" style={{ color: T.inkFaint }}>{t("orders.noMatch", "No orders match your filters.")}</p>
      ) : (
        <div className="flex flex-col gap-2.5">
          {page.visible.map((o) => (
            <div key={o.id} className="rounded-lg border p-4" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-semibold" style={{ color: T.ink }}>{o.customerName || t("dashboard.walkIn", "Walk-in")}</p>
                    <span className="text-xs" style={{ color: T.inkFaint }}>{o.orderNo}</span>
                  </div>
                  <p className="text-xs mt-0.5" style={{ color: T.inkSoft }}>
                    {(o.items || []).length === 0
                      ? t("orders.noItems", "No items")
                      : (o.items || []).map((it, i) => {
                          // Orders created before SKU-snapshotting existed won't have it.sku
                          // saved — fall back to a live catalogue lookup so old orders aren't
                          // stuck showing nothing just because they predate the feature.
                          const displaySku = it.sku || (it.productId ? (products.find((p) => p.id === it.productId)?.sku || "") : "");
                          return (
                            <span key={it.rowId || i}>
                              {i > 0 && ", "}
                              {it.name}
                              {displaySku && <span style={{ color: T.inkFaint }}> ({displaySku})</span>}
                            </span>
                          );
                        })}
                  </p>
                  {(o.items || []).some((it) => it.customPhoto) && (
                    <p className="inline-flex items-center gap-1 text-xs mt-1 font-medium" style={{ color: T.brass }}>
                      <Camera size={12} /> {t("orders.needsPhoto", "Needs customer's photo")}
                    </p>
                  )}
                  <div className="flex items-center gap-3 mt-2 flex-wrap text-xs" style={{ color: T.inkFaint }}>
                    <span>{fmtDate(o.date)}</span>
                    {o.deliveryDate && <span>{t("orders.delivery", "Delivery:")} {fmtShortDate(o.deliveryDate)}</span>}
                    <span>{o.orderType}</span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  {o.discount > 0 && <p className="text-xs tabular-nums" style={{ color: T.inkFaint, textDecoration: "line-through" }}>{fmtMoney(o.subtotal)}</p>}
                  <p className="text-sm font-semibold tabular-nums" style={{ color: T.ink }}>{fmtMoney(o.total)}</p>
                  {o.status === "Returned" ? (
                    <p className="text-xs font-medium tabular-nums" style={{ color: T.plum }}>{t("orders.refunded", "Refunded")} {fmtMoney(o.returnRefund || 0)}</p>
                  ) : o.balance > 0 ? (
                    <p className="text-xs font-medium tabular-nums" style={{ color: T.danger }}>{t("orders.due", "Due")} {fmtMoney(o.balance)}</p>
                  ) : (
                    <p className="text-xs" style={{ color: T.success }}>{t("orders.paidInFull", "Paid in full")}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center justify-between gap-2 mt-3 pt-3 border-t" style={{ borderColor: T.borderSoft }}>
                <select
                  value={o.status}
                  onChange={(e) => onQuickStatus(o, e.target.value)}
                  className="text-xs font-semibold rounded-full px-2.5 py-1 border focus:outline-none"
                  style={{ color: STATUS_COLORS[o.status], borderColor: T.borderSoft, backgroundColor: STATUS_COLORS[o.status] + "1A" }}
                >
                  {ORDER_STATUSES.map((s) => <option key={s} value={s}>{t(`status.${s}`, s)}</option>)}
                </select>
                <div className="flex items-center gap-1">
                  <ContactActions phone={o.customerPhone} message={orderWaMessage(o, shopName)} />
                  <IconBtn onClick={() => onReceipt(o)} label={t("orders.receipt", "Receipt")}><Printer size={15} /></IconBtn>
                  <IconBtn onClick={() => onEdit(o)} label={t("orders.edit", "Edit")}><Pencil size={15} /></IconBtn>
                  <IconBtn onClick={() => onDuplicate(o)} label={t("orders.duplicate", "Duplicate as new order")}><Copy size={15} /></IconBtn>
                  <IconBtn onClick={() => onDelete(o)} label={t("orders.delete", "Delete")} danger><Trash2 size={15} /></IconBtn>
                </div>
              </div>
            </div>
          ))}
          <ShowMore page={page} t={t} />
        </div>
      )}
    </div>
  );
}

/* ============================== CUSTOMERS ============================== */
export function CustomersTab({ customers, t, balanceFilter, setBalanceFilter, sortBy, setSortBy, shopName, onEdit, onDelete, onAdd, onView }) {
  const [search, setSearch] = useState("");
  const dq = useDeferredValue(search);
  const filtered = customers
    .filter((c) => {
      const q = dq.trim().toLowerCase();
      if (!q) return true;
      return c.name.toLowerCase().includes(q) || (c.phone || "").includes(q);
    })
    .filter((c) => balanceFilter === "All" || (balanceFilter === "Due" && c.outstanding > 0))
    .sort((a, b) => {
      if (sortBy === "recent") return (b.lastOrderDate || "").localeCompare(a.lastOrderDate || "");
      if (sortBy === "name") return a.name.localeCompare(b.name);
      return b.totalSpent - a.totalSpent;
    });
  const page = usePagedList(filtered, `${dq}|${balanceFilter}|${sortBy}|${filtered.length}`);


  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between">
        <div className="relative w-full sm:w-64">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: T.inkFaint }} />
          <TextInput placeholder={t("customers.searchPlaceholder", "Search name or phone")} value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <div className="flex gap-2">
          <SelectInput value={balanceFilter} onChange={(e) => setBalanceFilter(e.target.value)} className="flex-1 sm:flex-none sm:w-40">
            <option value="All">{t("customers.allCustomers", "All customers")}</option>
            <option value="Due">{t("customers.withBalanceDue", "With balance due")}</option>
          </SelectInput>
          <SelectInput value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="flex-1 sm:flex-none sm:w-40">
            <option value="spend">{t("customers.sortTopSpenders", "Sort: Top spenders")}</option>
            <option value="recent">{t("customers.sortMostRecent", "Sort: Most recent")}</option>
            <option value="name">{t("customers.sortName", "Sort: Name (A–Z)")}</option>
          </SelectInput>
        </div>
      </div>

      {customers.length === 0 ? (
        <EmptyState icon={Users} title={t("customers.noCustomersYet", "No customers yet")} subtitle={t("customers.noCustomersSubtitle", "Customers are added automatically when you create an order — or add one directly.")} actionLabel={t("customers.addCustomer", "Add customer")} onAction={onAdd} />
      ) : filtered.length === 0 ? (
        <p className="text-sm text-center py-10" style={{ color: T.inkFaint }}>{t("customers.noMatch", "No customers match your filters.")}</p>
      ) : (
        <>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {page.visible.map((c) => (
            <div key={c.id} className="rounded-lg border p-4 cursor-pointer" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }} onClick={() => onView(c)}>
              <div className="flex items-start justify-between">
                <div className="min-w-0">
                  <p className="text-sm font-semibold truncate" style={{ color: T.ink }}>{c.name}</p>
                  <p className="text-xs flex items-center gap-1 mt-0.5" style={{ color: T.inkSoft }}><Phone size={11} />{c.phone}</p>
                </div>
                <div className="flex gap-0.5" onClick={(e) => e.stopPropagation()}>
                  <ContactActions phone={c.phone} message={customerWaMessage(c, shopName)} size={14} />
                  <IconBtn onClick={() => onEdit(c)} label={t("action.edit", "Edit")}><Pencil size={14} /></IconBtn>
                  <IconBtn onClick={() => onDelete(c)} label={t("action.delete", "Delete")} danger><Trash2 size={14} /></IconBtn>
                </div>
              </div>
              <div className="flex items-center justify-between mt-3 pt-3 border-t" style={{ borderColor: T.borderSoft }}>
                <div>
                  <p className="text-xs" style={{ color: T.inkFaint }}>{c.totalOrders} {t("orders.ordersWord", c.totalOrders === 1 ? "order" : "orders")}</p>
                  <p className="text-xs" style={{ color: T.inkFaint }}>{t("customers.last", "Last:")} {c.lastOrderDate ? fmtShortDate(c.lastOrderDate) : "—"}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold tabular-nums" style={{ color: T.teal }}>{fmtMoney(c.totalSpent)}</p>
                  {c.outstanding > 0 && <p className="text-xs font-medium tabular-nums" style={{ color: T.danger }}>{fmtMoney(c.outstanding)} {t("customers.due", "due")}</p>}
                </div>
              </div>
            </div>
          ))}
        </div>
        <ShowMore page={page} t={t} />
        </>
      )}
    </div>
  );
}

/* ============================== FINANCE ============================== */
export function FinanceTab({ expenses, ordersComputed, orderCOGS, products, t, onViewProduct, catFilter, setCatFilter, dateFilter, setDateFilter, rangeStart, setRangeStart, rangeEnd, setRangeEnd, onEdit, onDelete, onAdd }) {
  const allExpenseCats = useMemo(
    () => Array.from(new Set([...EXPENSE_CATEGORIES, ...expenses.map((e) => e.category).filter(Boolean)])),
    [expenses]
  );
  const dateRange = useMemo(() => resolveDateRange(dateFilter, rangeStart, rangeEnd), [dateFilter, rangeStart, rangeEnd]);
  const inRange = (dateStr) => !dateRange || (dateStr >= dateRange[0] && dateStr <= dateRange[1]);

  // The whole P&L below is scoped to the selected period, not just the expense list —
  // "This month" should mean this month's sales and profit too, not all-time sales
  // next to a filtered expense list.
  const periodOrders = useMemo(
    () => ordersComputed.filter((o) => o.status !== "Cancelled" && o.status !== "Returned" && inRange(o.date)),
    [ordersComputed, dateRange]
  );
  const periodExpensesAll = useMemo(() => expenses.filter((e) => inRange(e.date)), [expenses, dateRange]);
  const periodFinance = useMemo(() => {
    const totalSales = periodOrders.reduce((s, o) => s + o.total, 0);
    const totalAdvance = periodOrders.reduce((s, o) => s + num(o.advance), 0);
    const totalOutstanding = periodOrders.reduce((s, o) => s + o.balance, 0);
    const cogs = periodOrders.reduce((s, o) => s + orderCOGS(o), 0);
    const totalExpenses = periodExpensesAll.reduce((s, e) => s + num(e.amount), 0);
    const grossProfit = totalSales - cogs;
    const netProfit = grossProfit - totalExpenses;
    return { totalSales, totalAdvance, totalOutstanding, cogs, totalExpenses, grossProfit, netProfit };
  }, [periodOrders, periodExpensesAll, orderCOGS]);

  const periodLabel = dateFilter === "All time" || !dateRange ? t("finance.allTime", "All time") : `${dateFilter} · ${fmtShortDate(dateRange[0])} – ${fmtShortDate(dateRange[1])}`;

  // Per-product breakdown for the same period — which items actually drove that
  // Total Sales figure above. Custom/one-off items (no catalogue link) group under
  // their typed name since there's no product record to attach them to.
  const [productQuery, setProductQuery] = useState("");
  const [productsExpanded, setProductsExpanded] = useState(false);
  const productSalesAll = useMemo(() => {
    const map = new Map();
    periodOrders.forEach((o) => {
      // An order-level discount isn't attributed to any one item, so it's spread
      // proportionally across the order's lines here — otherwise this table's totals
      // would drift away from Total Sales above by exactly the discounted amount,
      // which reads as a bug even though neither number would be individually wrong.
      const discountRate = o.subtotal > 0 ? o.discount / o.subtotal : 0;
      (o.items || []).forEach((it) => {
        const key = it.productId || `custom:${it.name}`;
        const sku = it.sku || (it.productId ? (products.find((p) => p.id === it.productId)?.sku || "") : "");
        const row = map.get(key) || { key, productId: it.productId || null, name: it.name, sku, category: it.category, qty: 0, revenue: 0, cost: 0 };
        row.qty += num(it.qty);
        const inclusive = num(it.qty) * num(it.unitPrice) * (1 - discountRate);
        row.revenue += inclusive;
        row.cost += num(it.qty) * (it.unitCost !== undefined && it.unitCost !== "" ? num(it.unitCost) : 0);
        map.set(key, row);
      });
    });
    return [...map.values()].sort((a, b) => b.revenue - a.revenue);
  }, [periodOrders, products]);
  // Kept separate from productSalesAll on purpose — if a search matches nothing, only
  // the *rows* should empty out. The header summary and the search box itself need
  // the unfiltered count, or typing a query with no matches would make the whole
  // section (search box included) collapse away with no way to see or clear it.
  const productSales = useMemo(() => {
    const q = productQuery.trim().toLowerCase();
    if (!q) return productSalesAll;
    return productSalesAll.filter((r) => r.name.toLowerCase().includes(q) || (r.sku || "").toLowerCase().includes(q));
  }, [productSalesAll, productQuery]);

  // Category filter narrows the expense *list* for browsing — the P&L total above
  // still reflects every category so it stays a true period total.
  const filtered = periodExpensesAll
    .filter((e) => catFilter === "All" || e.category === catFilter)
    .sort((a, b) => (a.date < b.date ? 1 : -1));
  const filteredTotal = filtered.reduce((s, e) => s + num(e.amount), 0);
  const isCatFiltered = catFilter !== "All";
  const page = usePagedList(filtered, `${catFilter}|${dateFilter}|${rangeStart}|${rangeEnd}|${filtered.length}`);

  const plRows = [
    ["totalSales", t("finance.totalSales", "Total sales"), periodFinance.totalSales, T.ink],
    ["advanceCollected", t("finance.advanceCollected", "Advance collected"), periodFinance.totalAdvance, T.ink],
    ["outstandingBalance", t("finance.outstandingBalance", "Outstanding balance"), periodFinance.totalOutstanding, T.warn],
    ["cogs", t("finance.cogs", "Estimated cost of goods sold"), -periodFinance.cogs, T.inkSoft],
    ["grossProfit", t("finance.grossProfit", "Gross profit"), periodFinance.grossProfit, T.ink],
    ["totalExpenses", t("finance.totalExpenses", "Total expenses"), -periodFinance.totalExpenses, T.inkSoft],
  ];
  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between">
        <p className="text-xs" style={{ color: T.inkFaint }}>{t("finance.showing", "Showing")} <span style={{ color: T.inkSoft }}>{periodLabel}</span></p>
        <DateFilterControl preset={dateFilter} setPreset={setDateFilter} start={rangeStart} setStart={setRangeStart} end={rangeEnd} setEnd={setRangeEnd} t={t} />
      </div>

      <div className="rounded-lg border p-5" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
        <p className="text-sm font-semibold mb-4" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>{t("finance.pnl", "Profit & loss")} — {periodLabel}</p>
        <div className="flex flex-col divide-y" style={{ borderColor: T.borderSoft }}>
          {plRows.map(([id, label, val]) => (
            <div key={id} className="flex items-center justify-between py-2 text-sm">
              <span style={{ color: T.inkSoft }}>{label}</span>
              <span className="tabular-nums font-medium" style={{ color: val < 0 ? T.danger : T.ink }}>
                {val < 0 ? "(" + fmtMoney(Math.abs(val)) + ")" : fmtMoney(val)}
              </span>
            </div>
          ))}
          <div className="flex items-center justify-between pt-3 mt-1">
            <span className="text-sm font-semibold" style={{ color: T.ink }}>{t("finance.netProfit", "Net profit")}</span>
            <span className="text-lg font-semibold tabular-nums" style={{ color: periodFinance.netProfit >= 0 ? T.success : T.danger, fontFamily: FONT_DISPLAY }}>
              {fmtMoney(periodFinance.netProfit)}
            </span>
          </div>
        </div>
      </div>

      <div className="rounded-lg border overflow-hidden" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
        <button
          type="button"
          onClick={() => setProductsExpanded((v) => !v)}
          className="w-full flex items-center justify-between gap-3 px-5 py-4 text-left"
        >
          <div className="min-w-0">
            <p className="text-sm font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>{t("finance.salesByProduct", "Sales by product")} — {periodLabel}</p>
            {productSalesAll.length > 0 ? (
              <p className="text-xs mt-0.5 truncate" style={{ color: T.inkFaint }}>
                {productSalesAll.length} {t("finance.itemsSold", "items sold")} · {t("finance.top", "Top:")} {productSalesAll[0].name} ({fmtMoney(productSalesAll[0].revenue)})
              </p>
            ) : (
              <p className="text-xs mt-0.5" style={{ color: T.inkFaint }}>{t("finance.noSalesYet", "No sales in this period yet")}</p>
            )}
          </div>
          {productSalesAll.length > 0 && (
            <ChevronDown size={18} style={{ color: T.inkFaint, flexShrink: 0, transform: productsExpanded ? "rotate(180deg)" : "none", transition: "transform 0.15s" }} />
          )}
        </button>

        {productsExpanded && productSalesAll.length > 0 && (
          <div className="border-t" style={{ borderColor: T.borderSoft }}>
            <div className="p-3 border-b" style={{ borderColor: T.borderSoft }}>
              <div className="relative">
                <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: T.inkFaint }} />
                <TextInput placeholder={t("finance.searchProduct", "Search product…")} value={productQuery} onChange={(e) => setProductQuery(e.target.value)} className="pl-8" />
              </div>
            </div>
            <div className="divide-y max-h-96 overflow-y-auto" style={{ borderColor: T.borderSoft }}>
              {productSales.length === 0 ? (
                <p className="text-sm text-center py-6" style={{ color: T.inkFaint }}>{t("finance.noProductsMatch", "No products match")} "{productQuery}"</p>
              ) : (
                productSales.map((r) => {
                  const profit = r.revenue - r.cost;
                  const clickable = !!r.productId && !!onViewProduct;
                  return (
                    <div
                      key={r.key}
                      onClick={clickable ? () => onViewProduct(r.productId) : undefined}
                      className={`flex items-start justify-between gap-3 px-5 py-3 ${clickable ? "cursor-pointer transition-colors" : ""}`}
                      onMouseEnter={clickable ? (e) => (e.currentTarget.style.backgroundColor = `color-mix(in oklab, ${T.borderSoft} 25%, transparent)`) : undefined}
                      onMouseLeave={clickable ? (e) => (e.currentTarget.style.backgroundColor = "transparent") : undefined}
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate" style={{ color: T.ink }}>{r.name}</p>
                        <div className="flex items-center gap-2 flex-wrap mt-0.5">
                          {r.category && <CategoryTag category={r.category} />}
                          {r.sku ? (
                            <span className="text-xs" style={{ color: T.inkFaint, fontFamily: FONT_MONO }}>{r.sku}</span>
                          ) : (
                            <span className="text-xs" style={{ color: T.inkFaint }}>{t("finance.customItem", "Custom item")}</span>
                          )}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-sm font-semibold tabular-nums" style={{ color: T.ink }}>{fmtMoney(r.revenue)}</p>
                        <p className="text-xs tabular-nums mt-0.5" style={{ color: T.inkFaint }}>
                          {r.qty} {t("finance.sold", "sold")} · <span style={{ color: profit >= 0 ? T.success : T.danger }}>{fmtMoney(profit)} {t("finance.profit", "profit")}</span>
                        </p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>

      <div>
        <div className="flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between mb-3">
          <p className="text-sm font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>{t("finance.expenses", "Expenses")}</p>
          {expenses.length > 0 && (
            <SelectInput value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className="w-full sm:w-40">
              <option value="All">{t("finance.allCategories", "All categories")}</option>
              {allExpenseCats.map((c) => <option key={c} value={c}>{c}</option>)}
            </SelectInput>
          )}
        </div>
        {expenses.length === 0 ? (
          <EmptyState icon={Wallet} title={t("finance.noExpensesLogged", "No expenses logged")} subtitle={t("finance.noExpensesSubtitle", "Track materials, rent, electricity and wages here to see your true profit.")} actionLabel={t("finance.addExpense", "Add expense")} onAction={onAdd} />
        ) : filtered.length === 0 ? (
          <p className="text-sm text-center py-10" style={{ color: T.inkFaint }}>{t("finance.noExpensesMatch", "No expenses match your filters.")}</p>
        ) : (
          <div className="rounded-lg border overflow-hidden" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
            {(isCatFiltered || dateFilter !== "All time") && (
              <div className="flex items-center justify-between px-5 py-2.5 text-xs font-medium font-mono tabular-nums" style={{ backgroundColor: T.tealSoft, color: T.teal }}>
                <span>{filtered.length} {t("finance.expensesShown", "expenses shown")}</span>
                <span>{t("finance.subtotal", "Subtotal:")} {fmtMoney(filteredTotal)}</span>
              </div>
            )}
            <div className="divide-y" style={{ borderColor: T.borderSoft }}>
              {page.visible.map((e) => (
                <div key={e.id} className="flex items-center justify-between px-5 py-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: T.ink }}>{e.description || e.category}</p>
                    <p className="text-xs mt-0.5" style={{ color: T.inkFaint }}>{fmtShortDate(e.date)} · {e.category} · {e.paymentMode}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm font-semibold tabular-nums" style={{ color: T.ink }}>{fmtMoney(e.amount)}</span>
                    <IconBtn onClick={() => onEdit(e)} label={t("action.edit", "Edit")}><Pencil size={14} /></IconBtn>
                    <IconBtn onClick={() => onDelete(e)} label={t("action.delete", "Delete")} danger><Trash2 size={14} /></IconBtn>
                  </div>
                </div>
              ))}
            </div>
            <ShowMore page={page} t={t} />
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================== MODALS ============================== */

