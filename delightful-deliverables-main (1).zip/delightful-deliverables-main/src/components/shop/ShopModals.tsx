// @ts-nocheck
import React, { useState, useEffect, useMemo, useCallback, useRef, lazy, Suspense } from "react";
import { Plus, X, Trash2, Settings, Download, Frame, Phone, MapPin, PackagePlus, FileSpreadsheet, Upload, Image, Printer, Sun, Moon, Store, UserRound, Users, Database, ShieldAlert, Check, ChevronRight, ArrowLeft, Languages, LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import * as shopBackup from "./shopBackup";
import { firstError, productSchema, customerSchema } from "./shopSchemas";
import { T, FONT_MONO, CATEGORIES, PAYMENT_MODES, ORDER_TYPES, ORDER_STATUSES, EXPENSE_CATEGORIES, LANGUAGES, genId, nextSku, todayStr, fmtMoney, fmtDate, fmtShortDate, num, nonNeg, orderPayments, orderDiscount, normalizePhone, waLink, telLink, resizeImageToDataUrl, orderWaMessage, customerWaMessage, Badge, CategoryTag, StatusBadge, IconBtn, WhatsAppGlyph, ContactActions, SearchableProductSelect, PrimaryButton, GhostButton, Field, TextInput, SelectInput, TextArea, OtherableSelect, Modal, StatCard } from "./shopShared";

/* ============================== BULK IMPORT ==============================
   Lets a shop bring an existing product or customer list in from a spreadsheet
   instead of typing hundreds of rows. Nothing is saved until the person has seen
   exactly what will be added, what will be updated, and what was skipped and why.
   Matching is on the thing that's already unique in the app: SKU for products,
   phone number for customers. */
export const normHeader = (h) => String(h == null ? "" : h).toLowerCase().replace(/[^a-z0-9]/g, "");

// Each field lists the spreadsheet column names it will accept, most specific first.
export const IMPORT_FIELDS = {
  products: [
    { key: "sku", label: "SKU", aliases: ["sku", "code", "itemcode", "productcode"] },
    { key: "name", label: "Item name", aliases: ["itemname", "productname", "name", "product", "item"], required: true },
    { key: "category", label: "Category", aliases: ["category", "type"] },
    { key: "size", label: "Size", aliases: ["size"] },
    { key: "customization", label: "Customization", aliases: ["customization", "customisation", "notes"] },
    { key: "costPrice", label: "Cost price", aliases: ["costprice", "cost", "purchaseprice", "buyprice"], number: true },
    { key: "sellingPrice", label: "Selling price", aliases: ["sellingprice", "price", "mrp", "rate", "saleprice"], number: true },
    { key: "openingStock", label: "Opening stock", aliases: ["openingstock", "stock", "quantity", "qty", "currentstock"], number: true },
    { key: "reorderLevel", label: "Reorder level", aliases: ["reorderlevel", "reorder", "minstock", "minimumstock"], number: true },
  ],
  customers: [
    { key: "name", label: "Name", aliases: ["customername", "name", "customer"], required: true },
    { key: "phone", label: "Phone", aliases: ["phone", "mobile", "phonenumber", "contact", "mobilenumber"], required: true },
    { key: "address", label: "Address", aliases: ["address", "location"] },
    { key: "notes", label: "Notes", aliases: ["notes", "note", "remarks"] },
  ],
};

export function ImportModal({ kind, existing, t, onClose, onConfirm }) {
  const fields = IMPORT_FIELDS[kind];
  const isProducts = kind === "products";
  const [rows, setRows] = useState(null);
  const [fileName, setFileName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const readFile = async (file) => {
    if (!file) return;
    setBusy(true); setError(""); setRows(null); setFileName(file.name);
    try {
      const XLSX = await import("xlsx");
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const raw = XLSX.utils.sheet_to_json(ws, { defval: "" });
      if (!raw.length) { setError("That file has no rows in its first sheet."); setBusy(false); return; }

      // Work out which spreadsheet column feeds which field, whatever it's called.
      const headers = Object.keys(raw[0]);
      const map = {};
      fields.forEach((f) => {
        const hit = headers.find((h) => f.aliases.includes(normHeader(h)));
        if (hit) map[f.key] = hit;
      });
      const missingRequired = fields.filter((f) => f.required && !map[f.key]);
      if (missingRequired.length) {
        setError(`Couldn't find a column for: ${missingRequired.map((f) => f.label).join(", ")}. Rename the column heading in your file and try again.`);
        setBusy(false);
        return;
      }

      const seen = new Set();
      const parsed = raw.map((r, i) => {
        const rec = {};
        fields.forEach((f) => {
          const v = map[f.key] ? r[map[f.key]] : "";
          rec[f.key] = f.number ? num(String(v).replace(/[^0-9.\-]/g, "")) : String(v == null ? "" : v).trim();
        });
        if (isProducts) {
          if (!rec.category) rec.category = CATEGORIES[0];
          if (!rec.reorderLevel) rec.reorderLevel = 5;
        }
        const out = { line: i + 2, rec };
        const blank = fields.filter((f) => f.required).every((f) => !rec[f.key]);
        if (blank) return { ...out, status: "skip", reason: "Empty row" };

        const matchKey = isProducts ? String(rec.sku || "").toLowerCase() : String(rec.phone || "").replace(/\D/g, "");
        if (matchKey) {
          if (seen.has(matchKey)) return { ...out, status: "skip", reason: isProducts ? "Same SKU appears earlier in the file" : "Same phone number appears earlier in the file" };
          seen.add(matchKey);
        }
        const match = matchKey
          ? existing.find((e) => (isProducts ? String(e.sku || "").toLowerCase() === matchKey : String(e.phone || "").replace(/\D/g, "") === matchKey))
          : null;

        const full = match
          ? { ...match, ...rec, id: match.id, sku: rec.sku || match.sku }
          : { ...rec, id: genId(isProducts ? "prod" : "cust"), ...(isProducts ? { restocks: [] } : {}) };
        const err = firstError(isProducts ? productSchema : customerSchema, full);
        if (err) return { ...out, rec: full, status: "skip", reason: err };
        return { ...out, rec: full, status: match ? "update" : "new" };
      });
      setRows(parsed);
    } catch (e) {
      setError("Could not read that file. Please use a .csv or .xlsx spreadsheet.");
    } finally {
      setBusy(false);
    }
  };

  const counts = useMemo(() => {
    const c = { new: 0, update: 0, skip: 0 };
    (rows || []).forEach((r) => { c[r.status] += 1; });
    return c;
  }, [rows]);

  const confirm = async () => {
    setSaving(true);
    await onConfirm((rows || []).filter((r) => r.status !== "skip"));
    setSaving(false);
  };

  const statusColor = (s) => (s === "new" ? T.success : s === "update" ? T.teal : T.inkFaint);
  const statusLabel = (s) => (s === "new" ? "Will be added" : s === "update" ? "Will be updated" : "Skipped");

  return (
    <Modal wide title={isProducts ? t("import.productsTitle", "Import products from a spreadsheet") : t("import.customersTitle", "Import customers from a spreadsheet")} onClose={onClose}>
      <div className="flex flex-col gap-4">
        <p className="text-xs leading-relaxed" style={{ color: T.inkSoft }}>
          {t("import.help", "Upload a .csv or .xlsx file where the first row holds the column headings.")}{" "}
          {t("import.columns", "Columns we can read:")} <span style={{ color: T.ink }}>{fields.map((f) => f.label + (f.required ? "*" : "")).join(", ")}</span>.{" "}
          {isProducts
            ? t("import.matchProducts", "Rows with an SKU that already exists will update that product instead of creating a second one.")
            : t("import.matchCustomers", "Rows with a phone number that already exists will update that customer instead of creating a duplicate.")}
        </p>

        <label className="flex items-center justify-center gap-2 px-4 py-6 rounded-md border border-dashed cursor-pointer text-sm font-semibold"
          style={{ borderColor: T.border, color: T.ink, backgroundColor: T.bg }}>
          <Upload size={16} />
          {busy ? t("import.reading", "Reading file…") : fileName || t("import.choose", "Choose a spreadsheet")}
          <input type="file" accept=".csv,.xlsx,.xls" className="hidden" onChange={(e) => readFile(e.target.files?.[0])} />
        </label>

        {error && <p className="text-xs" style={{ color: T.danger }}>{error}</p>}

        {rows && (
          <>
            <div className="flex flex-wrap gap-2">
              <Badge text={`${counts.new} ${t("import.toAdd", "to add")}`} color={T.success} soft={T.successSoft} />
              <Badge text={`${counts.update} ${t("import.toUpdate", "to update")}`} color={T.teal} soft={T.tealSoft} />
              <Badge text={`${counts.skip} ${t("import.skipped", "skipped")}`} color={T.inkFaint} soft={T.borderSoft} />
            </div>
            <div className="rounded-md border overflow-hidden" style={{ borderColor: T.borderSoft }}>
              <div className="max-h-64 overflow-y-auto divide-y" style={{ borderColor: T.borderSoft }}>
                {rows.slice(0, 200).map((r) => (
                  <div key={r.line} className="px-3 py-2 flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm truncate" style={{ color: T.ink }}>
                        {r.rec.name || t("import.unnamed", "(no name)")}
                        {isProducts && r.rec.sku ? <span style={{ color: T.inkFaint }}> · {r.rec.sku}</span> : null}
                        {!isProducts && r.rec.phone ? <span style={{ color: T.inkFaint }}> · {r.rec.phone}</span> : null}
                      </p>
                      {r.status === "skip" && <p className="text-[11px]" style={{ color: T.inkFaint }}>{t("import.row", "Row")} {r.line} — {r.reason}</p>}
                    </div>
                    <span className="text-[11px] font-semibold whitespace-nowrap pt-0.5" style={{ color: statusColor(r.status) }}>{statusLabel(r.status)}</span>
                  </div>
                ))}
              </div>
            </div>
            {rows.length > 200 && <p className="text-[11px]" style={{ color: T.inkFaint }}>{t("import.previewNote", "Showing the first 200 rows — everything in the file will be imported.")}</p>}
          </>
        )}

        <div className="flex gap-2 justify-end">
          <GhostButton onClick={onClose}>{t("action.cancel", "Cancel")}</GhostButton>
          <PrimaryButton onClick={confirm}>
            {saving
              ? t("import.importing", "Importing…")
              : `${t("import.confirm", "Import")} ${counts.new + counts.update} ${t("import.records", "records")}`}
          </PrimaryButton>
        </div>
      </div>
    </Modal>
  );
}


export function ProductModal({ product, products, t, onClose, onSave }) {
  const isEdit = !!product.id;
  const [form, setForm] = useState({
    id: product.id || genId("SKU"),
    sku: product.sku || (isEdit ? "" : nextSku(product.category || CATEGORIES[0], products || [])),
    category: product.category || CATEGORIES[0],
    name: product.name || "",
    size: product.size || "",
    customization: product.customization || "",
    costPrice: product.costPrice ?? "",
    sellingPrice: product.sellingPrice ?? "",
    openingStock: product.openingStock ?? "",
    reorderLevel: product.reorderLevel ?? 5,
    active: product.active !== false,
  });
  const [skuTouched, setSkuTouched] = useState(isEdit);
  const [error, setError] = useState("");
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const belowCost = num(form.sellingPrice) > 0 && num(form.costPrice) > 0 && num(form.sellingPrice) < num(form.costPrice);
  const submit = (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    const finalSku = form.sku.trim() || form.id;
    const dup = (products || []).some((p) => p.id !== form.id && (p.sku || "").toLowerCase() === finalSku.toLowerCase());
    if (dup) { setError(`SKU "${finalSku}" is already used by another product — pick a different one.`); return; }
    onSave({
      ...form,
      sku: finalSku,
      costPrice: nonNeg(form.costPrice),
      sellingPrice: nonNeg(form.sellingPrice),
      openingStock: nonNeg(form.openingStock),
      reorderLevel: nonNeg(form.reorderLevel),
      restocks: product.restocks || [],
    });
  };
  return (
    <Modal title={isEdit ? t("form.product.editTitle", "Edit product") : t("form.product.addTitle", "Add product")} onClose={onClose}>
      <form onSubmit={submit} className="flex flex-col gap-3.5">
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("form.product.category", "Category")} required>
            <OtherableSelect
              options={CATEGORIES}
              value={form.category}
              onChange={(v) => {
                const next = { ...form, category: v };
                if (!skuTouched) next.sku = nextSku(v, products || []);
                setForm(next);
              }}
              placeholder={t("form.product.categoryPlaceholder", "e.g. Metal Frame, Photo Album")}
            />
          </Field>
          <Field label={t("form.product.sku", "Product ID / SKU")}>
            <TextInput value={form.sku} onChange={(e) => { setSkuTouched(true); setError(""); set("sku")(e); }} />
          </Field>
        </div>
        {!skuTouched && !error && <p className="text-xs -mt-2" style={{ color: T.inkFaint }}>{t("form.product.skuAutoGen", "Auto-generated from category — edit it any time.")}</p>}
        {error && <p className="text-xs -mt-2" style={{ color: T.danger }}>{error}</p>}
        <Field label={t("form.product.name", "Item name")} required>
          <TextInput required value={form.name} onChange={set("name")} placeholder={t("form.product.namePlaceholder", "e.g. Classic Wooden Photo Frame")} />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("form.product.size", "Size")}><TextInput value={form.size} onChange={set("size")} placeholder={t("form.product.sizePlaceholder", "e.g. 8x10 inch")} /></Field>
          <Field label={t("form.product.customization", "Customization")}><TextInput value={form.customization} onChange={set("customization")} placeholder={t("form.product.customizationPlaceholder", "e.g. Engraving available")} /></Field>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("form.product.costPrice", "Cost price (₹)")} required><TextInput type="number" min="0" required value={form.costPrice} onChange={set("costPrice")} /></Field>
          <Field label={t("form.product.sellingPrice", "Selling price (₹)")} required><TextInput type="number" min="0" required value={form.sellingPrice} onChange={set("sellingPrice")} /></Field>
        </div>
        {belowCost && <p className="text-xs -mt-2" style={{ color: T.warn }}>{t("form.product.belowCost", "Selling price is below cost price — this item will show as a loss.")}</p>}
        <div className="grid grid-cols-2 gap-3">
          <Field label={isEdit ? t("form.product.openingStockEdit", "Opening stock (first count)") : t("form.product.openingStockAdd", "Opening stock (qty)")} required>
            <TextInput type="number" min="0" required value={form.openingStock} onChange={set("openingStock")} />
          </Field>
          <Field label={t("form.product.reorderLevel", "Reorder level")}><TextInput type="number" min="0" value={form.reorderLevel} onChange={set("reorderLevel")} /></Field>
        </div>
        {isEdit && <p className="text-xs -mt-2" style={{ color: T.inkFaint }}>{t("form.product.restockHint", "To add newly received stock, use the restock button on the Stock list instead of editing this number.")}</p>}
        {isEdit && (
          <div className="border-t pt-3" style={{ borderColor: T.borderSoft }}>
            <label className="flex items-center gap-2 text-sm cursor-pointer" style={{ color: T.ink }}>
              <input type="checkbox" checked={!form.active} onChange={(e) => setForm({ ...form, active: !e.target.checked })} />
              {t("form.product.discontinuedLabel", "Discontinued — hide from new orders")}
            </label>
            <p className="text-xs mt-1" style={{ color: T.inkFaint }}>{t("form.product.discontinuedHint", "Stays in Stock and in every past order exactly as before — this only removes it from the picker when creating new orders.")}</p>
          </div>
        )}
        <div className="flex gap-2 pt-2">
          <GhostButton onClick={onClose} full>{t("action.cancel", "Cancel")}</GhostButton>
          <PrimaryButton type="submit" full>{t("form.product.saveButton", "Save product")}</PrimaryButton>
        </div>
      </form>
    </Modal>
  );
}

export function RestockModal({ product, t, onClose, onSave }) {
  const [qty, setQty] = useState("");
  const [date, setDate] = useState(todayStr());
  const [note, setNote] = useState("");
  const submit = (e) => {
    e.preventDefault();
    if (!num(qty) || num(qty) <= 0) return;
    onSave({ id: genId("RS"), date, qty: num(qty), note: note.trim() });
  };
  return (
    <Modal title={t("form.restock.title", `Restock — ${product.name}`, { name: product.name })} onClose={onClose}>
      <form onSubmit={submit} className="flex flex-col gap-3.5">
        <p className="text-xs" style={{ color: T.inkSoft }}>
          {t("form.restock.currentStock", `Currently ${product.current} pcs in stock (${product.received} received so far, ${product.sold} sold).`, { current: product.current, received: product.received, sold: product.sold })}
        </p>
        <Field label={t("form.restock.quantity", "Quantity received")} required>
          <TextInput type="number" min="1" required value={qty} onChange={(e) => setQty(e.target.value)} placeholder={t("form.restock.quantityPlaceholder", "e.g. 10")} />
        </Field>
        <Field label={t("form.restock.date", "Date")}><TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} /></Field>
        <Field label={t("form.restock.note", "Note")}><TextInput value={note} onChange={(e) => setNote(e.target.value)} placeholder={t("form.restock.notePlaceholder", "e.g. From supplier, invoice #45")} /></Field>
        <div className="flex gap-2 pt-2">
          <GhostButton onClick={onClose} full>{t("action.cancel", "Cancel")}</GhostButton>
          <PrimaryButton type="submit" full>{t("form.restock.addButton", "Add to stock")}</PrimaryButton>
        </div>
      </form>
    </Modal>
  );
}

export function OrderModal({ order, products, productsComputed, customerOptions, shopName, settings, t, onClose, onSave }) {
  const isEdit = !!order.id;
  const blankItem = () => ({ rowId: genId("ROW"), productId: "", name: "", category: CATEGORIES[0], sku: "", qty: 1, unitPrice: "", unitCost: "", customPhoto: false, customPhotoNote: "", customPhotoDataUrl: "" });
  const [form, setForm] = useState({
    id: order.id || genId("ORD"),
    orderNo: order.orderNo || "ORD-" + Date.now().toString().slice(-6),
    date: order.date || todayStr(),
    customerName: order.customerName || "",
    customerPhone: order.customerPhone || "",
    orderType: order.orderType || "Walk-in",
    items: order.items && order.items.length ? order.items.map((it) => ({ customPhoto: false, customPhotoNote: "", customPhotoDataUrl: "", sku: "", ...it })) : [blankItem()],
    discountType: order.discountType || "none",
    discountValue: order.discountValue ?? "",
    splitPayment: !!(order.payments && order.payments.length > 1),
    payments: order.payments && order.payments.length ? order.payments : [{ id: genId("PAY"), mode: order.paymentMode || "Cash", amount: "" }, { id: genId("PAY"), mode: "UPI", amount: "" }],
    advance: order.advance ?? "",
    paymentMode: order.paymentMode || "Cash",
    deliveryDate: order.deliveryDate || "",
    status: order.status || "Pending",
    notes: order.notes || "",
  });
  const [error, setError] = useState("");
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const updateItem = (rowId, patch) => {
    setForm({ ...form, items: form.items.map((it) => (it.rowId === rowId ? { ...it, ...patch } : it)) });
  };
  const updatePayment = (id, patch) => {
    setForm({ ...form, payments: form.payments.map((p) => (p.id === id ? { ...p, ...patch } : p)) });
  };
  const addPaymentRow = () => {
    if (form.payments.length >= 4) return; // more than 4 methods on one sale is vanishingly rare and just clutters the form
    setForm({ ...form, payments: [...form.payments, { id: genId("PAY"), mode: "Cash", amount: "" }] });
  };
  const removePaymentRow = (id) => {
    setForm({ ...form, payments: form.payments.filter((p) => p.id !== id) });
  };
  const onPickProduct = (rowId, productId) => {
    if (!productId) {
      updateItem(rowId, { productId: "", name: "", category: CATEGORIES[0], sku: "", unitPrice: "", unitCost: "" });
      return;
    }
    const p = products.find((p) => p.id === productId);
    if (p) updateItem(rowId, { productId: p.id, name: p.name, category: p.category, sku: p.sku || "", unitPrice: p.sellingPrice, unitCost: p.costPrice });
  };
  const addItemRow = () => setForm({ ...form, items: [...form.items, blankItem()] });
  const removeItemRow = (rowId) => setForm({ ...form, items: form.items.filter((it) => it.rowId !== rowId) });

  // How many of a product are available for *this* line, accounting for the fact
  // that (when editing) this same order already counted its own qty as "sold".
  const availableFor = (productId) => {
    const p = productsComputed.find((pr) => pr.id === productId);
    if (!p) return null;
    let already = 0;
    if (isEdit) (order.items || []).forEach((it) => { if (it.productId === productId) already += num(it.qty); });
    return p.current + already;
  };

  const subtotal = form.items.reduce((s, it) => s + num(it.qty) * num(it.unitPrice), 0);
  const discount = orderDiscount(form, subtotal);
  const total = subtotal - discount;
  const splitTotal = form.payments.reduce((s, p) => s + nonNeg(p.amount), 0);
  const effectiveAdvance = form.splitPayment ? splitTotal : num(form.advance);
  const balance = total - effectiveAdvance;
  const dateIssue = form.deliveryDate && form.deliveryDate < form.date;

  const submit = (e) => {
    e.preventDefault();
    const cleanItems = form.items
      .filter((it) => it.name.trim())
      .map((it) => ({ ...it, qty: Math.max(1, nonNeg(it.qty) || 1), unitPrice: nonNeg(it.unitPrice), unitCost: it.unitCost === "" ? "" : nonNeg(it.unitCost) }));
    if (cleanItems.length === 0) { setError(t("form.order.noItemsError", "Add at least one item to the order.")); return; }

    let advance, paymentMode, payments;
    if (form.splitPayment) {
      const cleanPayments = form.payments.filter((p) => nonNeg(p.amount) > 0).map((p) => ({ id: p.id, mode: p.mode, amount: nonNeg(p.amount) }));
      if (cleanPayments.length === 0) { setError(t("form.order.noPaymentError", "Add at least one payment amount, or turn off split payment.")); return; }
      const modes = [...new Set(cleanPayments.map((p) => p.mode))];
      advance = cleanPayments.reduce((s, p) => s + p.amount, 0);
      paymentMode = modes.length === 1 ? modes[0] : "Split";
      payments = cleanPayments;
    } else {
      advance = nonNeg(form.advance);
      paymentMode = form.paymentMode;
      payments = []; // clears any earlier split-payment breakdown if this order is being edited back to a single method
    }

    onSave({
      ...form,
      customerName: form.customerName.trim() || "Walk-in Customer",
      customerPhone: normalizePhone(form.customerPhone),
      items: cleanItems,
      discountValue: form.discountType === "none" ? 0 : form.discountType === "percent" ? Math.min(100, nonNeg(form.discountValue)) : nonNeg(form.discountValue),
      advance,
      paymentMode,
      payments,
    });
  };

  return (
    <Modal title={isEdit ? t("form.order.editTitle", `Edit order ${form.orderNo}`, { orderNo: form.orderNo }) : t("form.order.addTitle", "New order")} onClose={onClose} wide>
      <form onSubmit={submit} className="flex flex-col gap-4">
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("form.order.date", "Date")} required><TextInput type="date" required value={form.date} onChange={set("date")} /></Field>
          <Field label={t("form.order.orderType", "Order type")}>
            <OtherableSelect options={ORDER_TYPES} value={form.orderType} onChange={(v) => setForm({ ...form, orderType: v })} placeholder={t("form.order.orderTypePlaceholder", "e.g. Wholesale, Online enquiry")} />
          </Field>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("form.order.customerName", "Customer name")}>
            <TextInput
              list="customer-names"
              value={form.customerName}
              onChange={(e) => {
                const name = e.target.value;
                const matches = customerOptions.filter((c) => c.name.toLowerCase() === name.toLowerCase());
                // Only auto-fill phone if the name unambiguously matches one known customer
                // and the phone field hasn't already been typed into — two "Amit Kumar"s
                // shouldn't get silently merged.
                if (matches.length === 1 && !form.customerPhone) {
                  setForm({ ...form, customerName: name, customerPhone: matches[0].phone });
                } else {
                  setForm({ ...form, customerName: name });
                }
              }}
              placeholder={t("form.order.customerNamePlaceholder", "Leave blank for a quick anonymous sale")}
            />
            <datalist id="customer-names">
              {customerOptions.map((c) => <option key={c.phone} value={c.name} />)}
            </datalist>
          </Field>
          <Field label={t("form.order.phone", "Phone")}>
            <div className="flex items-center gap-1">
              <TextInput
                value={form.customerPhone}
                onChange={(e) => {
                  const phone = e.target.value;
                  const match = customerOptions.find((c) => normalizePhone(c.phone) === normalizePhone(phone));
                  setForm({ ...form, customerPhone: phone, customerName: match ? match.name : form.customerName });
                }}
                onBlur={(e) => setForm((f) => ({ ...f, customerPhone: normalizePhone(e.target.value) }))}
                placeholder={t("form.order.phonePlaceholder", "Optional — needed to track this customer's history")}
              />
              {isEdit && <ContactActions phone={form.customerPhone} message={orderWaMessage({ ...form, total, balance }, shopName)} />}
            </div>
          </Field>
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold" style={{ color: T.inkSoft }}>{t("form.order.items", "Items")}</span>
            <button type="button" onClick={addItemRow} className="text-xs font-semibold flex items-center gap-1" style={{ color: T.teal }}>
              <Plus size={14} /> {t("form.order.addItem", "Add item")}
            </button>
          </div>
          {error && <p className="text-xs mb-2" style={{ color: T.danger }}>{error}</p>}
          <div className="flex flex-col gap-2">
            {form.items.map((it) => {
              const avail = it.productId ? availableFor(it.productId) : null;
              const oversells = avail !== null && num(it.qty) > avail;
              const missingProduct = it.productId && !products.some((p) => p.id === it.productId);
              const selectedProduct = it.productId ? products.find((p) => p.id === it.productId) : null;
              const selectedIsInactive = selectedProduct && selectedProduct.active === false;
              const activeProducts = products.filter((p) => p.active !== false);
              const pickerProducts = missingProduct
                ? [{ id: it.productId, sku: it.sku, name: `${it.name} (removed from catalog)`, category: it.category }, ...activeProducts]
                : selectedIsInactive
                ? [{ ...selectedProduct, name: `${selectedProduct.name} (discontinued)` }, ...activeProducts]
                : activeProducts;
              return (
                <div key={it.rowId} className="rounded-md border p-3" style={{ borderColor: oversells ? T.warn : T.borderSoft }}>
                  <div className="grid grid-cols-[1fr_auto] gap-2 mb-2">
                    <SearchableProductSelect
                      products={pickerProducts}
                      value={it.productId}
                      onChange={(id) => { setError(""); onPickProduct(it.rowId, id); }}
                      placeholder={t("form.order.customItemPlaceholder", "Custom / one-off item")}
                      allowCustom
                    />
                    <button type="button" onClick={() => removeItemRow(it.rowId)} className="p-2" style={{ color: T.danger }} aria-label={t("form.order.removeItem", "Remove item")}>
                      <Trash2 size={15} />
                    </button>
                  </div>
                  {!it.productId && (
                    <div className="grid grid-cols-2 gap-2 mb-2">
                      <TextInput placeholder={t("form.order.itemNamePlaceholder", "Item name")} value={it.name} onChange={(e) => { setError(""); updateItem(it.rowId, { name: e.target.value }); }} />
                      <OtherableSelect options={CATEGORIES} value={it.category} onChange={(v) => updateItem(it.rowId, { category: v })} placeholder={t("form.order.customCategoryPlaceholder", "Custom category")} />
                    </div>
                  )}
                  <div className="grid grid-cols-2 gap-2">
                    <Field label={t("form.order.qty", "Qty")}><TextInput type="number" min="1" value={it.qty} onChange={(e) => updateItem(it.rowId, { qty: e.target.value })} /></Field>
                    <Field label={t("form.order.unitPrice", "Unit price (₹)")}><TextInput type="number" min="0" value={it.unitPrice} onChange={(e) => updateItem(it.rowId, { unitPrice: e.target.value })} /></Field>
                  </div>
                  {oversells && (
                    <p className="text-xs mt-1.5" style={{ color: T.warn }}>
                      {t("form.order.oversellWarning", `Only ${avail} in stock — saving this will oversell. Fine for a backorder or made-to-order piece, otherwise restock first.`, { avail })}
                    </p>
                  )}

                  <div className="mt-2.5 pt-2.5 border-t" style={{ borderColor: T.borderSoft }}>
                    <label className="flex items-center gap-2 text-xs cursor-pointer" style={{ color: T.inkSoft }}>
                      <input type="checkbox" checked={!!it.customPhoto} onChange={(e) => updateItem(it.rowId, { customPhoto: e.target.checked })} />
                      {t("form.order.customPhotoCheckbox", "Make with the customer's own photo/design (optional)")}
                    </label>
                    {it.customPhoto && (
                      <div className="mt-2 flex items-start gap-3">
                        <div className="w-14 h-14 rounded-md overflow-hidden border flex items-center justify-center shrink-0" style={{ borderColor: T.borderSoft, backgroundColor: T.bg }}>
                          {it.customPhotoDataUrl ? (
                            <img src={it.customPhotoDataUrl} alt="Reference" className="w-full h-full object-cover" />
                          ) : (
                            <Image size={18} style={{ color: T.inkFaint }} />
                          )}
                        </div>
                        <div className="flex-1 flex flex-col gap-1.5 min-w-0">
                          <TextInput
                            value={it.customPhotoNote}
                            onChange={(e) => updateItem(it.rowId, { customPhotoNote: e.target.value })}
                            placeholder={t("form.order.customPhotoNotePlaceholder", "e.g. Customer will WhatsApp the photo before pickup")}
                          />
                          <div className="flex items-center gap-3">
                            <label className="text-xs font-semibold cursor-pointer" style={{ color: T.teal }}>
                              {it.customPhotoDataUrl ? t("form.order.changePhoto", "Change reference photo") : t("form.order.attachPhoto", "Attach reference photo")}
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) => {
                                  const file = e.target.files && e.target.files[0];
                                  e.target.value = "";
                                  if (!file) return;
                                  resizeImageToDataUrl(file, 200, (dataUrl, err) => {
                                    if (!err) updateItem(it.rowId, { customPhotoDataUrl: dataUrl });
                                  });
                                }}
                              />
                            </label>
                            {it.customPhotoDataUrl && (
                              <button type="button" onClick={() => updateItem(it.rowId, { customPhotoDataUrl: "" })} className="text-xs font-medium" style={{ color: T.danger }}>
                                {t("form.order.removePhoto", "Remove")}
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className={`grid gap-3 ${form.discountType === "none" ? "grid-cols-1" : "grid-cols-2"}`}>
          <Field label={t("form.order.discount", "Discount")}>
            <SelectInput value={form.discountType} onChange={(e) => setForm({ ...form, discountType: e.target.value, discountValue: "" })}>
              <option value="none">{t("form.order.noDiscount", "No discount")}</option>
              <option value="percent">{t("form.order.percentOff", "Percentage off")}</option>
              <option value="flat">{t("form.order.flatOff", "Flat amount off")}</option>
            </SelectInput>
          </Field>
          {form.discountType !== "none" && (
            <Field label={form.discountType === "percent" ? t("form.order.discountPercent", "Discount (%)") : t("form.order.discountAmount", "Discount amount (₹)")}>
              <TextInput type="number" min="0" max={form.discountType === "percent" ? 100 : undefined} value={form.discountValue} onChange={set("discountValue")} />
            </Field>
          )}
        </div>

        {!form.splitPayment ? (
          <div className="grid grid-cols-2 gap-3 items-end">
            <Field label={t("form.order.advancePaid", "Advance paid (₹)")}><TextInput type="number" min="0" value={form.advance} onChange={set("advance")} /></Field>
            <div className="flex flex-col gap-1.5">
              <Field label={t("form.expense.paymentMode", "Payment mode")}>
                <OtherableSelect options={PAYMENT_MODES} value={form.paymentMode} onChange={(v) => setForm({ ...form, paymentMode: v })} placeholder={t("form.order.paymentModePlaceholder", "e.g. Bank transfer, Cheque")} />
              </Field>
              {num(form.advance) > 0 && (
                <button type="button" onClick={() => setForm({ ...form, splitPayment: true })} className="text-xs font-medium text-left" style={{ color: T.teal }}>
                  {t("form.order.paidAcrossMultiple", "Paid across more than one method?")}
                </button>
              )}
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold" style={{ color: T.inkSoft }}>{t("form.order.splitPayment", "Split payment")}</span>
              <button type="button" onClick={() => setForm({ ...form, splitPayment: false })} className="text-xs font-medium" style={{ color: T.inkFaint }}>
                {t("form.order.useOneMethod", "Use one payment method instead")}
              </button>
            </div>
            <div className="flex flex-col gap-2">
              {form.payments.map((p) => (
                <div key={p.id} className="flex gap-2 items-center">
                  <div className="w-32 shrink-0">
                    <OtherableSelect options={PAYMENT_MODES} value={p.mode} onChange={(v) => updatePayment(p.id, { mode: v })} placeholder={t("form.order.otherPlaceholder", "Other")} />
                  </div>
                  <TextInput type="number" min="0" value={p.amount} onChange={(e) => updatePayment(p.id, { amount: e.target.value })} placeholder={t("form.order.amountPlaceholder", "Amount (₹)")} />
                  {form.payments.length > 1 && (
                    <button type="button" onClick={() => removePaymentRow(p.id)} className="shrink-0" style={{ color: T.danger }}><X size={16} /></button>
                  )}
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between mt-2">
              {form.payments.length < 4 ? (
                <button type="button" onClick={addPaymentRow} className="text-xs font-medium flex items-center gap-1" style={{ color: T.teal }}>
                  <Plus size={13} /> {t("form.order.addAnotherMethod", "Add another method")}
                </button>
              ) : <span />}
              <span className="text-xs tabular-nums" style={{ color: T.inkSoft }}>{t("form.order.totalAdvance", `Total advance: ${fmtMoney(splitTotal)}`, { amount: fmtMoney(splitTotal) })}</span>
            </div>
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("form.order.deliveryDate", "Delivery date")}><TextInput type="date" value={form.deliveryDate} onChange={set("deliveryDate")} /></Field>
          <Field label={t("form.order.status", "Status")}>
            <SelectInput value={form.status} onChange={set("status")}>
              {ORDER_STATUSES.map((s) => <option key={s} value={s}>{t(`status.${s}`, s)}</option>)}
            </SelectInput>
          </Field>
        </div>
        {dateIssue && <p className="text-xs -mt-2" style={{ color: T.warn }}>{t("form.order.dateIssue", "Delivery date is before the order date — check this is right.")}</p>}
        <Field label={t("form.customer.notes", "Notes")}><TextArea rows={2} value={form.notes} onChange={set("notes")} placeholder={t("form.order.notesOptional", "Optional")} /></Field>

        <div className="rounded-md px-4 py-3" style={{ backgroundColor: T.tealSoft }}>
          {discount > 0 && (
            <div className="flex items-center justify-between text-xs mb-1.5" style={{ color: T.inkSoft }}>
              <span>{t("form.order.subtotalDiscountLine", `Subtotal ${fmtMoney(subtotal)} − Discount ${fmtMoney(discount)}`, { subtotal: fmtMoney(subtotal), discount: fmtMoney(discount) })}</span>
            </div>
          )}
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium" style={{ color: T.teal }}>{t("form.order.total", "Total:")} {fmtMoney(total)}</span>
            <span className="text-sm font-medium" style={{ color: balance > 0 ? T.danger : balance < 0 ? T.warn : T.success }}>
              {balance > 0 ? t("form.order.balanceDue", `Balance due: ${fmtMoney(balance)}`, { amount: fmtMoney(balance) }) : balance < 0 ? t("form.order.overpaid", `Overpaid — refund ${fmtMoney(-balance)}`, { amount: fmtMoney(-balance) }) : t("orders.paidInFull", "Paid in full")}
            </span>
          </div>
        </div>

        <div className="flex gap-2 pt-1">
          <GhostButton onClick={onClose} full>{t("action.cancel", "Cancel")}</GhostButton>
          <PrimaryButton type="submit" full>{t("form.order.saveButton", "Save order")}</PrimaryButton>
        </div>
      </form>
    </Modal>
  );
}

export function CustomerModal({ customer, customers, t, onClose, onSave }) {
  const isEdit = !!customer.id;
  const [form, setForm] = useState({
    id: customer.id || genId("CUST"),
    name: customer.name || "",
    phone: customer.phone || "",
    address: customer.address || "",
    notes: customer.notes || "",
  });
  const [error, setError] = useState("");
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const submit = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) return;
    const normalized = normalizePhone(form.phone);
    const dup = (customers || []).find((c) => c.id !== form.id && normalizePhone(c.phone) === normalized);
    if (dup) { setError(t("form.customer.duplicateError", `This number is already saved as "${dup.name}" — edit that customer instead, or use a different number.`, { name: dup.name })); return; }
    onSave({ ...form, phone: normalized });
  };
  return (
    <Modal title={isEdit ? t("form.customer.editTitle", "Edit customer") : t("form.customer.addTitle", "Add customer")} onClose={onClose}>
      <form onSubmit={submit} className="flex flex-col gap-3.5">
        <Field label={t("form.customer.name", "Name")} required><TextInput required value={form.name} onChange={set("name")} /></Field>
        <Field label={t("form.customer.phone", "Phone")} required><TextInput required value={form.phone} onChange={set("phone")} /></Field>
        {error && <p className="text-xs" style={{ color: T.danger }}>{error}</p>}
        <Field label={t("form.customer.address", "Address")}><TextArea rows={2} value={form.address} onChange={set("address")} /></Field>
        <Field label={t("form.customer.notes", "Notes")}><TextArea rows={2} value={form.notes} onChange={set("notes")} placeholder={t("form.customer.notesPlaceholder", "e.g. Prefers wooden frames")} /></Field>
        <div className="flex gap-2 pt-2">
          <GhostButton onClick={onClose} full>{t("action.cancel", "Cancel")}</GhostButton>
          <PrimaryButton type="submit" full>{t("form.customer.saveButton", "Save customer")}</PrimaryButton>
        </div>
      </form>
    </Modal>
  );
}

export function CustomerDetailModal({ customer, orders, shopName, t, onClose, onEdit }) {
  const sorted = [...orders].sort((a, b) => (a.date < b.date ? 1 : -1));
  return (
    <Modal title={customer.name} onClose={onClose}>
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-1 text-sm" style={{ color: T.inkSoft }}><Phone size={13} />{customer.phone}</span>
          <div className="flex gap-2">
            <a href={telLink(customer.phone)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold border" style={{ color: T.ink, borderColor: T.border }}>
              <Phone size={13} /> Call
            </a>
            <a href={waLink(customer.phone, customerWaMessage(customer, shopName))} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 pl-1.5 pr-3 py-1.5 rounded-md text-xs font-semibold text-white" style={{ backgroundColor: "#25D366" }}>
              <WhatsAppGlyph size={17} /> WhatsApp
            </a>
          </div>
        </div>
        {customer.address && <p className="text-sm flex items-start gap-1" style={{ color: T.inkSoft }}><MapPin size={13} className="mt-0.5 shrink-0" />{customer.address}</p>}
        {customer.notes && <p className="text-sm italic" style={{ color: T.inkFaint }}>{customer.notes}</p>}

        <div className="grid grid-cols-2 gap-3 my-2">
          <StatCard label="Total orders" value={customer.totalOrders} accent={T.teal} sub="Excludes cancelled" />
          <StatCard label="Total spent" value={fmtMoney(customer.totalSpent)} accent={T.brass} sub={customer.outstanding > 0 ? `${fmtMoney(customer.outstanding)} due` : undefined} />
        </div>

        <p className="text-xs font-semibold mt-1" style={{ color: T.inkSoft }}>Order history</p>
        <div className="flex flex-col divide-y max-h-56 overflow-y-auto" style={{ borderColor: T.borderSoft }}>
          {sorted.length === 0 && <p className="text-sm py-3" style={{ color: T.inkFaint }}>{t("customers.noOrdersYet", "No orders yet.")}</p>}
          {sorted.map((o) => (
            <div key={o.id} className="flex items-center justify-between py-2 text-sm gap-2">
              <span style={{ color: T.inkSoft }} className="truncate">{fmtShortDate(o.date)} · {o.orderNo}</span>
              <div className="flex items-center gap-2 shrink-0">
                {(o.status === "Cancelled" || o.status === "Returned") && <StatusBadge status={o.status} t={t} />}
                <span className="font-medium tabular-nums" style={{ color: (o.status === "Cancelled" || o.status === "Returned") ? T.inkFaint : T.ink }}>{fmtMoney(o.total)}</span>
              </div>
            </div>
          ))}
        </div>
        <div className="flex gap-2 pt-2">
          <GhostButton onClick={onClose} full>Close</GhostButton>
          <PrimaryButton onClick={onEdit} full>Edit customer</PrimaryButton>
        </div>
      </div>
    </Modal>
  );
}

export function ProductDetailModal({ product, orders, revenue, profit, t, onClose, onEdit, onRestock }) {
  return (
    <Modal title={product.name} onClose={onClose}>
      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-2 flex-wrap">
          <CategoryTag category={product.category} />
          {product.sku && <span className="text-xs" style={{ color: T.inkFaint, fontFamily: FONT_MONO }}>{product.sku}</span>}
          {product.size && <span className="text-xs" style={{ color: T.inkFaint }}>· {product.size}</span>}
        </div>
        {product.customization && <p className="text-sm italic" style={{ color: T.inkFaint }}>{product.customization}</p>}

        <div className="grid grid-cols-2 gap-3 my-1">
          <StatCard label="Current stock" value={`${product.current} pcs`} accent={product.current < 0 ? T.danger : product.low ? T.warn : T.teal} sub={product.current < 0 ? "Oversold" : product.low ? "Low stock" : undefined} />
          <StatCard label="Units sold" value={product.sold} accent={T.brass} sub="Excludes cancelled" />
          <StatCard label="Revenue" value={fmtMoney(revenue)} accent={T.teal} />
          <StatCard label="Profit contributed" value={fmtMoney(profit)} accent={profit >= 0 ? T.success : T.danger} />
        </div>

        <p className="text-xs font-semibold mt-1" style={{ color: T.inkSoft }}>Order history</p>
        <div className="flex flex-col divide-y max-h-44 overflow-y-auto" style={{ borderColor: T.borderSoft }}>
          {orders.length === 0 && <p className="text-sm py-3" style={{ color: T.inkFaint }}>{t("products.notInAnyOrder", "Not part of any order yet.")}</p>}
          {orders.map((o) => (
            <div key={o.id} className="flex items-center justify-between py-2 text-sm gap-2">
              <span style={{ color: T.inkSoft }} className="truncate">{fmtShortDate(o.date)} · {o.orderNo} · {o.customerName || t("dashboard.walkIn", "Walk-in")}</span>
              <div className="flex items-center gap-2 shrink-0">
                {(o.status === "Cancelled" || o.status === "Returned") && <StatusBadge status={o.status} t={t} />}
                <span className="font-medium tabular-nums" style={{ color: (o.status === "Cancelled" || o.status === "Returned") ? T.inkFaint : T.ink }}>{o._qty}× {fmtMoney(o._revenue)}</span>
              </div>
            </div>
          ))}
        </div>

        {product.restocks && product.restocks.length > 0 && (
          <>
            <p className="text-xs font-semibold mt-1" style={{ color: T.inkSoft }}>Restock history</p>
            <div className="flex flex-col divide-y max-h-32 overflow-y-auto" style={{ borderColor: T.borderSoft }}>
              {[...product.restocks].sort((a, b) => (a.date < b.date ? 1 : -1)).map((r) => (
                <div key={r.id} className="flex items-center justify-between py-1.5 text-sm gap-2">
                  <span style={{ color: T.inkSoft }} className="truncate">{fmtShortDate(r.date)}{r.note ? ` · ${r.note}` : ""}</span>
                  <span className="font-medium tabular-nums" style={{ color: T.success }}>+{r.qty}</span>
                </div>
              ))}
            </div>
          </>
        )}

        <div className="flex gap-2 pt-2">
          <GhostButton onClick={onRestock} full><PackagePlus size={15} /> Restock</GhostButton>
          <PrimaryButton onClick={onEdit} full>Edit product</PrimaryButton>
        </div>
      </div>
    </Modal>
  );
}

export function ReceiptModal({ order, settings, onClose }) {
  const items = order.items || [];
  const subtotal = order.subtotal ?? items.reduce((s, it) => s + num(it.qty) * num(it.unitPrice), 0);
  const discount = order.discount ?? 0;
  const total = order.total ?? (subtotal - discount);
  const balance = total - num(order.advance);

  const shareText = () => {
    const lines = [
      settings.shopName,
      settings.shopAddress || null,
      settings.shopPhone ? `Ph: ${settings.shopPhone}` : null,
      "",
      `Receipt — ${order.orderNo}`,
      `Date: ${fmtDate(order.date)}`,
      order.customerName ? `Customer: ${order.customerName}` : null,
      "",
      ...items.map((it) => `${it.name} x${num(it.qty)} — ${fmtMoney(num(it.qty) * num(it.unitPrice))}`),
      "",
      `Subtotal: ${fmtMoney(subtotal)}`,
      discount > 0 ? `Discount: -${fmtMoney(discount)}` : null,
      `Total: ${fmtMoney(total)}`,
      num(order.advance) > 0 ? `Advance paid: ${fmtMoney(num(order.advance))}` : null,
      balance > 0 ? `Balance due: ${fmtMoney(balance)}` : "Paid in full",
      order.paymentMode === "Split"
        ? `Payment: ${orderPayments(order).map((p) => `${p.mode} ${fmtMoney(p.amount)}`).join(" + ")}`
        : `Payment mode: ${order.paymentMode}`,
      order.deliveryDate ? `Delivery: ${fmtDate(order.deliveryDate)}` : null,
      "",
      "Thank you for shopping with us!",
    ].filter((l) => l !== null).join("\n");
    window.open(waLink(order.customerPhone, lines), "_blank", "noopener,noreferrer");
  };

  return (
    <Modal title="Receipt" onClose={onClose} wide>
      <div className="flex flex-col gap-3">
        {/* Deliberately light/printable regardless of the app's dark theme — this is
            the one screen meant to end up on paper, so it should look like paper,
            and printing a dark background would waste ink and look unfinished. */}
        <div className="receipt-print rounded-lg overflow-hidden border" style={{ backgroundColor: "#FFFFFF", borderColor: "#E2E2E2" }}>
          <div className="p-6" style={{ color: "#1A1A1A", fontFamily: "Inter, Arial, sans-serif" }}>
            <div className="flex items-center gap-3 mb-4 pb-4" style={{ borderBottom: "1px dashed #CCCCCC" }}>
              {settings.logoDataUrl && (
                <img src={settings.logoDataUrl} alt="" style={{ width: 40, height: 40, borderRadius: 6, objectFit: "cover" }} />
              )}
              <div>
                <p style={{ fontWeight: 700, fontSize: 16 }}>{settings.shopName}</p>
                {settings.shopAddress && <p style={{ fontSize: 11, color: "#666" }}>{settings.shopAddress}</p>}
                {settings.shopPhone && <p style={{ fontSize: 11, color: "#666" }}>Ph: {settings.shopPhone}</p>}
              </div>
            </div>

            <div className="flex items-start justify-between mb-4" style={{ fontSize: 12, color: "#444" }}>
              <div>
                <p style={{ fontWeight: 600, fontSize: 13, color: "#1A1A1A" }}>Receipt — {order.orderNo}</p>
                <p>{fmtDate(order.date)}</p>
              </div>
              <div style={{ textAlign: "right" }}>
                {order.customerName && <p style={{ fontWeight: 600, color: "#1A1A1A" }}>{order.customerName}</p>}
                {order.customerPhone && <p>{order.customerPhone}</p>}
              </div>
            </div>

            <table style={{ width: "100%", fontSize: 12, borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid #DDDDDD", textAlign: "left" }}>
                  <th style={{ padding: "4px 0", fontWeight: 600 }}>Item</th>
                  <th style={{ padding: "4px 0", fontWeight: 600, textAlign: "center" }}>Qty</th>
                  <th style={{ padding: "4px 0", fontWeight: 600, textAlign: "right" }}>Price</th>
                  <th style={{ padding: "4px 0", fontWeight: 600, textAlign: "right" }}>Total</th>
                </tr>
              </thead>
              <tbody>
                {items.length === 0 ? (
                  <tr><td colSpan={4} style={{ padding: "10px 0", color: "#888", textAlign: "center" }}>No items</td></tr>
                ) : (
                  items.map((it, i) => (
                    <tr key={it.rowId || i} style={{ borderBottom: "1px solid #F2F2F2" }}>
                      <td style={{ padding: "6px 0" }}>{it.name}{it.sku ? ` (${it.sku})` : ""}</td>
                      <td style={{ padding: "6px 0", textAlign: "center" }}>{num(it.qty)}</td>
                      <td style={{ padding: "6px 0", textAlign: "right" }}>{fmtMoney(num(it.unitPrice))}</td>
                      <td style={{ padding: "6px 0", textAlign: "right" }}>{fmtMoney(num(it.qty) * num(it.unitPrice))}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>

            <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px dashed #CCCCCC", fontSize: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span>Subtotal</span><span>{fmtMoney(subtotal)}</span>
              </div>
              {discount > 0 && (
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, color: "#555555" }}>
                  <span>Discount</span><span>-{fmtMoney(discount)}</span>
                </div>
              )}
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontWeight: 600 }}>
                <span>Total</span><span>{fmtMoney(total)}</span>
              </div>
              {num(order.advance) > 0 && (
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, color: "#555555" }}>
                  <span>Advance paid</span><span>{fmtMoney(num(order.advance))}</span>
                </div>
              )}
              <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 700, fontSize: 13, marginTop: 4 }}>
                <span>{balance > 0 ? "Balance due" : "Paid in full"}</span>
                {balance > 0 && <span>{fmtMoney(balance)}</span>}
              </div>
            </div>

            <div style={{ marginTop: 10, fontSize: 11, color: "#666666" }}>
              {order.paymentMode === "Split" ? (
                <p>Payment: {orderPayments(order).map((p) => `${p.mode} ${fmtMoney(p.amount)}`).join(" + ")}</p>
              ) : (
                <p>Payment mode: {order.paymentMode}</p>
              )}
              {order.deliveryDate && <p>Delivery: {fmtDate(order.deliveryDate)}</p>}
            </div>

            <p style={{ marginTop: 18, textAlign: "center", fontSize: 11, color: "#999999" }}>Thank you for shopping with us!</p>
          </div>
        </div>

        <div className="flex gap-2 no-print">
          <GhostButton onClick={() => window.print()} full><Printer size={15} /> Print</GhostButton>
          {order.customerPhone ? (
            <PrimaryButton onClick={shareText} full><WhatsAppGlyph size={16} /> Share on WhatsApp</PrimaryButton>
          ) : (
            <GhostButton onClick={onClose} full>Close</GhostButton>
          )}
        </div>
      </div>
    </Modal>
  );
}

export function ReturnModal({ order, onClose, onConfirm }) {
  const [refundAmount, setRefundAmount] = useState(String(Math.round(order.total || 0)));
  const [reason, setReason] = useState("");
  const submit = (e) => {
    e.preventDefault();
    onConfirm({ returnRefund: nonNeg(refundAmount), returnReason: reason.trim(), returnDate: todayStr() });
  };
  return (
    <Modal title={`Process return — ${order.orderNo}`} onClose={onClose}>
      <form onSubmit={submit} className="flex flex-col gap-3.5">
        <p className="text-xs" style={{ color: T.inkSoft }}>
          This adds the order's items back to stock and removes it from your sales and profit totals — it stays visible in Orders, just marked as returned.
        </p>
        <Field label="Refund amount (₹)" required>
          <TextInput type="number" min="0" required value={refundAmount} onChange={(e) => setRefundAmount(e.target.value)} />
        </Field>
        <p className="text-xs -mt-2" style={{ color: T.inkFaint }}>Defaults to the full order amount — lower it for a partial refund, or set to 0 for an exchange with nothing refunded.</p>
        <Field label="Reason (optional)">
          <TextArea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Wrong size, customer changed mind" />
        </Field>
        <div className="flex gap-2 pt-2">
          <GhostButton onClick={onClose} full>Cancel</GhostButton>
          <PrimaryButton type="submit" full>Confirm return</PrimaryButton>
        </div>
      </form>
    </Modal>
  );
}

export function ExpenseModal({ expense, t, onClose, onSave }) {
  const isEdit = !!expense.id;
  const [form, setForm] = useState({
    id: expense.id || genId("EXP"),
    date: expense.date || todayStr(),
    category: expense.category || EXPENSE_CATEGORIES[0],
    description: expense.description || "",
    amount: expense.amount ?? "",
    paymentMode: expense.paymentMode || "Cash",
  });
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const submit = (e) => {
    e.preventDefault();
    if (!form.amount || nonNeg(form.amount) <= 0) return;
    onSave({ ...form, amount: nonNeg(form.amount) });
  };
  return (
    <Modal title={isEdit ? t("form.expense.editTitle", "Edit expense") : t("form.expense.addTitle", "Add expense")} onClose={onClose}>
      <form onSubmit={submit} className="flex flex-col gap-3.5">
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("form.expense.date", "Date")} required><TextInput type="date" required value={form.date} onChange={set("date")} /></Field>
          <Field label={t("form.expense.category", "Category")}>
            <OtherableSelect options={EXPENSE_CATEGORIES.filter((c) => c !== "Other")} value={form.category} onChange={(v) => setForm({ ...form, category: v })} placeholder={t("form.expense.categoryPlaceholder", "e.g. Insurance, Repairs")} />
          </Field>
        </div>
        <Field label={t("form.expense.description", "Description")}><TextInput value={form.description} onChange={set("description")} placeholder={t("form.expense.descriptionPlaceholder", "e.g. Wood planks & acrylic sheets")} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("form.expense.amount", "Amount (₹)")} required><TextInput type="number" min="0" required value={form.amount} onChange={set("amount")} /></Field>
          <Field label={t("form.expense.paymentMode", "Payment mode")}>
            <OtherableSelect options={PAYMENT_MODES} value={form.paymentMode} onChange={(v) => setForm({ ...form, paymentMode: v })} placeholder={t("form.expense.paymentModePlaceholder", "e.g. Bank transfer, Cheque")} />
          </Field>
        </div>
        <div className="flex gap-2 pt-2">
          <GhostButton onClick={onClose} full>{t("action.cancel", "Cancel")}</GhostButton>
          <PrimaryButton type="submit" full>{t("form.expense.saveButton", "Save expense")}</PrimaryButton>
        </div>
      </form>
    </Modal>
  );
}



// Loading a backup file back in. Nothing is written until the owner has seen
// exactly what the file would add, update or remove.
export function RestoreModal({ t, current, onClose, onConfirm }) {
  const [parsed, setParsed] = useState(null);
  const [fileName, setFileName] = useState("");
  const [mode, setMode] = useState("merge");
  const [confirmText, setConfirmText] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const pick = async (file) => {
    if (!file) return;
    setError(""); setParsed(null); setFileName(file.name);
    try {
      setParsed(await shopBackup.parseBackup(file));
    } catch (e) {
      setError(e?.message || "Could not read that file.");
    }
  };

  const rows = parsed ? shopBackup.previewBackup(parsed, current, mode) : [];
  const ready = parsed && (mode === "merge" || confirmText.trim().toUpperCase() === "REPLACE");

  return (
    <Modal title={t("restore.title", "Restore from backup")} onClose={onClose}>
      <div className="flex flex-col gap-4">
        <p className="text-xs" style={{ color: T.inkFaint }}>
          {t("restore.help", "Pick the .json backup file this app created. You'll see exactly what it contains before anything is saved.")}
        </p>

        <label className="px-4 py-2.5 rounded-md text-sm font-semibold border text-center cursor-pointer" style={{ color: T.ink, borderColor: T.borderSoft, backgroundColor: T.bg }}>
          <Upload size={15} className="inline mr-2 -mt-0.5" />
          {fileName || t("restore.chooseFile", "Choose backup file")}
          <input type="file" accept=".json,application/json" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
        </label>

        {error && <p className="text-xs" style={{ color: T.danger }}>{error}</p>}

        {parsed && (
          <>
            <div className="rounded-lg border" style={{ borderColor: T.borderSoft }}>
              {rows.map((r) => (
                <div key={r.kind} className="flex items-center justify-between px-3 py-2 text-xs border-b last:border-b-0" style={{ borderColor: T.borderSoft }}>
                  <span style={{ color: T.ink, textTransform: "capitalize" }}>{r.kind}</span>
                  <span style={{ color: T.inkFaint, fontFamily: FONT_MONO }}>
                    {r.added} new · {r.updated} updated{mode === "replace" ? ` · ${r.removed} removed` : ""}
                  </span>
                </div>
              ))}
            </div>

            <div className="flex flex-col gap-2">
              {[
                ["merge", t("restore.merge", "Merge"), t("restore.mergeHint", "Keep everything you have now and add or update whatever is in the file.")],
                ["replace", t("restore.replace", "Replace everything"), t("restore.replaceHint", "Make the shop match the file exactly. Records that aren't in the file are deleted.")],
              ].map(([value, label, hint]) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setMode(value)}
                  className="text-left px-3 py-2.5 rounded-md border"
                  style={{ borderColor: mode === value ? T.teal : T.borderSoft, backgroundColor: T.bg }}
                >
                  <p className="text-sm font-semibold" style={{ color: mode === value ? T.teal : T.ink }}>{label}</p>
                  <p className="text-xs mt-0.5" style={{ color: T.inkFaint }}>{hint}</p>
                </button>
              ))}
            </div>

            {mode === "replace" && (
              <Field label={t("restore.typeReplace", "Type REPLACE to confirm")}>
                <TextInput value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="REPLACE" />
              </Field>
            )}

            <PrimaryButton
              full
              onClick={ready && !busy ? async () => { setBusy(true); await onConfirm(parsed, mode); setBusy(false); } : undefined}
            >
              {busy ? t("restore.restoring", "Restoring…") : t("restore.confirm", "Restore this backup")}
            </PrimaryButton>
          </>
        )}
      </div>
    </Modal>
  );
}

export function SettingsModal({ settings, user, t, onClose, onSave, onLogoChange, onExportExcel, exportingExcel, onExportJson, backupBusy, onRestore, onSeed, onUnseed, hasDemoData, onClearAll, isOwner, teamMembers, teamBusy, onInviteStaff, onRemoveStaff, theme, onThemeChange, lang, onLanguageChange, onSignOut }) {
  const [name, setName] = useState(settings.shopName);
  const [phone, setPhone] = useState(settings.shopPhone || "");
  const [address, setAddress] = useState(settings.shopAddress || "");
  const [inviteEmail, setInviteEmail] = useState("");
  const [uploading, setUploading] = useState(false);
  const [logoError, setLogoError] = useState("");
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordMsg, setPasswordMsg] = useState("");
  const [passwordErr, setPasswordErr] = useState("");
  const [savingPassword, setSavingPassword] = useState(false);
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [newEmail, setNewEmail] = useState("");
  const [emailMsg, setEmailMsg] = useState("");
  const [emailErr, setEmailErr] = useState("");
  const [savingEmail, setSavingEmail] = useState(false);
  const [section, setSection] = useState("menu");

  const signInMethod = (() => {
    const providers = user?.app_metadata?.providers || (user?.app_metadata?.provider ? [user.app_metadata.provider] : []);
    if (providers.includes("google")) return t("settings.googleAccount", "Google account");
    if (providers.includes("phone")) return t("settings.phoneAccount", "Phone number");
    if (providers.includes("email")) return t("settings.emailPassword", "Email & password");
    return providers[0] || t("settings.emailPassword", "Email & password");
  })();
  const usesPassword = signInMethod === t("settings.emailPassword", "Email & password");
  const usesPhone = signInMethod === t("settings.phoneAccount", "Phone number");
  const joined = user?.created_at
    ? new Date(user.created_at).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })
    : "—";

  const changePassword = async () => {
    setPasswordErr(""); setPasswordMsg("");
    if (newPassword.length < 6) { setPasswordErr(t("settings.useAtLeast6", "Use at least 6 characters.")); return; }
    if (newPassword !== confirmPassword) { setPasswordErr(t("settings.passwordsMustMatch", "Both passwords must match.")); return; }
    setSavingPassword(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setSavingPassword(false);
    if (error) { setPasswordErr(error.message); return; }
    setNewPassword(""); setConfirmPassword(""); setShowPasswordForm(false);
    setPasswordMsg(t("settings.passwordUpdated", "Password updated."));
  };

  const changeEmail = async () => {
    setEmailErr(""); setEmailMsg("");
    const trimmed = newEmail.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) { setEmailErr(t("settings.enterValidEmail", "Enter a valid email address.")); return; }
    if (trimmed.toLowerCase() === (user?.email || "").toLowerCase()) { setEmailErr(t("settings.alreadyCurrentEmail", "That's already your current email.")); return; }
    setSavingEmail(true);
    const { error } = await supabase.auth.updateUser({ email: trimmed });
    setSavingEmail(false);
    if (error) { setEmailErr(error.message); return; }
    setNewEmail(""); setShowEmailForm(false);
    // Supabase sends a confirmation link to the new address and the change only takes
    // effect once that's clicked — the old address stays active until then, so saying
    // just "Email updated" would be misleading about what actually happened.
    setEmailMsg(t("settings.confirmationSent", `Confirmation link sent to ${trimmed} — click it to finish changing your email.`, { email: trimmed }));
  };


  const handleLogoFile = (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = ""; // lets the same file be picked again later if needed
    if (!file) return;
    setLogoError("");
    setUploading(true);
    resizeImageToDataUrl(file, 240, (dataUrl, err) => {
      setUploading(false);
      if (err) { setLogoError(err); return; }
      onLogoChange(dataUrl);
    }, "image/png");
  };

  const sections = [
    { id: "shop", label: t("settings.shopProfile", "Shop profile"), hint: t("settings.shopMenuHint", "Name, logo and receipt details"), group: "organization", icon: Store },
    { id: "account", label: t("settings.yourAccount", "Your account"), hint: t("settings.accountMenuHint", "Sign-in details and security"), group: "organization", icon: UserRound },
    ...(isOwner ? [{ id: "team", label: t("settings.team", "Team"), hint: t("settings.teamMenuHint", "Members and shop access"), group: "organization", icon: Users }] : []),
    { id: "appearance", label: t("settings.appearance", "Appearance"), hint: t("settings.appearanceMenuHint", "Light and dark display modes"), group: "preferences", icon: Sun },
    { id: "language", label: t("settings.language", "Language"), hint: t("settings.languageMenuHint", "Choose your display language"), group: "preferences", icon: Languages },
    { id: "data", label: t("settings.dataBackup", "Data & backup"), hint: t("settings.dataMenuHint", "Download, restore and sample data"), group: "system", icon: Database },
    ...(isOwner ? [{ id: "danger", label: t("settings.dangerZone", "Danger zone"), hint: t("settings.dangerMenuHint", "Permanent data actions"), group: "danger", icon: ShieldAlert, danger: true }] : []),
  ];
  const current = sections.find((item) => item.id === section) || sections.find((item) => item.id === "appearance") || sections[0];
  const contentSection = section === "menu" ? "appearance" : section;
  const saveShop = () => onSave({ ...settings, shopName: name || "Frame & Gifts Shop", shopPhone: phone.trim(), shopAddress: address.trim() });

  return (
    <Modal title={t("settings.title", "Settings")} onClose={onClose} settingsLayout>
      <div className="flex h-full min-h-0 flex-col sm:flex-row">
        <aside className="hidden shrink-0 border-r sm:block sm:w-56" style={{ borderColor: T.borderSoft, backgroundColor: T.bg }}>
          <nav className="flex flex-col gap-1 p-4" aria-label={t("settings.sections", "Settings sections")}>
            {sections.map((item) => {
              const active = item.id === current.id;
              return (
                <button key={item.id} type="button" onClick={() => setSection(item.id)} className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors" style={{ color: item.danger ? T.danger : active ? T.teal : T.inkSoft, backgroundColor: active ? (item.danger ? T.dangerSoft : T.tealSoft) : "transparent" }}>
                  <item.icon size={17} /> {item.label}
                </button>
              );
            })}
          </nav>
        </aside>

        {section === "menu" && (
          <section className="min-w-0 flex-1 overflow-y-auto px-5 py-5 sm:hidden">
            {["organization", "preferences", "system", "danger"].map((group) => {
              const items = sections.filter((item) => item.group === group);
              if (!items.length) return null;
              const groupLabel = group === "organization" ? t("settings.organization", "Organization") : group === "preferences" ? t("settings.preferences", "Preferences") : group === "system" ? t("settings.system", "System") : "";
              return <div key={group} className={`${group === "danger" ? "mt-2 border-t pt-4" : "mb-5"}`} style={{ borderColor: T.borderSoft }}>
                {groupLabel && <p className="mb-1 px-1 text-[11px] font-semibold uppercase" style={{ color: T.inkFaint, letterSpacing: "0.08em" }}>{groupLabel}</p>}
                <div className="overflow-hidden rounded-lg border" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
                  {items.map((item, index) => <button key={item.id} type="button" onClick={() => setSection(item.id)} className="grid min-h-16 w-full grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 text-left" style={{ borderTop: index ? `1px solid ${T.borderSoft}` : "none" }}>
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg" style={{ color: item.danger ? T.danger : T.teal, backgroundColor: item.danger ? T.dangerSoft : T.tealSoft }}><item.icon size={19} /></span>
                    <span className="min-w-0"><span className="block truncate text-sm font-medium" style={{ color: item.danger ? T.danger : T.ink }}>{item.label}</span><span className="mt-0.5 block text-xs" style={{ color: item.danger ? T.danger : T.inkFaint }}>{item.hint}</span></span>
                    <ChevronRight size={17} className="shrink-0" style={{ color: item.danger ? T.danger : T.inkFaint }} />
                  </button>)}
                </div>
              </div>;
            })}
          </section>
        )}

        <section className={`${section === "menu" ? "hidden sm:block" : "block"} min-w-0 flex-1 overflow-y-auto px-5 py-5 sm:px-8 sm:py-7`}>
          <button type="button" onClick={() => setSection("menu")} className="mb-5 flex min-h-11 items-center gap-2 text-sm font-medium sm:hidden" style={{ color: T.teal }}><ArrowLeft size={18} /> {t("settings.allSettings", "All settings")}</button>
          <header className="mb-7">
            <h2 className="text-xl font-semibold" style={{ color: current.danger ? T.danger : T.ink }}>{current.label}</h2>
            <p className="mt-1 text-sm" style={{ color: T.inkFaint }}>
               {contentSection === "appearance" && t("settings.appearanceHint", "Choose how the shop manager looks on this device.")}
               {contentSection === "language" && t("settings.languageHint", "Choose the language used throughout the shop manager.")}
               {contentSection === "shop" && t("settings.shopHint", "Keep the details shown across your workspace and receipts up to date.")}
               {contentSection === "account" && t("settings.accountHint", "Review your sign-in details and account security.")}
               {contentSection === "team" && t("settings.teamHint", "Manage who can work in this shop.")}
               {contentSection === "data" && t("settings.dataHint", "Download copies of your records or restore an earlier backup.")}
               {contentSection === "danger" && t("settings.dangerHint", "Permanent actions that affect every record in this shop.")}
            </p>
          </header>

          {contentSection === "appearance" && (
            <div>
              <p className="mb-4 text-xs font-semibold uppercase" style={{ color: T.inkSoft, letterSpacing: "0.08em" }}>{t("settings.interfaceTheme", "Interface theme")}</p>
              <div className="grid grid-cols-2 gap-4">
                {[{ id: "light", label: t("settings.light", "Light"), icon: Sun }, { id: "dark", label: t("settings.dark", "Dark"), icon: Moon }].map((choice) => {
                  const active = theme === choice.id;
                  return (
                    <button key={choice.id} type="button" onClick={() => onThemeChange(choice.id)} aria-pressed={active} className="group text-left">
                      <div className={`relative aspect-video overflow-hidden rounded-lg border-2 p-2 transition-colors theme-preview-${choice.id}`} style={{ color: "var(--preview-ink)", borderColor: active ? T.teal : T.border, backgroundColor: "var(--preview-bg)" }}>
                        <div className="flex h-full overflow-hidden rounded border" style={{ borderColor: "var(--preview-border)", backgroundColor: "var(--preview-surface)" }}>
                          <div className="w-1/4 border-r" style={{ borderColor: "var(--preview-border)" }} />
                          <div className="flex-1 space-y-2 p-2"><div className="h-1.5 w-2/3 rounded bg-current opacity-20" /><div className="h-6 rounded bg-current opacity-10" /></div>
                        </div>
                        {active && <span className="absolute right-2 top-2 flex h-5 w-5 items-center justify-center rounded-full" style={{ color: T.bg, backgroundColor: T.teal }}><Check size={13} /></span>}
                      </div>
                      <span className="mt-2 flex items-center justify-center gap-1.5 text-sm font-medium" style={{ color: active ? T.teal : T.inkSoft }}><choice.icon size={15} /> {choice.label}</span>
                    </button>
                  );
                })}
              </div>
              <p className="mt-5 text-xs" style={{ color: T.inkFaint }}>{t("settings.themeDeviceHint", "Your choice is saved on this device and applies immediately.")}</p>
            </div>
          )}

          {contentSection === "language" && (
            <div className="flex flex-col gap-2">
              {LANGUAGES.map((language) => {
                const active = language.code === lang;
                return <button key={language.code} type="button" onClick={() => onLanguageChange(language.code)} aria-pressed={active} className="flex min-h-14 items-center justify-between rounded-lg border px-4 py-3 text-left" style={{ color: active ? T.teal : T.ink, borderColor: active ? T.teal : T.borderSoft, backgroundColor: active ? T.tealSoft : T.surface }}><span><span className="block text-sm font-medium">{language.label}</span><span className="mt-0.5 block text-xs" style={{ color: T.inkFaint }}>{language.short}</span></span>{active && <Check size={17} />}</button>;
              })}
              <p className="mt-2 text-xs" style={{ color: T.inkFaint }}>{t("settings.languageDeviceHint", "Your language choice is saved on this device.")}</p>
            </div>
          )}

          {contentSection === "shop" && (
            <div className="flex flex-col gap-5">
              <Field label={t("settings.shopLogo", "Shop logo")}>
                <div className="flex items-center gap-4">
                  <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-lg border" style={{ borderColor: T.borderSoft, backgroundColor: T.bg }}>
                    {settings.logoDataUrl ? <img src={settings.logoDataUrl} alt="Shop logo" className="h-full w-full object-cover" /> : <Frame size={25} style={{ color: T.brass }} />}
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="inline-flex w-fit cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-xs font-semibold" style={{ color: T.ink, borderColor: T.border }}><Upload size={14} /> {uploading ? t("settings.uploading", "Uploading…") : settings.logoDataUrl ? t("settings.changeLogo", "Change logo") : t("settings.uploadLogo", "Upload logo")}<input type="file" accept="image/*" className="hidden" onChange={handleLogoFile} disabled={uploading} /></label>
                    {settings.logoDataUrl && <button type="button" onClick={() => onLogoChange(null)} className="text-left text-xs" style={{ color: T.danger }}>{t("settings.removeLogo", "Remove logo")}</button>}
                  </div>
                </div>
                {logoError && <p className="mt-1.5 text-xs" style={{ color: T.danger }}>{logoError}</p>}
              </Field>
              <Field label={t("settings.shopName", "Shop name")}><TextInput value={name} onChange={(e) => setName(e.target.value)} /></Field>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label={t("settings.phoneOptional", "Phone (optional)")}><TextInput value={phone} onChange={(e) => setPhone(e.target.value)} placeholder={t("settings.shownOnReceipts", "Shown on receipts")} /></Field>
                <Field label={t("settings.addressOptional", "Address (optional)")}><TextInput value={address} onChange={(e) => setAddress(e.target.value)} placeholder={t("settings.shownOnReceipts", "Shown on receipts")} /></Field>
              </div>
              <div className="flex justify-end border-t pt-5" style={{ borderColor: T.borderSoft }}><PrimaryButton onClick={saveShop}>{t("settings.saveChanges", "Save changes")}</PrimaryButton></div>
            </div>
          )}

          {contentSection === "account" && (
            <div className="flex flex-col gap-5">
              <div className="rounded-lg border" style={{ borderColor: T.borderSoft }}>
                {[[t("settings.email", "Email"), user?.email || "—"], ...(user?.phone ? [[t("settings.phone", "Phone"), user.phone.startsWith("+") ? user.phone : "+" + user.phone]] : []), [t("settings.signInMethod", "Sign-in method"), signInMethod], [t("settings.memberSince", "Member since"), joined]].map(([label, value]) => <div key={label} className="flex items-center justify-between gap-4 border-b px-4 py-3 last:border-b-0" style={{ borderColor: T.borderSoft }}><span className="text-xs" style={{ color: T.inkFaint }}>{label}</span><span className="break-all text-right text-xs" style={{ color: T.ink }}>{value}</span></div>)}
              </div>
              {usesPassword ? <>
                <div className="rounded-lg border p-4" style={{ borderColor: T.borderSoft }}>
                  <div className="flex items-center justify-between gap-4"><div><p className="text-sm font-medium" style={{ color: T.ink }}>{t("settings.email", "Email")}</p><p className="mt-0.5 text-xs" style={{ color: T.inkFaint }}>{user?.email}</p></div>{!showEmailForm && <GhostButton onClick={() => { setShowEmailForm(true); setEmailMsg(""); setNewEmail(""); }}>{t("settings.changeEmail", "Change email")}</GhostButton>}</div>
                  {showEmailForm && <div className="mt-4 flex flex-col gap-3"><Field label={t("settings.newEmailAddress", "New email address")}><TextInput type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} /></Field><p className="text-xs" style={{ color: T.inkFaint }}>{t("settings.confirmEmailHint", "We'll send a confirmation link to the new address.")}</p>{emailErr && <p className="text-xs" style={{ color: T.danger }}>{emailErr}</p>}<div className="flex gap-2"><PrimaryButton onClick={changeEmail}>{savingEmail ? t("settings.sending", "Sending…") : t("settings.sendConfirmationLink", "Send confirmation link")}</PrimaryButton><GhostButton onClick={() => setShowEmailForm(false)}>{t("action.cancel", "Cancel")}</GhostButton></div></div>}
                  {emailMsg && <p className="mt-2 text-xs" style={{ color: T.success }}>{emailMsg}</p>}
                </div>
                <div className="rounded-lg border p-4" style={{ borderColor: T.borderSoft }}>
                  <div className="flex items-center justify-between gap-4"><div><p className="text-sm font-medium" style={{ color: T.ink }}>{t("settings.password", "Password")}</p><p className="mt-0.5 text-xs" style={{ color: T.inkFaint }}>••••••••</p></div>{!showPasswordForm && <GhostButton onClick={() => { setShowPasswordForm(true); setPasswordMsg(""); }}>{t("settings.changePassword", "Change password")}</GhostButton>}</div>
                  {showPasswordForm && <div className="mt-4 flex flex-col gap-3"><Field label={t("settings.newPassword", "New password")}><TextInput type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} /></Field><Field label={t("settings.confirmNewPassword", "Confirm new password")}><TextInput type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} /></Field>{passwordErr && <p className="text-xs" style={{ color: T.danger }}>{passwordErr}</p>}<div className="flex gap-2"><PrimaryButton onClick={changePassword}>{savingPassword ? t("settings.saving", "Saving…") : t("settings.updatePassword", "Update password")}</PrimaryButton><GhostButton onClick={() => setShowPasswordForm(false)}>{t("action.cancel", "Cancel")}</GhostButton></div></div>}
                  {passwordMsg && <p className="mt-2 text-xs" style={{ color: T.success }}>{passwordMsg}</p>}
                </div>
              </> : <p className="rounded-lg border p-4 text-sm" style={{ borderColor: T.borderSoft, color: T.inkSoft }}>{usesPhone ? t("settings.phoneNoPassword", "You sign in with your phone number, so there's no password to manage here.") : t("settings.googleNoPassword", "You sign in with Google, so there's no password to manage here.")}</p>}
              <div className="border-t pt-5" style={{ borderColor: T.borderSoft }}><GhostButton onClick={onSignOut} full><LogOut size={16} /> {t("settings.signOut", "Sign out")}</GhostButton></div>
            </div>
          )}

          {contentSection === "team" && isOwner && (
            <div>
              {teamMembers === null ? <p className="text-sm" style={{ color: T.inkFaint }}>{t("settings.migrationNotRun", "Staff logins aren't available yet.")}</p> : <>
                <div className="mb-5 flex flex-col gap-2">{teamMembers.map((m) => <div key={m.id} className="flex items-center justify-between rounded-lg border px-4 py-3" style={{ borderColor: T.borderSoft }}><div className="min-w-0"><p className="truncate text-sm" style={{ color: T.ink }}>{m.invited_email}</p><p className="text-xs" style={{ color: m.member_user_id ? T.success : T.warn }}>{m.member_user_id ? t("settings.joined", "Joined") : t("settings.invitedWaiting", "Invited — waiting for sign-up")}</p></div><IconBtn onClick={() => onRemoveStaff(m.id)} label={t("action.delete", "Remove")} danger><X size={15} /></IconBtn></div>)}</div>
                <div className="flex gap-2"><TextInput type="email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder={t("settings.theirEmailPlaceholder", "Their email address")} /><GhostButton onClick={() => { if (inviteEmail.trim()) { onInviteStaff(inviteEmail); setInviteEmail(""); } }}>{teamBusy ? "…" : t("settings.invite", "Invite")}</GhostButton></div>
                <p className="mt-3 text-xs" style={{ color: T.inkFaint }}>{t("settings.inviteHint", "Tell them to sign up with this exact email address. Access begins automatically after their first sign-in.")}</p>
              </>}
            </div>
          )}

          {contentSection === "data" && (() => {
            const last = settings.lastBackupAt ? new Date(settings.lastBackupAt) : null;
            const days = last ? Math.floor((Date.now() - last.getTime()) / 86400000) : null;
            const stale = days === null || days > 30;
            return <div className="flex flex-col gap-6">
              <div className="rounded-lg border p-4" style={{ borderColor: T.borderSoft }}><div className="mb-4 flex items-center justify-between gap-3"><div><p className="text-sm font-medium" style={{ color: T.ink }}>{t("settings.backupReports", "Backup & reports")}</p><p className="mt-1 text-xs" style={{ color: stale ? T.warn : T.inkFaint }}>{last ? `${t("settings.lastBackup", "Last full backup")}: ${last.toLocaleDateString()}` : t("settings.neverBackedUp", "Never backed up — download one now")}</p></div></div><div className="grid gap-2 sm:grid-cols-2"><GhostButton onClick={backupBusy ? undefined : onExportJson} full><Download size={15} /> {backupBusy ? t("settings.preparingFile", "Preparing…") : t("settings.downloadBackup", "Full backup")}</GhostButton><GhostButton onClick={exportingExcel ? undefined : onExportExcel} full><FileSpreadsheet size={15} /> {exportingExcel ? t("settings.preparingFile", "Preparing…") : t("settings.exportExcel", "Export to Excel")}</GhostButton>{isOwner && <div className="sm:col-span-2"><GhostButton onClick={onRestore} full><Upload size={15} /> {t("settings.restoreBackup", "Restore from backup")}</GhostButton></div>}</div></div>
              <div className="rounded-lg border p-4" style={{ borderColor: T.borderSoft }}><p className="text-sm font-medium" style={{ color: T.ink }}>{t("settings.sampleData", "Sample data")}</p><p className="mb-4 mt-1 text-xs" style={{ color: T.inkFaint }}>{t("settings.sampleDataHint", "Use example records to explore the app without mixing them with real records.")}</p><div className="flex gap-2"><GhostButton onClick={onSeed} full>{t("settings.loadSampleData", "Load sample data")}</GhostButton>{hasDemoData && <GhostButton onClick={onUnseed} full>{t("settings.removeSampleData", "Remove sample data")}</GhostButton>}</div></div>
              <p className="text-xs" style={{ color: T.inkFaint }}>{t("settings.syncedFooter", "Your shop data is saved to your account and synced automatically across signed-in devices.")}</p>
            </div>;
          })()}

          {contentSection === "danger" && isOwner && <div className="rounded-lg border p-5" style={{ borderColor: T.dangerSoft, backgroundColor: T.dangerSoft }}><p className="text-sm font-semibold" style={{ color: T.danger }}>{t("settings.clearAllData", "Clear all data")}</p><p className="mb-5 mt-1 text-xs" style={{ color: T.inkSoft }}>{t("settings.clearAllHint", "Permanently deletes stock, orders, customers, and expenses. Download a backup first.")}</p><button type="button" onClick={onClearAll} className="min-h-11 rounded-md border px-4 py-2.5 text-sm font-semibold" style={{ color: T.danger, borderColor: T.danger }}>{t("settings.clearAllData", "Clear all data")}</button></div>}
        </section>
      </div>
    </Modal>
  );
}


