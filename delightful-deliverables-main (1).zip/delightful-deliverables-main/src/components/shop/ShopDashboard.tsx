// @ts-nocheck
import React, { lazy, Suspense } from "react";
import { ChevronRight, Clock, PackageCheck, AlertTriangle, Users } from "lucide-react";
import { T, PAYMENT_MODES, fmtMoney, fmtShortDate, orderWaMessage, Badge, CategoryTag, StatusBadge, ContactActions, StatCard, MiniStat } from "./shopShared";

const SalesChart = lazy(() => import("./SalesChart"));

export default function DashboardTab({ dashboard, finance, customers, setTab, shopName, t, canSeeMoney = true }) {
  return (
    <div className="flex flex-col gap-5">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label={t("dashboard.todaysSales", "Today's sales")} value={fmtMoney(dashboard.todaySales)} accent={T.teal} />
        <StatCard label={t("dashboard.thisMonth", "This month's sales")} value={fmtMoney(dashboard.monthSales)} accent={T.brass} />
        <StatCard label={t("dashboard.outstanding", "Outstanding balance")} value={fmtMoney(finance.totalOutstanding)} accent={T.warn} />
        {canSeeMoney ? (
          <StatCard
            label={t("dashboard.netProfit", "Net profit (overall)")}
            value={fmtMoney(finance.netProfit)}
            accent={finance.netProfit >= 0 ? T.success : T.danger}
          />
        ) : (
          <StatCard label={t("dashboard.totalSales", "Total sales")} value={fmtMoney(finance.totalSales)} accent={T.success} />
        )}
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <MiniStat label={t("dashboard.pending", "Pending orders")} value={dashboard.pending} icon={Clock} />
        <MiniStat label={t("dashboard.ready", "Ready for delivery")} value={dashboard.ready} icon={PackageCheck} />
        <MiniStat label={t("dashboard.lowStock", "Low stock items")} value={dashboard.lowStock.length} icon={AlertTriangle} />
        <MiniStat label={t("dashboard.customers", "Total customers")} value={customers.length} icon={Users} />
      </div>

      <div className="rounded-lg border p-5" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm font-semibold" style={{ color: T.ink }}>{t("dashboard.todaysCollections", "Today's collections")}</p>
          <span className="text-xs" style={{ color: T.inkFaint }}>{t("dashboard.forClosingTill", "For closing the till")}</span>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {Array.from(new Set([...PAYMENT_MODES, ...Object.keys(dashboard.collectionsToday)])).map((m) => (
            <div key={m} className="rounded-md px-3 py-2.5 text-center" style={{ backgroundColor: `color-mix(in oklab, ${T.borderSoft} 50%, transparent)` }}>
              <p className="text-xs truncate" style={{ color: T.inkSoft }}>{m}</p>
              <p className="text-base font-semibold tabular-nums" style={{ color: T.ink }}>{fmtMoney(dashboard.collectionsToday[m] || 0)}</p>
            </div>
          ))}
        </div>
        <p className="text-xs mt-2.5" style={{ color: T.inkFaint }}>{t("dashboard.onlyTodaysOrders", "Only covers payments on orders placed today — a balance settled today on an older order isn't included here.")}</p>
      </div>

      <div className="rounded-lg border p-5" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
        <p className="text-sm font-semibold mb-4" style={{ color: T.ink }}>{t("dashboard.salesLast7Days", "Sales — last 7 days")}</p>
        <Suspense fallback={<div style={{ width: "100%", height: 180 }} className="flex items-center justify-center"><span className="text-xs" style={{ color: T.inkFaint }}>{t("dashboard.loadingChart", "Loading chart…")}</span></div>}>
          <SalesChart
            data={dashboard.week}
            colors={{ borderSoft: T.borderSoft, inkSoft: T.inkSoft, inkFaint: T.inkFaint, surface: T.surface, teal: T.teal, ink: T.ink }}
            formatMoney={fmtMoney}
          />
        </Suspense>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-lg border p-5" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-semibold" style={{ color: T.ink }}>{t("dashboard.lowStockAlerts", "Low stock alerts")}</p>
            <button onClick={() => setTab("stock")} className="text-xs font-medium flex items-center gap-0.5" style={{ color: T.teal }}>
              {t("dashboard.viewStock", "View stock")} <ChevronRight size={13} />
            </button>
          </div>
          {dashboard.lowStock.length === 0 ? (
            <p className="text-sm py-4 text-center" style={{ color: T.inkFaint }}>{t("dashboard.stockHealthy", "Nothing running low — stock looks healthy.")}</p>
          ) : (
            <div className="flex flex-col divide-y" style={{ borderColor: T.borderSoft }}>
              {dashboard.lowStock.slice(0, 5).map((p) => (
                <div key={p.id} className="flex items-center justify-between py-2.5">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: T.ink }}>{p.name}</p>
                    <CategoryTag category={p.category} />
                  </div>
                  <Badge text={t("dashboard.itemsLeft", "{n} left", { n: p.current })} color={T.danger} soft={T.dangerSoft} />
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-lg border p-5" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-semibold" style={{ color: T.ink }}>{t("dashboard.paymentReminders", "Payment reminders")}</p>
            <button onClick={() => setTab("orders")} className="text-xs font-medium flex items-center gap-0.5" style={{ color: T.teal }}>
              {t("dashboard.viewOrders", "View orders")} <ChevronRight size={13} />
            </button>
          </div>
          {dashboard.paymentReminders.length === 0 ? (
            <p className="text-sm py-4 text-center" style={{ color: T.inkFaint }}>{t("dashboard.noOutstanding", "No outstanding balances — nice.")}</p>
          ) : (
            <div className="flex flex-col divide-y" style={{ borderColor: T.borderSoft }}>
              {dashboard.paymentReminders.slice(0, 5).map((o) => (
                <div key={o.id} className="flex items-center justify-between py-2.5 gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: T.ink }}>{o.customerName || t("dashboard.walkIn", "Walk-in")}</p>
                    <p className="text-xs" style={{ color: T.inkFaint }}>
                      {o.orderNo} · {o.daysOutstanding === 0 ? t("dashboard.today", "Today") : t("dashboard.daysAgo", `${o.daysOutstanding} day${o.daysOutstanding === 1 ? "" : "s"} ago`, { n: o.daysOutstanding })}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm font-semibold tabular-nums" style={{ color: o.daysOutstanding >= 14 ? T.danger : o.daysOutstanding >= 7 ? T.warn : T.ink }}>
                      {fmtMoney(o.balance)}
                    </span>
                    <ContactActions phone={o.customerPhone} message={orderWaMessage(o, shopName)} />
                  </div>
                </div>
              ))}
              {dashboard.paymentReminders.length > 5 && (
                <p className="text-xs pt-2.5 text-center" style={{ color: T.inkFaint }}>{t("dashboard.moreBalanceDue", `+${dashboard.paymentReminders.length - 5} more with a balance due`, { n: dashboard.paymentReminders.length - 5 })}</p>
              )}
            </div>
          )}
        </div>

        <div className="rounded-lg border p-5" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-semibold" style={{ color: T.ink }}>{t("dashboard.deliveriesDueSoon", "Deliveries due soon")}</p>
            <button onClick={() => setTab("orders")} className="text-xs font-medium flex items-center gap-0.5" style={{ color: T.teal }}>
              {t("dashboard.viewOrders", "View orders")} <ChevronRight size={13} />
            </button>
          </div>
          {dashboard.dueSoon.length === 0 ? (
            <p className="text-sm py-4 text-center" style={{ color: T.inkFaint }}>{t("dashboard.noDeliveriesDue", "No deliveries due in the next 3 days.")}</p>
          ) : (
            <div className="flex flex-col divide-y" style={{ borderColor: T.borderSoft }}>
              {dashboard.dueSoon.slice(0, 5).map((o) => (
                <div key={o.id} className="flex items-center justify-between py-2.5 gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: T.ink }}>{o.customerName || t("dashboard.walkIn", "Walk-in")}</p>
                    <p className="text-xs" style={{ color: T.inkFaint }}>{fmtShortDate(o.deliveryDate)} · {o.orderNo}</p>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <StatusBadge status={o.status} t={t} />
                    <ContactActions phone={o.customerPhone} message={orderWaMessage(o, shopName)} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

