// @ts-nocheck
// One place that decides what a valid product / customer / order / expense looks
// like. The forms check against these before saving (so a person gets a clear
// message instead of a failed write), and shopRepo checks again right before it
// talks to the database (so nothing broken can slip in through another path).
import { z } from "zod";

// Form fields arrive as strings ("", "12", "12.5"); treat blank as "not given".
const money = (label) =>
  z.preprocess(
    (v) => (v === "" || v === null || v === undefined ? 0 : typeof v === "string" ? Number(v) : v),
    z.number({ invalid_type_error: `${label} must be a number` }).finite(`${label} must be a number`).min(0, `${label} can't be negative`)
  );
const count = (label, min = 0) =>
  z.preprocess(
    (v) => (v === "" || v === null || v === undefined ? 0 : typeof v === "string" ? Number(v) : v),
    z.number({ invalid_type_error: `${label} must be a whole number` }).int(`${label} must be a whole number`).min(min, min > 0 ? `${label} must be at least ${min}` : `${label} can't be negative`)
  );
const text = (label, max = 300) => z.string().trim().min(1, `${label} is required`).max(max, `${label} is too long`);
const optionalText = (max = 2000) => z.union([z.string().max(max, "This text is too long"), z.literal(""), z.null(), z.undefined()]);
const isoDate = (label) =>
  z.union([
    z.string().regex(/^\d{4}-\d{2}-\d{2}$/, `${label} must be a valid date`),
    z.literal(""),
    z.null(),
    z.undefined(),
  ]);

export const productSchema = z
  .object({
    id: z.string().min(1),
    name: text("Product name", 200),
    category: text("Category", 80),
    sku: z.string().trim().max(40, "SKU is too long").optional().or(z.literal("")),
    size: optionalText(120),
    customization: optionalText(500),
    costPrice: money("Cost price"),
    sellingPrice: money("Selling price"),
    openingStock: count("Opening stock"),
    reorderLevel: count("Reorder level"),
    gstRate: z.preprocess(
      (v) => (v === "" || v === null || v === undefined ? 0 : typeof v === "string" ? Number(v) : v),
      z.number().min(0, "GST rate can't be negative").max(100, "GST rate can't be over 100%")
    ).optional(),
  })
  .passthrough();

export const restockSchema = z
  .object({
    qty: count("Quantity", 1),
    date: isoDate("Restock date"),
    note: optionalText(300),
  })
  .passthrough();

export const customerSchema = z
  .object({
    id: z.string().min(1),
    name: text("Customer name", 200),
    phone: z
      .string()
      .trim()
      .min(6, "Phone number looks too short")
      .max(20, "Phone number looks too long")
      .regex(/^[0-9+\-\s()]+$/, "Phone number can only contain digits"),
    address: optionalText(500),
    notes: optionalText(1000),
  })
  .passthrough();

export const expenseSchema = z
  .object({
    id: z.string().min(1),
    category: text("Expense category", 80),
    amount: money("Amount"),
    date: isoDate("Expense date"),
    paymentMode: z.string().min(1, "Payment mode is required"),
    description: optionalText(500),
  })
  .passthrough();

export const orderItemSchema = z
  .object({
    name: text("Item name", 200),
    qty: count("Item quantity", 1),
    unitPrice: money("Item price"),
    unitCost: z.union([money("Item cost"), z.literal(""), z.null(), z.undefined()]),
  })
  .passthrough();

export const orderSchema = z
  .object({
    id: z.string().min(1),
    date: isoDate("Order date"),
    orderType: z.string().min(1, "Order type is required"),
    status: z.string().min(1, "Order status is required"),
    customerName: optionalText(200),
    customerPhone: z.union([
      z.string().trim().max(20, "Phone number looks too long").regex(/^[0-9+\-\s()]*$/, "Phone number can only contain digits"),
      z.null(),
      z.undefined(),
    ]),
    // Saving an existing order with no lines is tolerated here (old records exist);
    // the form schema below is the one that insists on at least one item.
    items: z.array(orderItemSchema).optional().default([]),
    discountValue: money("Discount"),
    advance: money("Advance"),
    deliveryDate: isoDate("Delivery date"),
    notes: optionalText(1000),
  })
  .passthrough()
  .superRefine((o, ctx) => {
    if (o.discountType === "percent" && Number(o.discountValue || 0) > 100) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: "A percentage discount can't be more than 100%" });
    }
  });

// What a person filling in the order form must provide.
export const orderFormSchema = orderSchema.superRefine((o, ctx) => {
  if (!o.items || o.items.length === 0) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Add at least one item to the order" });
  }
});

export const settingsSchema = z
  .object({
    shopName: text("Shop name", 120),
    shopPhone: optionalText(20),
    shopAddress: optionalText(500),
  })
  .passthrough();

// Returns null when everything is fine, otherwise the first problem in plain words.
export function firstError(schema, value) {
  const res = schema.safeParse(value);
  if (res.success) return null;
  const issue = res.error.issues[0];
  return issue?.message || "Please check the details and try again";
}

export function checkAll(schema, list) {
  for (const item of list || []) {
    const err = firstError(schema, item);
    if (err) return err;
  }
  return null;
}
