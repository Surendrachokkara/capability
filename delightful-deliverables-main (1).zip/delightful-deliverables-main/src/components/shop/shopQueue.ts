// @ts-nocheck
// Offline write queue.
//
// When a save can't reach the server (airplane mode, dead spot in the shop, wifi
// dropped mid-billing), the change is kept on this device as a small list of
// "these exact records changed" / "these were deleted" instead of being lost or
// blocking the person from working. The moment the connection is back, the queue
// is replayed record by record, so offline work merges into whatever else
// happened meanwhile rather than overwriting it.
import * as shopRepo from "./shopRepo";

const PREFIX = "shop-pending-";
const KINDS = ["products", "customers", "expenses", "orders"];

const emptyQueue = () => ({ products: null, customers: null, expenses: null, orders: null, settings: undefined });

function read(shopId) {
  try {
    const raw = window.localStorage.getItem(PREFIX + shopId);
    return raw ? { ...emptyQueue(), ...JSON.parse(raw) } : emptyQueue();
  } catch {
    return emptyQueue();
  }
}

function write(shopId, queue) {
  try {
    window.localStorage.setItem(PREFIX + shopId, JSON.stringify(queue));
  } catch {
    // Storage full or blocked — nothing useful we can do beyond not crashing.
  }
}

export function clear(shopId) {
  try { window.localStorage.removeItem(PREFIX + shopId); } catch {}
}

// Number of individual records waiting to sync — what the banner counts.
export function pendingCount(shopId) {
  const q = read(shopId);
  let n = q.settings === undefined ? 0 : 1;
  KINDS.forEach((k) => {
    if (q[k]) n += (q[k].upserts?.length || 0) + (q[k].deletes?.length || 0);
  });
  return n;
}

export function hasPending(shopId) {
  return pendingCount(shopId) > 0;
}

// When the oldest waiting change was made, so the banner can say how stale it is.
export function pendingSince(shopId) {
  const q = read(shopId);
  if (!pendingCount(shopId)) return null;
  return q.queuedAt || Date.now();
}

// Records a failed save. The whole list is compared against what the server last
// gave us, so only genuinely changed and removed records are remembered.
export function enqueue(shopId, kind, value) {
  if (!shopId) return;
  const q = read(shopId);
  if (!q.queuedAt) q.queuedAt = Date.now();
  if (kind === "settings") {
    q.settings = value;
  } else if (KINDS.includes(kind)) {
    const { upserts, deletes } = shopRepo.diffList(kind, value);
    const prev = q[kind] || { upserts: [], deletes: [] };
    const byId = {};
    prev.upserts.forEach((r) => { byId[r.id] = r; });
    upserts.forEach((r) => { byId[r.id] = r; });
    const removed = new Set([...prev.deletes, ...deletes]);
    // A record that was deleted and then re-created keeps the newer state only.
    upserts.forEach((r) => removed.delete(r.id));
    q[kind] = {
      upserts: Object.values(byId).filter((r) => !removed.has(r.id)),
      deletes: [...removed],
    };
  }
  write(shopId, q);
}


// Sends everything that's waiting. Returns how many records went through; throws
// if the connection is still bad, leaving the queue intact for the next attempt.
export async function flush(shopId) {
  const q = read(shopId);
  let sent = 0;
  for (const kind of KINDS) {
    const ops = q[kind];
    if (!ops) continue;
    await shopRepo.applyOps(shopId, kind, ops);
    sent += (ops.upserts?.length || 0) + (ops.deletes?.length || 0);
    q[kind] = null;
    write(shopId, q);
  }
  if (q.settings !== undefined) {
    await shopRepo.saveKind(shopId, "settings", q.settings);
    sent += 1;
    q.settings = undefined;
    write(shopId, q);
  }
  clear(shopId);
  return sent;
}
