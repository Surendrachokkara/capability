// @ts-nocheck
// Rebuilt without recharts/d3: the earlier version pulled in a ~368KB (98KB gzipped)
// chunk just to draw 7 bars. That's most of a charting-library-plus-d3 dependency tree
// for something plain SVG does natively in a few KB. Every feature from the previous
// version is kept — gridlines, formatted currency axis, hover highlight, a value
// readout — just built by hand instead of through a library.
import { useState } from "react";

// Rounds a value up to a "nice" round number for axis scaling (100, 200, 500, 1000,
// 2000, 5000...) the same way a real charting library picks its tick values, so the
// Y-axis doesn't show awkward numbers like "1,847".
function niceCeil(value) {
  if (!value || value <= 0) return 100;
  const exp = Math.floor(Math.log10(value));
  const base = Math.pow(10, exp);
  const norm = value / base;
  const niceNorm = norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10;
  return niceNorm * base;
}

export default function SalesChart({ data, colors, formatMoney }) {
  const [hoverIdx, setHoverIdx] = useState(null);
  const items = data && data.length ? data : [];
  const maxVal = niceCeil(Math.max(0, ...items.map((d) => Number(d.sales) || 0)));

  const W = 600;
  const H = 200;
  const padL = 54;
  const padR = 8;
  const padT = 22;
  const padB = 24;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;
  const n = Math.max(1, items.length);
  const slot = plotW / n;
  const barW = Math.min(38, slot * 0.55);
  const ticks = [0, 0.5, 1].map((f) => Math.round(maxVal * f));

  const yFor = (v) => padT + plotH - (Math.max(0, Number(v) || 0) / maxVal) * plotH;

  return (
    <div style={{ width: "100%", height: 180 }}>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%" preserveAspectRatio="none" style={{ overflow: "visible" }}>
        {/* Gridlines + Y-axis labels */}
        {ticks.map((t, i) => {
          const y = yFor(t);
          return (
            <g key={i}>
              <line x1={padL} y1={y} x2={W - padR} y2={y} stroke={colors.borderSoft} strokeDasharray="2 4" />
              <text x={padL - 8} y={y} textAnchor="end" dominantBaseline="middle" fontSize={11} fill={colors.inkFaint}>
                {formatMoney(t)}
              </text>
            </g>
          );
        })}

        {/* Bars + hover targets + X-axis labels */}
        {items.map((d, i) => {
          const cx = padL + slot * i + slot / 2;
          const val = Number(d.sales) || 0;
          const barY = yFor(val);
          const isHover = hoverIdx === i;
          return (
            <g
              key={i}
              onMouseEnter={() => setHoverIdx(i)}
              onMouseLeave={() => setHoverIdx((h) => (h === i ? null : h))}
              style={{ cursor: "pointer" }}
            >
              {/* Full-height invisible hit area — easier to hover accurately than the bar alone, especially for small values */}
              <rect x={padL + slot * i} y={padT} width={slot} height={plotH} fill="transparent" />
              {isHover && <rect x={padL + slot * i} y={padT} width={slot} height={plotH} fill={colors.borderSoft} opacity={0.5} />}
              <rect
                x={cx - barW / 2}
                y={barY}
                width={barW}
                height={Math.max(0, padT + plotH - barY)}
                rx={4}
                fill={colors.teal}
                opacity={isHover ? 0.85 : 1}
              />
              <text x={cx} y={H - 6} textAnchor="middle" fontSize={11} fill={isHover ? colors.ink : colors.inkSoft}>
                {d.day}
              </text>
              {isHover && (
                <text x={cx} y={Math.max(12, barY - 8)} textAnchor="middle" fontSize={12} fontWeight={600} fill={colors.ink}>
                  {formatMoney(val)}
                </text>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
}
