// @ts-nocheck
// Relational persistence layer for the shop app.
//
// The UI still works with plain arrays of camelCase records (products, orders,
// customers, expenses) exactly as it always has. This module is the only place
// that knows those arrays are actually stored as normalised rows in products /
// customers / expenses / orders / order_items / order_payments /
// product_restocks. Keeping the translation here means a single edit to a
// product writes one small row instead of rewriting the entire shop.
import { supabase } from "@/integrations/supabase/client";
import { checkAll, productSchema, customerSchema, expenseSchema, orderSchema } from "./shopSchemas";

const DEFAULT_SETTINGS = { shopName: "Frame & Gifts Shop", shopPhone: "", shopAddress: "" };

const num = (v) => {
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : 0;
};
const int = (v) => Math.round(num(v));
const orNull = (v) => (v === undefined || v === "" ? null : v);
const dateOrNull = (v) => (v && String(v).trim() ? String(v).slice(0, 10) : null);

/* ---------------- row <-> record mapping ---------------- */

const productToRow = (p, shopId) => ({
  id: p.id,
  shop_owner_id: shopId,
  sku: p.sku || "",
  category: p.category || "",
  name: p.name || "",
  size: orNull(p.size),
  customization: orNull(p.customization),
  cost_price: num(p.costPrice),
  selling_price: num(p.sellingPrice),
  opening_stock: int(p.openingStock),
  reorder_level: int(p.reorderLevel),
  active: p.active !== false,
  gst_rate: p.gstRate === undefined || p.gstRate === "" ? 0 : num(p.gstRate),
  hsn_code: orNull(p.hsnCode),
});

const rowToProduct = (r, restocks) => ({
  id: r.id,
  sku: r.sku,
  category: r.category,
  name: r.name,
  size: r.size || "",
  customization: r.customization || "",
  costPrice: r.cost_price,
  sellingPrice: r.selling_price,
  openingStock: r.opening_stock,
  reorderLevel: r.reorder_level,
  active: r.active,
  gstRate: r.gst_rate ?? 0,
  hsnCode: r.hsn_code || "",
  restocks: (restocks || []).map((x) => ({ date: x.restocked_at, qty: x.qty, note: x.note || "" })),
});

const customerToRow = (c, shopId) => ({
  id: c.id,
  shop_owner_id: shopId,
  name: c.name || "",
  phone: c.phone || "",
  address: orNull(c.address),
  notes: orNull(c.notes),
});

const rowToCustomer = (r) => ({
  id: r.id,
  name: r.name,
  phone: r.phone,
  address: r.address || "",
  notes: r.notes || "",
});

const expenseToRow = (e, shopId) => ({
  id: e.id,
  shop_owner_id: shopId,
  supplier_id: orNull(e.supplierId),
  spent_at: dateOrNull(e.date) || new Date().toISOString().slice(0, 10),
  category: e.category || "Other",
  description: orNull(e.description),
  amount: num(e.amount),
  payment_mode: e.paymentMode || "Cash",
});

const rowToExpense = (r) => ({
  id: r.id,
  supplierId: r.supplier_id || "",
  date: r.spent_at,
  category: r.category,
  description: r.description || "",
  amount: r.amount,
  paymentMode: r.payment_mode,
});

const orderToRow = (o, shopId) => ({
  id: o.id,
  shop_owner_id: shopId,
  customer_id: orNull(o.customerId),
  order_no: o.orderNo || o.id,
  order_date: dateOrNull(o.date) || new Date().toISOString().slice(0, 10),
  customer_name: orNull(o.customerName),
  customer_phone: orNull(o.customerPhone),
  order_type: o.orderType || "Walk-in",
  status: o.status || "Pending",
  discount_type: orNull(o.discountType),
  discount_value: num(o.discountValue),
  advance: num(o.advance),
  payment_mode: orNull(o.paymentMode),
  split_payment: Boolean(o.splitPayment),
  delivery_date: dateOrNull(o.deliveryDate),
  notes: orNull(o.notes),
});

const rowToOrder = (r, items, payments) => ({
  id: r.id,
  orderNo: r.order_no,
  date: r.order_date,
  customerId: r.customer_id || "",
  customerName: r.customer_name || "",
  customerPhone: r.customer_phone || "",
  orderType: r.order_type,
  status: r.status,
  discountType: r.discount_type || "",
  discountValue: r.discount_value,
  advance: r.advance,
  paymentMode: r.payment_mode || "",
  splitPayment: r.split_payment,
  deliveryDate: r.delivery_date || "",
  notes: r.notes || "",
  items: (items || []).map((it) => ({
    rowId: it.id,
    productId: it.product_id || "",
    name: it.name,
    category: it.category || "",
    sku: it.sku || "",
    qty: it.qty,
    unitPrice: it.unit_price,
    unitCost: it.unit_cost ?? "",
    customPhoto: it.custom_photo,
    customPhotoNote: it.custom_photo_note || "",
    customPhotoDataUrl: it.custom_photo_data_url || "",
  })),
  payments: (payments || []).map((p) => ({ mode: p.mode, amount: p.amount })),
});

/* ---------------- loading ---------------- */

// The database returns at most 1000 rows per request. A busy shop has more
// orders than that, so every read walks through the rows in pages instead of
// quietly stopping at the first thousand.
const PAGE = 1000;

async function fetchAll(build) {
  const out = [];
  for (let from = 0; ; from += PAGE) {
    const { data, error } = await build().range(from, from + PAGE - 1);
    if (error) throw error;
    out.push(...(data || []));
    if (!data || data.length < PAGE) return out;
  }
}

// Long "one of these ids" lists are split up so a single request never grows
// beyond what the database will accept.
const ID_CHUNK = 200;

async function fetchChildren(table, column, ids) {
  const out = [];
  for (let i = 0; i < ids.length; i += ID_CHUNK) {
    const slice = ids.slice(i, i + ID_CHUNK);
    out.push(...(await fetchAll(() => supabase.from(table).select("*").in(column, slice))));
  }
  return out;
}

// Order lines are fetched in full, photo included: saving an edited order rewrites
// its lines, so anything left out here would be wiped on the next save.
const ITEM_COLUMNS = "*";

export async function loadShop(shopId) {
  // One round of requests, not two: each parent brings its own child rows along
  // instead of the app waiting for the parents to arrive before it can even ask.
  const [productRows, customerRows, expenseRows, orderRows, settingsRes] = await Promise.all([
    fetchAll(() =>
      supabase.from("products").select("*, product_restocks(*)").eq("shop_owner_id", shopId),
    ),
    fetchAll(() => supabase.from("customers").select("*").eq("shop_owner_id", shopId)),
    fetchAll(() => supabase.from("expenses").select("*").eq("shop_owner_id", shopId)),
    fetchAll(() =>
      supabase
        .from("orders")
        .select(`*, order_items(${ITEM_COLUMNS}), order_payments(*)`)
        .eq("shop_owner_id", shopId),
    ),
    supabase.from("shop_data").select("settings").eq("user_id", shopId).maybeSingle(),
  ]);
  if (settingsRes.error) throw settingsRes.error;
  const prodRes = { data: productRows };
  const custRes = { data: customerRows };
  const expRes = { data: expenseRows };
  const ordRes = { data: orderRows };

  const restocksByProduct = {};
  productRows.forEach((r) => { restocksByProduct[r.id] = r.product_restocks || []; });
  const itemsByOrder = {};
  const paymentsByOrder = {};
  orderRows.forEach((r) => {
    itemsByOrder[r.id] = r.order_items || [];
    paymentsByOrder[r.id] = r.order_payments || [];
  });

  const products = (prodRes.data || [])
    .map((r) => rowToProduct(r, restocksByProduct[r.id]))
    .sort((a, b) => String(a.name).localeCompare(String(b.name)));
  const customers = (custRes.data || []).map(rowToCustomer).sort((a, b) => String(a.name).localeCompare(String(b.name)));
  const expenses = (expRes.data || []).map(rowToExpense).sort((a, b) => String(b.date).localeCompare(String(a.date)));
  const orders = (ordRes.data || [])
    .map((r) => rowToOrder(r, itemsByOrder[r.id], paymentsByOrder[r.id]))
    .sort((a, b) => String(b.orderNo).localeCompare(String(a.orderNo)));

  return {
    products,
    customers,
    expenses,
    orders,
    settings: settingsRes.data?.settings || DEFAULT_SETTINGS,
  };
}

export async function ensureShopRow(shopId, settings) {
  const { error } = await supabase
    .from("shop_data")
    .upsert({ user_id: shopId, settings: settings || DEFAULT_SETTINGS }, { onConflict: "user_id" });
  if (error) throw error;
}

/* ---------------- saving ---------------- */

// Whole-array saves stay the UI's contract, but only what actually changed goes
// over the wire: rows are upserted, rows that disappeared from the array are
// deleted, and child rows (order lines, payments, restocks) are only rewritten
// for records whose contents actually changed since the last read.
const childSnapshots = { orders: {}, products: {} };

// What the server last told us each record looked like. Used to work out exactly
// what a person changed while they were offline, so reconnecting re-sends only
// their own edits instead of overwriting whatever happened elsewhere meanwhile.
const KINDS = ["products", "customers", "expenses", "orders"];
const listSnapshots = { products: {}, customers: {}, expenses: {}, orders: {} };

function snapshotList(kind, list) {
  const map = {};
  (list || []).forEach((r) => { map[r.id] = JSON.stringify(r); });
  listSnapshots[kind] = map;
}

export function resetSnapshots() {
  childSnapshots.orders = {};
  childSnapshots.products = {};
  KINDS.forEach((k) => { listSnapshots[k] = {}; });
}

export function primeSnapshots(shop) {
  resetSnapshots();
  (shop.orders || []).forEach((o) => {
    childSnapshots.orders[o.id] = JSON.stringify([o.items || [], o.payments || []]);
  });
  (shop.products || []).forEach((p) => {
    childSnapshots.products[p.id] = JSON.stringify(p.restocks || []);
  });
  KINDS.forEach((k) => snapshotList(k, shop[k]));
}

// Which records in this list differ from the last known server state, and which
// ones disappeared. Settings are a single value, so they have no diff.
export function diffList(kind, list) {
  const prev = listSnapshots[kind] || {};
  const upserts = [];
  const seen = new Set();
  (list || []).forEach((r) => {
    seen.add(r.id);
    if (prev[r.id] !== JSON.stringify(r)) upserts.push(r);
  });
  const deletes = Object.keys(prev).filter((id) => !seen.has(id));
  return { upserts, deletes };
}

async function syncTable(table, shopId, rows, ids) {
  if (rows.length) {
    const { error } = await supabase.from(table).upsert(rows, { onConflict: "id" });
    if (error) throw error;
  }
  const del = supabase.from(table).delete().eq("shop_owner_id", shopId);
  const { error: delErr } = ids.length ? await del.not("id", "in", `(${ids.map((i) => `"${i}"`).join(",")})`) : await del;
  if (delErr) throw delErr;
}

// Last line of defence: whatever path a write came from, it gets checked against
// the same rules the forms use before anything reaches the database.
function assertValid(err) {
  if (err) throw new Error(err);
}

async function saveProducts(shopId, list) {
  assertValid(checkAll(productSchema, list));
  const rows = list.map((p) => productToRow(p, shopId));
  await syncTable("products", shopId, rows, list.map((p) => p.id));

  for (const p of list) {
    const snap = JSON.stringify(p.restocks || []);
    if (childSnapshots.products[p.id] === snap) continue;
    const { error: delErr } = await supabase.from("product_restocks").delete().eq("product_id", p.id);
    if (delErr) throw delErr;
    const restocks = (p.restocks || []).map((r) => ({
      product_id: p.id,
      restocked_at: dateOrNull(r.date) || new Date().toISOString().slice(0, 10),
      qty: int(r.qty),
      note: orNull(r.note),
    }));
    if (restocks.length) {
      const { error } = await supabase.from("product_restocks").insert(restocks);
      if (error) throw error;
    }
    childSnapshots.products[p.id] = snap;
  }
  snapshotList("products", list);
}

async function saveCustomers(shopId, list) {
  assertValid(checkAll(customerSchema, list));
  await syncTable("customers", shopId, list.map((c) => customerToRow(c, shopId)), list.map((c) => c.id));
  snapshotList("customers", list);
}

async function saveExpenses(shopId, list) {
  assertValid(checkAll(expenseSchema, list));
  await syncTable("expenses", shopId, list.map((e) => expenseToRow(e, shopId)), list.map((e) => e.id));
  snapshotList("expenses", list);
}

async function saveOrders(shopId, list) {
  assertValid(checkAll(orderSchema, list));
  await syncTable("orders", shopId, list.map((o) => orderToRow(o, shopId)), list.map((o) => o.id));

  for (const o of list) {
    const snap = JSON.stringify([o.items || [], o.payments || []]);
    if (childSnapshots.orders[o.id] === snap) continue;

    const [delItems, delPays] = await Promise.all([
      supabase.from("order_items").delete().eq("order_id", o.id),
      supabase.from("order_payments").delete().eq("order_id", o.id),
    ]);
    if (delItems.error) throw delItems.error;
    if (delPays.error) throw delPays.error;

    const items = (o.items || []).map((it) => ({
      order_id: o.id,
      product_id: orNull(it.productId),
      name: it.name || "",
      category: orNull(it.category),
      sku: orNull(it.sku),
      qty: int(it.qty),
      unit_price: num(it.unitPrice),
      unit_cost: it.unitCost === "" || it.unitCost === undefined || it.unitCost === null ? null : num(it.unitCost),
      custom_photo: Boolean(it.customPhoto),
      custom_photo_note: orNull(it.customPhotoNote),
      custom_photo_data_url: orNull(it.customPhotoDataUrl),
    }));
    if (items.length) {
      const { error } = await supabase.from("order_items").insert(items);
      if (error) throw error;
    }
    const payments = (o.payments || [])
      .filter((p) => p && p.mode)
      .map((p) => ({ order_id: o.id, mode: p.mode, amount: num(p.amount) }));
    if (payments.length) {
      const { error } = await supabase.from("order_payments").insert(payments);
      if (error) throw error;
    }
    childSnapshots.orders[o.id] = snap;
  }
  snapshotList("orders", list);
}

async function saveSettings(shopId, settings) {
  const { error } = await supabase
    .from("shop_data")
    .upsert({ user_id: shopId, settings: settings || DEFAULT_SETTINGS }, { onConflict: "user_id" });
  if (error) throw error;
}

/* ---------------- atomic single-order save ---------------- */

// One order, its lines and its payments go to the database as a single
// all-or-nothing operation, and a brand-new order gets its number handed out by
// the shop's own counter — so two people saving at the same moment can never
// land on the same order number or leave half an order behind.
export async function saveOrderAtomic(shopId, order, { assignOrderNo = false } = {}) {
  assertValid(checkAll(orderSchema, [order]));

  const row = orderToRow(order, shopId);
  const items = (order.items || []).map((it) => ({
    product_id: orNull(it.productId),
    name: it.name || "",
    category: orNull(it.category),
    sku: orNull(it.sku),
    qty: int(it.qty),
    unit_price: num(it.unitPrice),
    unit_cost: it.unitCost === "" || it.unitCost === undefined || it.unitCost === null ? null : num(it.unitCost),
    custom_photo: Boolean(it.customPhoto),
    custom_photo_note: orNull(it.customPhotoNote),
    custom_photo_data_url: orNull(it.customPhotoDataUrl),
  }));
  const payments = (order.payments || [])
    .filter((p) => p && p.mode)
    .map((p) => ({ mode: p.mode, amount: num(p.amount) }));

  const { data, error } = await supabase.rpc("save_order", {
    _shop_owner_id: shopId,
    _order: row,
    _items: items,
    _payments: payments,
    _assign_order_no: assignOrderNo,
  });
  if (error) throw error;

  const saved = { ...order, orderNo: data?.order_no || order.orderNo };
  childSnapshots.orders[order.id] = JSON.stringify([order.items || [], order.payments || []]);
  listSnapshots.orders[order.id] = JSON.stringify(saved);
  return saved;
}

/* ---------------- replaying offline changes ---------------- */

// Re-sends only the records a person actually touched while disconnected. Rows
// nobody touched are left exactly as they are on the server, so coming back
// online merges the offline work in rather than restoring a stale whole list.
export async function applyOps(shopId, kind, ops) {
  const { upserts = [], deletes = [] } = ops || {};

  if (kind === "orders") {
    for (const order of upserts) {
      const needsNumber = !order.orderNo || String(order.orderNo).startsWith(PENDING_ORDER_NO);
      await saveOrderAtomic(shopId, order, { assignOrderNo: needsNumber });
    }
  } else if (upserts.length) {
    const toRow = { products: productToRow, customers: customerToRow, expenses: expenseToRow }[kind];
    assertValid(checkAll({ products: productSchema, customers: customerSchema, expenses: expenseSchema }[kind], upserts));
    const { error } = await supabase.from(kind).upsert(upserts.map((r) => toRow(r, shopId)), { onConflict: "id" });
    if (error) throw error;
    if (kind === "products") {
      for (const p of upserts) {
        const { error: delErr } = await supabase.from("product_restocks").delete().eq("product_id", p.id);
        if (delErr) throw delErr;
        const restocks = (p.restocks || []).map((r) => ({
          product_id: p.id,
          restocked_at: dateOrNull(r.date) || new Date().toISOString().slice(0, 10),
          qty: int(r.qty),
          note: orNull(r.note),
        }));
        if (restocks.length) {
          const { error } = await supabase.from("product_restocks").insert(restocks);
          if (error) throw error;
        }
        childSnapshots.products[p.id] = JSON.stringify(p.restocks || []);
      }
    }
  }

  if (deletes.length) {
    const { error } = await supabase.from(kind).delete().eq("shop_owner_id", shopId).in("id", deletes);
    if (error) throw error;
  }
}

// Placeholder number shown on an order created while offline, replaced by the
// shop's real counter number the moment it syncs.
export const PENDING_ORDER_NO = "PENDING";


const SAVERS = {
  products: saveProducts,
  customers: saveCustomers,
  expenses: saveExpenses,
  orders: saveOrders,
  settings: saveSettings,
};

// kind: "products" | "customers" | "expenses" | "orders" | "settings"
export async function saveKind(shopId, kind, value) {
  const fn = SAVERS[kind];
  if (!fn) return;
  await fn(shopId, value);
}

export async function saveKinds(shopId, payload) {
  // Order matters: products and customers first so orders/expenses can reference
  // them, and deletions of referenced rows null out cleanly.
  const order = ["products", "customers", "expenses", "orders", "settings"];
  for (const kind of order) {
    if (payload[kind] !== undefined) await saveKind(shopId, kind, payload[kind]);
  }
}

export async function loadKind(shopId, kind, fallback) {
  try {
    const shop = await loadShop(shopId);
    return shop[kind] ?? fallback;
  } catch {
    return fallback;
  }
}

export const REALTIME_TABLES = [
  "products",
  "customers",
  "expenses",
  "orders",
  "order_items",
  "order_payments",
  "product_restocks",
  "shop_data",
];
