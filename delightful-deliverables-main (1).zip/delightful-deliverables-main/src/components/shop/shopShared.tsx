// @ts-nocheck
import React, { useState, useEffect, useMemo, useCallback, useRef, lazy, Suspense } from "react";
import { LayoutDashboard, Package, ShoppingBag, Users, Wallet, Plus, X, Search, AlertTriangle, Frame, Clock, PackageCheck, CircleCheck, RefreshCw, Phone, Ban, ChevronDown, RotateCcw, Globe } from "lucide-react";
import * as shopRepo from "./shopRepo";
import * as shopQueue from "./shopQueue";

/* ----------------------------- THEME -----------------------------
   "Mission control": near-black panels, hairline borders, monospace
   data readouts, colour reserved for signal (accent) and state
   (success/warn/danger) rather than decoration. */
export const T = {
  bg: "var(--shop-bg)",
  surface: "var(--shop-surface)",
  ink: "var(--shop-ink)",
  inkSoft: "var(--shop-ink-soft)",
  inkFaint: "var(--shop-ink-faint)",
  border: "var(--shop-border)",
  borderSoft: "var(--shop-border-soft)",
  teal: "var(--shop-primary)",
  tealSoft: "var(--shop-primary-soft)",
  brass: "var(--shop-secondary)",
  brassSoft: "var(--shop-secondary-soft)",
  success: "var(--shop-success)",
  successSoft: "var(--shop-success-soft)",
  warn: "var(--shop-warning)",
  warnSoft: "var(--shop-warning-soft)",
  danger: "var(--shop-danger)",
  dangerSoft: "var(--shop-danger-soft)",
  plum: "var(--shop-returned)",
  plumSoft: "var(--shop-returned-soft)",
};
export const FONT_DISPLAY = "'Space Grotesk', sans-serif";
export const FONT_MONO = "'Space Mono', monospace";

export const CATEGORIES = ["Wooden Frame", "Acrylic Frame", "LED Frame", "Gift Item"];
export const CATEGORY_COLORS = {
  "Wooden Frame": "#D99A5B",
  "Acrylic Frame": "#5FB4EC",
  "LED Frame": "#F2CB4E",
  "Gift Item": "#EE93AE",
};
export const PAYMENT_MODES = ["Cash", "UPI", "Card"];
export const ORDER_TYPES = ["Walk-in", "Custom"];
export const ORDER_STATUSES = ["Pending", "In Progress", "Ready", "Delivered", "Cancelled", "Returned"];
export const STATUS_COLORS = {
  Pending: T.warn,
  "In Progress": T.teal,
  Ready: T.success,
  Delivered: T.inkFaint,
  Cancelled: T.danger,
  Returned: T.plum,
};
export const STATUS_ICONS = {
  Pending: Clock,
  "In Progress": RefreshCw,
  Ready: PackageCheck,
  Delivered: CircleCheck,
  Cancelled: Ban,
  Returned: RotateCcw,
};
export const EXPENSE_CATEGORIES = [
  "Raw Material", "Rent", "Electricity", "Salary/Wages", "Transport", "Packaging", "Marketing", "Other",
];

export const NAV = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "stock", label: "Stock", icon: Package },
  { id: "orders", label: "Orders", icon: ShoppingBag },
  { id: "customers", label: "Customers", icon: Users },
  { id: "finance", label: "Finance", icon: Wallet },
];

/* ----------------------------- HELPERS ----------------------------- */
export const genId = (prefix) => `${prefix}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

// Deliberately partial by design, not by accident: covers navigation, universal
// actions (used via shared components everywhere), and the Dashboard as the one
// fully-translated screen — rather than a half-finished attempt at all ~500+ strings
// in this file. Every t() call falls back to its English text if a key is missing
// here, so nothing ever renders blank or breaks because a translation doesn't exist
// yet. Translations are a good-faith effort at standard business Hindi, not the work
// of a certified translator — worth a native speaker's review before staff rely on it
// for anything precise.
export function useLanguage() {
  const [lang, setLangState] = useState(() => {
    try { return window.localStorage.getItem("shop-lang") || "en"; } catch { return "en"; }
  });
  // The translation tables are big; fetch them only when a non-English language is picked.
  const [dict, setDict] = useState({});
  useEffect(() => {
    if (lang === "en") { setDict({}); return; }
    let alive = true;
    import("./shopI18n").then((m) => { if (alive) setDict(m.TRANSLATIONS[lang] || {}); }).catch(() => {});
    return () => { alive = false; };
  }, [lang]);
  const setLang = (l) => {
    setLangState(l);
    try { window.localStorage.setItem("shop-lang", l); } catch {}
  };
  const t = useCallback((key, fallback, vars) => {
    let str = (lang !== "en" && dict[key]) || fallback;
    if (vars) { Object.entries(vars).forEach(([k, v]) => { str = str.replaceAll(`{${k}}`, v); }); }
    return str;
  }, [lang, dict]);
  return { lang, setLang, t };
}

// India's financial year runs April–March. "26-27" for anything from Apr 2026
// through Mar 2027, regardless of what today's date is — an order's own date decides
// its year, so a backdated order still gets a number consistent with when it happened.
export const financialYearShort = (dateStr) => {
  const d = dateStr ? new Date(dateStr + "T00:00:00") : new Date();
  const y = isNaN(d) ? new Date().getFullYear() : d.getFullYear();
  const m = isNaN(d) ? new Date().getMonth() : d.getMonth();
  const startYear = m >= 3 ? y : y - 1;
  return `${String(startYear).slice(-2)}${String(startYear + 1).slice(-2)}`;
};
// Strictly sequential per financial year, with no gaps — what a real invoice series
// needs. Only ever looks at numbers already in this exact "ORD-<FY>-" format, so
// every order created before this existed (any older format) is left alone and
// never renumbered; the new sequence just starts fresh at 0001 for its own year.
export const nextSequentialNo = (records, dateStr, prefixLetters, getField) => {
  const prefix = `${prefixLetters}-${financialYearShort(dateStr)}-`;
  const used = (records || [])
    .map((r) => getField(r) || "")
    .filter((n) => n.startsWith(prefix))
    .map((n) => parseInt(n.slice(prefix.length), 10))
    .filter((n) => !isNaN(n));
  const next = (used.length ? Math.max(...used) : 0) + 1;
  return `${prefix}${String(next).padStart(4, "0")}`;
};
export const nextOrderNo = (orders, dateStr) => nextSequentialNo(orders, dateStr, "ORD", (o) => o.orderNo);

// Every product needs a human-readable ID a shop owner can actually use on a label
// or in conversation — "WF-004", not a random string. Prefix comes from the category
// (built-ins get a fixed short code; a custom category is abbreviated from its
// initials), and the number is the next unused one for that prefix.
export const CATEGORY_PREFIXES = { "Wooden Frame": "WF", "Acrylic Frame": "AF", "LED Frame": "LF", "Gift Item": "GI" };
export const categoryPrefix = (category) => {
  if (CATEGORY_PREFIXES[category]) return CATEGORY_PREFIXES[category];
  const letters = (category || "").trim().split(/\s+/).map((w) => w[0]).join("").toUpperCase().slice(0, 3);
  return letters || "PR";
};
export const nextSku = (category, products) => {
  const prefix = categoryPrefix(category);
  const used = products
    .map((p) => (p.sku || "").toUpperCase())
    .filter((s) => s.startsWith(prefix + "-"))
    .map((s) => parseInt(s.slice(prefix.length + 1), 10))
    .filter((n) => !isNaN(n));
  const next = (used.length ? Math.max(...used) : 0) + 1;
  return `${prefix}-${String(next).padStart(3, "0")}`;
};
export const toLocalISODate = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
export const todayStr = () => toLocalISODate(new Date());

export const DATE_PRESETS = ["All time", "Today", "Yesterday", "This week", "Last week", "This month", "Last month", "This year", "Custom range"];
// Returns [startISO, endISO] inclusive, or null for "All time" / an incomplete custom range.
export const resolveDateRange = (preset, customStart, customEnd) => {
  const today = todayStr();
  const now = new Date();
  if (preset === "Today") return [today, today];
  if (preset === "Yesterday") {
    const y = new Date(now); y.setDate(now.getDate() - 1);
    const ys = toLocalISODate(y);
    return [ys, ys];
  }
  if (preset === "This week") {
    const s = new Date(now); s.setDate(now.getDate() - now.getDay());
    return [toLocalISODate(s), today];
  }
  if (preset === "Last week") {
    const e = new Date(now); e.setDate(now.getDate() - now.getDay() - 1);
    const s = new Date(e); s.setDate(e.getDate() - 6);
    return [toLocalISODate(s), toLocalISODate(e)];
  }
  if (preset === "This month") return [today.slice(0, 7) + "-01", today];
  if (preset === "Last month") {
    const s = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const e = new Date(now.getFullYear(), now.getMonth(), 0);
    return [toLocalISODate(s), toLocalISODate(e)];
  }
  if (preset === "This year") return [today.slice(0, 4) + "-01-01", today];
  if (preset === "Custom range") return customStart && customEnd ? [customStart, customEnd] : null;
  return null;
};
export const fmtMoney = (n) => "₹" + Math.round(Number(n) || 0).toLocaleString("en-IN");
export const fmtDate = (d) => {
  if (!d) return "—";
  const dt = new Date(d + "T00:00:00");
  if (isNaN(dt.getTime())) return "—";
  return dt.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
};
export const fmtShortDate = (d) => {
  if (!d) return "—";
  const dt = new Date(d + "T00:00:00");
  if (isNaN(dt.getTime())) return "—";
  return dt.toLocaleDateString("en-IN", { day: "2-digit", month: "short" });
};
export const num = (v) => (v === "" || v === null || v === undefined || isNaN(v) ? 0 : Number(v));
// HTML's min="0" on a number input is cosmetic only — it doesn't stop someone typing
// a leading "-". Every price, quantity, and amount gets clamped through this at the
// point it's actually saved, so a stray minus sign can't corrupt stock or profit math.
export const nonNeg = (v) => Math.max(0, num(v));
// A discount is always order-level (not per-item) — matches how small shops actually
// negotiate a price ("₹50 off the whole thing", not itemized). Clamped so a typo'd
// percentage or flat amount can never make the discount exceed the subtotal.
// A single source of truth for "what payments make up this order's advance" —
// returns the real payments array for a split order, or synthesizes an equivalent
// one-entry array from the legacy paymentMode/advance fields for every order that
// predates split payments (or never used it). Every consumer (dashboard collections,
// receipts, exports, the payment filter) reads through this instead of each having
// its own fallback logic that could drift out of sync with the others.
export const orderPayments = (o) => {
  if (o.payments && o.payments.length) return o.payments;
  return num(o.advance) > 0 ? [{ id: "legacy", mode: o.paymentMode || "Cash", amount: num(o.advance) }] : [];
};
export const orderDiscount = (o, subtotal) => {
  if (o.discountType === "percent") return Math.min(subtotal, (subtotal * nonNeg(o.discountValue)) / 100);
  if (o.discountType === "flat") return Math.min(subtotal, nonNeg(o.discountValue));
  return 0;
};
// Strips spaces/dashes/parens so "98765 43210" and "98765-43210" match the same
// customer instead of silently creating two records. Doesn't touch digits/leading +,
// so it won't mangle a number it doesn't fully understand.
export const normalizePhone = (s) => (s || "").toString().trim().replace(/[\s\-()]/g, "");
export const OTHER = "__other__";

// wa.me needs digits only, in international format. Most numbers entered here will
// be a plain 10-digit Indian mobile, so assume country code 91 unless one is already
// present — better to guess right for the common case than force the shop owner to
// re-type every number in a specific format.
export const waDigits = (phone) => {
  const d = (phone || "").replace(/\D/g, "");
  if (!d) return "";
  if (d.length === 10) return "91" + d;
  if (d.length === 11 && d.startsWith("0")) return "91" + d.slice(1);
  return d;
};
export const waLink = (phone, message) => `https://wa.me/${waDigits(phone)}${message ? "?text=" + encodeURIComponent(message) : ""}`;
export const telLink = (phone) => `tel:${(phone || "").replace(/[^\d+]/g, "")}`;

// Shrinks any picked image client-side before it's ever stored — a phone photo can be
// several MB; a logo thumbnail or a reference photo attached to an order line never
// needs to be. Shared by the shop-logo uploader and the per-item custom-photo uploader
// so that resize behavior (and any future fix to it) stays in one place.
export function resizeImageToDataUrl(file, maxDim, callback, mimeType = "image/jpeg", quality = 0.85) {
  if (!file) return;
  if (!file.type.startsWith("image/")) { callback(null, "Please choose an image file."); return; }
  const reader = new FileReader();
  reader.onload = (ev) => {
    const img = document.createElement("img");
    img.onload = () => {
      let { width, height } = img;
      if (width > height && width > maxDim) { height = Math.round((height * maxDim) / width); width = maxDim; }
      else if (height > maxDim) { width = Math.round((width * maxDim) / height); height = maxDim; }
      const canvas = document.createElement("canvas");
      canvas.width = width; canvas.height = height;
      canvas.getContext("2d").drawImage(img, 0, 0, width, height);
      callback(canvas.toDataURL(mimeType, quality), null);
    };
    img.onerror = () => callback(null, "Could not read that image — try a different file.");
    img.src = ev.target.result;
  };
  reader.onerror = () => callback(null, "Could not read that file.");
  reader.readAsDataURL(file);
}

export const orderWaMessage = (o, shopName) => {
  const name = o.customerName && o.customerName !== "Walk-in Customer" ? o.customerName : "there";
  const items = (o.items || []).map((it) => it.name).filter(Boolean).join(", ");
  let msg = `Hi ${name}, `;
  if (o.status === "Ready") msg += `your order ${o.orderNo}${items ? ` (${items})` : ""} is ready for pickup!`;
  else if (o.status === "Delivered") msg += `thank you for your order ${o.orderNo}!`;
  else if (o.status === "Cancelled") msg += `following up on your cancelled order ${o.orderNo}.`;
  else if (o.status === "Returned") msg += `confirming your return for order ${o.orderNo} has been processed${o.returnRefund > 0 ? ` — ${fmtMoney(o.returnRefund)} refunded` : ""}.`;
  else msg += `a quick update on your order ${o.orderNo}${items ? ` (${items})` : ""} — we're working on it.`;
  if (o.balance > 0 && o.status !== "Cancelled" && o.status !== "Returned") msg += ` Balance due: ${fmtMoney(o.balance)}.`;
  return msg + ` — ${shopName}`;
};
export const customerWaMessage = (c, shopName) => {
  let msg = `Hi ${c.name}, this is ${shopName}.`;
  if (c.outstanding > 0) msg += ` Friendly reminder — ${fmtMoney(c.outstanding)} is pending on your order(s).`;
  return msg;
};

export const DATA_COLUMNS = {
  "shop-products": "products",
  "shop-orders": "orders",
  "shop-customers": "customers",
  "shop-expenses": "expenses",
  "shop-settings": "settings",
};
export let activeUserId = "";
export function setActiveUserId(id) {
  activeUserId = id || "";
}

// Storage is normalised now (see shopRepo): each list lives in its own table, so a
// single product edit writes one small row instead of rewriting the whole shop.
export async function loadKey(key, fallback) {
  if (!activeUserId) return fallback;
  if (typeof navigator !== "undefined" && navigator.onLine === false) return fallback;
  try {
    return await shopRepo.loadKind(activeUserId, DATA_COLUMNS[key], fallback);
  } catch {
    // Offline or a dropped connection: work from what's already on screen rather
    // than refusing to add the record at all.
    return fallback;
  }
}
// A save that fails because the connection is gone is a completely different
// situation from one the server rejected: the first should be kept and retried,
// the second must be shown to the person so they can fix it.
export function isConnectionError(e) {
  if (typeof navigator !== "undefined" && navigator.onLine === false) return true;
  const msg = String(e?.message || "");
  return /failed to fetch|network|timeout|fetch failed|load failed/i.test(msg);
}

export async function saveKey(key, value) {
  if (!activeUserId) return false;
  const kind = DATA_COLUMNS[key];
  // With no connection the request doesn't fail fast — it just sits there, which
  // would leave the person staring at a form that never closes. Queue it straight
  // away instead so the app stays responsive.
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    shopQueue.enqueue(activeUserId, kind, value);
    return "queued";
  }
  try {
    await shopRepo.saveKind(activeUserId, kind, value);
    return true;
  } catch (e) {
    if (isConnectionError(e)) {
      shopQueue.enqueue(activeUserId, kind, value);
      return "queued";
    }
    return false;
  }
}

// For changes that touch several data types at once (loading sample data, clearing
// everything): one call so the writes go out in a single, consistent pass.
export async function saveMultipleKeys(payload) {
  if (!activeUserId) return false;
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    Object.entries(payload).forEach(([kind, value]) => shopQueue.enqueue(activeUserId, kind, value));
    return "queued";
  }
  try {
    await shopRepo.saveKinds(activeUserId, payload);
    return true;
  } catch (e) {
    if (isConnectionError(e)) {
      Object.entries(payload).forEach(([kind, value]) => shopQueue.enqueue(activeUserId, kind, value));
      return "queued";
    }
    return false;
  }
}

// Keyed by shop id (not just a fixed name) so a shared device — someone signed in as
// staff on a shop computer, say — never shows a different shop's cached data if the
// account signed in changes. Written whenever fresh data actually loads from the
// server; read only as a fallback when there's no connection to reach it at all.
export const CACHE_PREFIX = "shop-cache-";
export function cacheShopData(shopId, data) {
  try {
    window.localStorage.setItem(CACHE_PREFIX + shopId, JSON.stringify({ ...data, cachedAt: Date.now() }));
  } catch {
    // Storage full, disabled, or private browsing — caching is a nice-to-have and
    // never something the app should treat as a real failure.
  }
}
export function readCachedShopData(shopId) {
  try {
    const raw = window.localStorage.getItem(CACHE_PREFIX + shopId);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

// A tiny, separate brand cache lets the connection screen show the business identity
// before the larger shop snapshot has been read. It is scoped to the signed-in user
// so a shared device never flashes another shop's logo.
export const BRAND_CACHE_PREFIX = "shop-brand-for-";
export const LAST_BRAND_CACHE_KEY = "shop-brand-last";
export function cacheShopBrand(userId, settings) {
  if (!userId || !settings) return;
  try {
    const brand = JSON.stringify({
      shopName: settings.shopName || "Your business",
      logoDataUrl: settings.logoDataUrl || null,
    });
    window.localStorage.setItem(BRAND_CACHE_PREFIX + userId, brand);
    window.localStorage.setItem(LAST_BRAND_CACHE_KEY, brand);
  } catch {}
}
export function readCachedShopBrand(userId) {
  try {
    const raw = userId
      ? window.localStorage.getItem(BRAND_CACHE_PREFIX + userId)
      : window.localStorage.getItem(LAST_BRAND_CACHE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}
export function clearLastCachedShopBrand() {
  try { window.localStorage.removeItem(LAST_BRAND_CACHE_KEY); } catch {}
}

// Separate from the data cache above — this just remembers "which shop does my own
// login resolve to", so a returning visit can start loading real data immediately
// instead of waiting on two sequential round trips (checking for a pending invite,
// then checking membership) that matter for exactly one moment in a person's life —
// their very first sign-in — and are otherwise pure overhead on every single load.
export const SHOP_ID_CACHE_PREFIX = "shop-id-for-";
export function cachedShopIdFor(uid) {
  try { return window.localStorage.getItem(SHOP_ID_CACHE_PREFIX + uid) || null; } catch { return null; }
}
export function cacheShopIdFor(uid, shopId) {
  try { window.localStorage.setItem(SHOP_ID_CACHE_PREFIX + uid, shopId); } catch {}
}


/* ----------------------------- SMALL UI PIECES ----------------------------- */
export function Badge({ text, color, soft }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium whitespace-nowrap"
      style={{ color: color, backgroundColor: soft }}
    >
      {text}
    </span>
  );
}

export function CategoryTag({ category }) {
  const color = CATEGORY_COLORS[category] || T.inkFaint;
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium" style={{ color }}>
      <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: color }} />
      {category}
    </span>
  );
}

export function StatusBadge({ status, t }) {
  const color = STATUS_COLORS[status] || T.inkFaint;
  const Icon = STATUS_ICONS[status] || Clock;
  const label = t ? t(`status.${status}`, status) : status;
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold"
      style={{ color, backgroundColor: color + "1A" }}
    >
      <Icon size={12} strokeWidth={2.5} />
      {label}
    </span>
  );
}

export function IconBtn({ onClick, children, label, danger }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className="p-2 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-offset-1"
      style={{
        color: danger ? T.danger : T.inkSoft,
        ["--tw-ring-color"]: danger ? T.danger : T.teal,
      }}
      onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = danger ? T.dangerSoft : T.borderSoft)}
      onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
    >
      {children}
    </button>
  );
}

// Icon-only Call + WhatsApp links. Renders nothing if there's no phone — e.g. an
// anonymous walk-in sale — rather than showing dead buttons. Stops click propagation
// since this is almost always nested inside a clickable card row.
// Self-drawn badge (green circle + generic phone glyph) rather than a trace of
// Meta's trademarked logo — recognizable as "message on WhatsApp" without
// reproducing their specific mark.
// Generic chat-bubble glyph (not a trace of any brand's logo) in WhatsApp's
// green — reads as "message" through colour and context, not shape-copying.
export function WhatsAppGlyph({ size = 15 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <circle cx="12" cy="12" r="12" fill="#25D366" />
      <path
        fill="#FFFFFF"
        d="M7 10.5C7 8.01 9.24 6 12 6s5 2.01 5 4.5-2.24 4.5-5 4.5c-.62 0-1.21-.1-1.76-.29L7.8 16.2a.5.5 0 0 1-.74-.56l.53-1.87C7.22 12.87 7 11.72 7 10.5Z"
      />
      <circle cx="9.7" cy="10.5" r="0.9" fill="#25D366" />
      <circle cx="12" cy="10.5" r="0.9" fill="#25D366" />
      <circle cx="14.3" cy="10.5" r="0.9" fill="#25D366" />
    </svg>
  );
}

export const LANGUAGES = [
  { code: "en", label: "English", short: "EN" },
  { code: "hi", label: "हिन्दी", short: "हि" },
  { code: "te", label: "తెలుగు", short: "తె" },
];
export function LanguagePicker({ lang, setLang, compact }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const onDocClick = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);
  const current = LANGUAGES.find((l) => l.code === lang) || LANGUAGES[0];
  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label={`Language: ${current.label}`}
        title={`Language: ${current.label}`}
        className={compact ? "px-2.5 py-2 rounded-md flex items-center gap-1.5" : "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium w-full"}
        style={compact ? { color: T.teal, backgroundColor: T.tealSoft, border: `1px solid ${T.borderSoft}` } : { color: T.inkSoft }}
      >
        <Globe size={17} />
        {compact && <span className="text-xs font-bold">{current.short}</span>}
        {!compact && <span>Language</span>}
        {!compact && <span className="ml-auto text-xs" style={{ color: T.inkFaint }}>{current.label}</span>}
      </button>
      {open && (
        <div
          className="absolute z-20 mt-1 rounded-md border overflow-hidden shadow-lg"
          style={{ borderColor: T.borderSoft, backgroundColor: T.surface, minWidth: 140, right: compact ? 0 : "auto", left: compact ? "auto" : 0 }}
        >
          {LANGUAGES.map((l) => (
            <button
              key={l.code}
              onClick={() => { setLang(l.code); setOpen(false); }}
              className="w-full text-left px-3 py-2 text-sm whitespace-nowrap"
              style={{ color: l.code === lang ? T.teal : T.ink, backgroundColor: l.code === lang ? T.tealSoft : "transparent" }}
            >
              {l.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function ContactActions({ phone, message, size = 15 }) {
  if (!normalizePhone(phone)) return null;
  return (
    <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
      <a
        href={telLink(phone)}
        title="Call"
        aria-label="Call"
        className="p-2 rounded-md transition-colors"
        style={{ color: T.inkSoft }}
        onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = T.borderSoft)}
        onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
      >
        <Phone size={size} />
      </a>
      <a
        href={waLink(phone, message)}
        target="_blank"
        rel="noopener noreferrer"
        title="WhatsApp"
        aria-label="WhatsApp"
        className="p-1.5 rounded-md transition-opacity hover:opacity-80"
      >
        <WhatsAppGlyph size={size + 3} />
      </a>
    </div>
  );
}

// A searchable combobox for picking a product — with dozens of SKUs, a plain <select>
// forces scrolling through everything to find one. Used both for order line items and
// for filtering Orders by product.
export function SearchableProductSelect({ products, value, onChange, placeholder, allowCustom, allLabel }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const ref = useRef(null);
  const selected = products.find((p) => p.id === value);

  useEffect(() => {
    const onDocClick = (e) => { if (ref.current && !ref.current.contains(e.target)) { setOpen(false); setQuery(""); } };
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  const q = query.trim().toLowerCase();
  const filtered = !q ? products : products.filter((p) =>
    p.name.toLowerCase().includes(q) || (p.sku || "").toLowerCase().includes(q) || (p.category || "").toLowerCase().includes(q)
  );
  const label = selected
    ? `${selected.sku ? selected.sku + " — " : ""}${selected.name}`
    : (allLabel && !value ? allLabel : placeholder || "Select…");

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg text-sm border text-left"
        style={inputStyle}
      >
        <span className="truncate">{label}</span>
        <ChevronDown size={15} style={{ color: T.inkFaint, flexShrink: 0 }} />
      </button>
      {open && (
        <div className="absolute z-30 mt-1 w-full rounded-lg border shadow-xl overflow-hidden" style={{ backgroundColor: T.surface, borderColor: T.border }}>
          <div className="p-2 border-b" style={{ borderColor: T.borderSoft }}>
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: T.inkFaint }} />
              <TextInput autoFocus value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by name or SKU…" className="pl-8" />
            </div>
          </div>
          <div className="max-h-56 overflow-y-auto">
            {allLabel && (
              <button type="button" onClick={() => { onChange(""); setOpen(false); setQuery(""); }} className="w-full text-left px-3 py-2 text-sm border-b" style={{ color: T.ink, borderColor: T.borderSoft, backgroundColor: !value ? T.tealSoft : "transparent" }}>
                {allLabel}
              </button>
            )}
            {allowCustom && (
              <button type="button" onClick={() => { onChange(""); setOpen(false); setQuery(""); }} className="w-full text-left px-3 py-2 text-sm border-b" style={{ color: T.inkSoft, borderColor: T.borderSoft }}>
                Custom / one-off item
              </button>
            )}
            {filtered.length === 0 ? (
              <p className="px-3 py-4 text-xs text-center" style={{ color: T.inkFaint }}>No products match "{query}"</p>
            ) : (
              filtered.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => { onChange(p.id); setOpen(false); setQuery(""); }}
                  className="w-full flex items-center justify-between gap-2 px-3 py-2 text-sm text-left"
                  style={{ color: T.ink, backgroundColor: value === p.id ? T.tealSoft : "transparent" }}
                >
                  <span className="truncate">{p.sku ? `${p.sku} — ` : ""}{p.name}</span>
                  <CategoryTag category={p.category} />
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export function PrimaryButton({ onClick, children, full, type = "button" }) {
  return (
    <button
      type={type}
      onClick={onClick}
      className={`inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-md text-sm font-semibold transition-transform active:scale-[0.98] focus:outline-none focus:ring-2 focus:ring-offset-2 ${full ? "w-full" : ""}`}
      style={{ backgroundColor: T.teal, color: T.bg, ["--tw-ring-color"]: T.teal }}
    >
      {children}
    </button>
  );
}

export function GhostButton({ onClick, children, full }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-md text-sm font-semibold transition-colors border focus:outline-none focus:ring-2 focus:ring-offset-2 ${full ? "w-full" : ""}`}
      style={{ color: T.ink, borderColor: T.border, backgroundColor: T.surface, ["--tw-ring-color"]: T.teal }}
    >
      {children}
    </button>
  );
}

export function Field({ label, children, required }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-xs font-semibold" style={{ color: T.inkSoft }}>
        {label} {required && <span style={{ color: T.danger }}>*</span>}
      </span>
      {children}
    </label>
  );
}

export const inputCls =
  "w-full px-3 py-2.5 rounded-md text-sm border focus:outline-none focus:ring-2 focus:ring-offset-0 transition-colors";
export const inputStyle = { borderColor: T.border, color: T.ink, backgroundColor: T.surface, ["--tw-ring-color"]: T.teal };

export function TextInput(props) {
  return <input {...props} className={inputCls + " " + (props.className || "")} style={{ ...inputStyle, ...(props.style || {}) }} />;
}
export function SelectInput({ children, ...props }) {
  return (
    <select {...props} className={inputCls + " " + (props.className || "")} style={{ ...inputStyle, ...(props.style || {}) }}>
      {children}
    </select>
  );
}
export function TextArea(props) {
  return <textarea {...props} className={inputCls} style={inputStyle} />;
}

// A <select> that adds an "Other (type your own)" option. Picking it reveals a text
// input so the value isn't locked to a fixed list — a shop's categories, payment
// methods, etc. grow over time and shouldn't require an app update to add one.
export function OtherableSelect({ options, value, onChange, placeholder }) {
  const isCustom = value && !options.includes(value);
  const [showOther, setShowOther] = useState(isCustom);
  return (
    <div className="flex flex-col gap-1.5">
      <SelectInput
        value={showOther ? OTHER : value}
        onChange={(e) => {
          if (e.target.value === OTHER) { setShowOther(true); onChange(""); }
          else { setShowOther(false); onChange(e.target.value); }
        }}
      >
        <option value="" disabled>Select…</option>
        {options.map((c) => <option key={c} value={c}>{c}</option>)}
        <option value={OTHER}>Other (type your own)</option>
      </SelectInput>
      {showOther && (
        <TextInput autoFocus placeholder={placeholder || "Type here"} value={value} onChange={(e) => onChange(e.target.value)} />
      )}
    </div>
  );
}

// Preset dropdown (Today / This week / Last month / ...) that reveals two date
// inputs for "Custom range". Shared by Orders and Finance so both filter the same way.
export const DATE_PRESET_KEYS = {
  "All time": ["finance.allTime", "All time"],
  "Today": ["dashboard.today", "Today"],
  "Yesterday": ["date.yesterday", "Yesterday"],
  "This week": ["date.thisWeek", "This week"],
  "Last week": ["date.lastWeek", "Last week"],
  "This month": ["date.thisMonth", "This month"],
  "Last month": ["date.lastMonth", "Last month"],
  "This year": ["date.thisYear", "This year"],
  "Custom range": ["date.customRange", "Custom range"],
};
export function DateFilterControl({ preset, setPreset, start, setStart, end, setEnd, widthClass, t }) {
  return (
    <div className="flex gap-2 flex-wrap">
      <SelectInput value={preset} onChange={(e) => setPreset(e.target.value)} className={widthClass || "flex-1 sm:flex-none sm:w-36"}>
        {DATE_PRESETS.map((p) => {
          const [key, fallback] = DATE_PRESET_KEYS[p];
          return <option key={p} value={p}>{t ? t(key, fallback) : fallback}</option>;
        })}
      </SelectInput>
      {preset === "Custom range" && (
        <>
          <TextInput type="date" value={start} onChange={(e) => setStart(e.target.value)} className="sm:w-36" />
          <TextInput type="date" value={end} onChange={(e) => setEnd(e.target.value)} className="sm:w-36" />
        </>
      )}
    </div>
  );
}

export function Modal({ title, onClose, children, wide, settingsLayout = false }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div
        className={`relative w-full ${settingsLayout ? "h-dvh max-h-none sm:h-[min(760px,90vh)] sm:max-w-5xl" : wide ? "sm:max-w-2xl" : "sm:max-w-md"} ${settingsLayout ? "rounded-none" : "rounded-t-lg"} sm:rounded-lg shadow-xl max-h-[90vh] flex flex-col animate-[slideUp_0.2s_ease-out]`}
        style={{ backgroundColor: T.surface, border: `1px solid ${T.borderSoft}` }}
      >
        <div className={`flex shrink-0 items-center justify-between border-b ${settingsLayout ? "px-5 py-4 sm:px-6" : "px-5 py-4"}`} style={{ borderColor: T.borderSoft }}>
          <h3 className="text-base font-semibold" style={{ color: T.ink, fontFamily: FONT_DISPLAY }}>
            {title}
          </h3>
          <IconBtn onClick={onClose} label="Close">
            <X size={18} />
          </IconBtn>
        </div>
        <div className={settingsLayout ? "min-h-0 flex-1 overflow-hidden" : "px-5 py-4 overflow-y-auto"}>{children}</div>
      </div>
    </div>
  );
}

export function ConfirmDialog({ text, onCancel, onConfirm, t }) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/40" onClick={onCancel} />
      <div className="relative w-full max-w-sm rounded-lg shadow-xl p-5" style={{ backgroundColor: T.surface, border: `1px solid ${T.borderSoft}` }}>
        <div className="flex items-start gap-3 mb-4">
          <div className="p-2 rounded-full shrink-0" style={{ backgroundColor: T.dangerSoft }}>
            <AlertTriangle size={18} style={{ color: T.danger }} />
          </div>
          <p className="text-sm pt-1.5" style={{ color: T.ink }}>{text}</p>
        </div>
        <div className="flex gap-2 justify-end">
          <GhostButton onClick={onCancel}>{t ? t("action.cancel", "Cancel") : "Cancel"}</GhostButton>
          <button
            onClick={onConfirm}
            className="px-4 py-2.5 rounded-md text-sm font-semibold"
            style={{ backgroundColor: T.danger, color: T.bg }}
          >
            {t ? t("action.delete", "Delete") : "Delete"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* Long lists are drawn a page at a time. A shop with thousands of orders would
   otherwise put every single row on screen at once, which is what makes the
   list feel slow to scroll and slow to filter. */
export const LIST_PAGE = 50;

export function usePagedList(list, resetKey) {
  const [limit, setLimit] = useState(LIST_PAGE);
  useEffect(() => { setLimit(LIST_PAGE); }, [resetKey]);
  const visible = list.length > limit ? list.slice(0, limit) : list;
  return { visible, hidden: list.length - visible.length, total: list.length, showMore: () => setLimit((n) => n + LIST_PAGE) };
}

export function ShowMore({ page, t }) {
  if (!page.hidden) return null;
  return (
    <button
      onClick={page.showMore}
      className="w-full py-3 text-sm font-medium rounded-lg border transition-colors"
      style={{ borderColor: T.borderSoft, color: T.teal, backgroundColor: T.surface }}
    >
      {t("common.showMore", "Show {n} more", { n: Math.min(page.hidden, LIST_PAGE) })}
      {" · "}
      {t("common.ofTotal", "{shown} of {total} shown", { shown: page.total - page.hidden, total: page.total })}
    </button>
  );
}

export function EmptyState({ icon: Icon, title, subtitle, actionLabel, onAction, secondaryLabel, onSecondary }) {
  return (
    <div className="flex flex-col items-center text-center py-14 px-6">
      <div className="p-4 rounded-full mb-4" style={{ backgroundColor: T.brassSoft }}>
        <Icon size={26} style={{ color: T.brass }} />
      </div>
      <p className="font-semibold mb-1" style={{ color: T.ink }}>{title}</p>
      <p className="text-sm mb-5 max-w-xs" style={{ color: T.inkSoft }}>{subtitle}</p>
      {actionLabel && (
        <PrimaryButton onClick={onAction}>
          <Plus size={16} /> {actionLabel}
        </PrimaryButton>
      )}
      {secondaryLabel && (
        <button onClick={onSecondary} className="text-sm font-medium mt-3" style={{ color: T.teal }}>
          {secondaryLabel}
        </button>
      )}
    </div>
  );
}

export function StatCard({ label, value, accent, sub }) {
  return (
    <div
      className="rounded-lg p-4 border-l-4"
      style={{ borderColor: T.borderSoft, borderLeftColor: accent, backgroundColor: T.surface }}
    >
      <p className="text-[11px] font-semibold mb-1.5 uppercase" style={{ color: T.inkSoft, letterSpacing: "0.08em" }}>{label}</p>
      <p className="text-2xl font-bold tabular-nums" style={{ color: T.ink, fontFamily: FONT_MONO }}>
        {value}
      </p>
      {sub && <p className="text-xs mt-1" style={{ color: T.inkFaint }}>{sub}</p>}
    </div>
  );
}

export function MiniStat({ label, value, icon: Icon }) {
  return (
    <div className="flex items-center gap-3 rounded-md px-4 py-3 border" style={{ borderColor: T.borderSoft, backgroundColor: T.surface }}>
      <div className="p-2 rounded-md" style={{ backgroundColor: T.tealSoft }}>
        <Icon size={16} style={{ color: T.teal }} />
      </div>
      <div>
        <p className="text-lg font-bold tabular-nums" style={{ color: T.ink, fontFamily: FONT_MONO }}>{value}</p>
        <p className="text-[11px] uppercase" style={{ color: T.inkSoft, letterSpacing: "0.06em" }}>{label}</p>
      </div>
    </div>
  );
}

// Plain-English age of the oldest waiting offline change ("today", "yesterday", "3 days ago").
export function pendingAge(since) {
  if (!since) return "offline";
  const days = Math.floor((Date.now() - since) / 86400000);
  if (days <= 0) return "today";
  if (days === 1) return "yesterday";
  return `${days} days ago`;
}


