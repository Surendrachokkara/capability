import {
  useCallback,
  useEffect,
  useState,
  type ChangeEvent,
  type FormEvent,
  type ReactNode,
} from "react";
import { Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Field, GhostButton, PrimaryButton, T, TextInput } from "@/components/shop/shopShared";

type InviteRow = {
  id: string;
  email: string;
  note: string | null;
  invited_at: string;
  blocked: boolean;
  opened_at: string | null;
  shop_name: string | null;
};

type Report = {
  invited: number;
  opened: number;
  waiting: number;
  blocked: number;
  rows: InviteRow[];
};

const EMPTY_REPORT: Report = { invited: 0, opened: 0, waiting: 0, blocked: 0, rows: [] };
const EMAIL_OK = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function Shell({ children }: { children: ReactNode }) {
  return (
    <main
      className="shop-theme min-h-screen px-5 py-10"
      data-shop-theme="dark"
      style={{ backgroundColor: T.bg, color: T.ink }}
    >
      <div className="mx-auto w-full max-w-xl">{children}</div>
    </main>
  );
}

function statusLabel(row: InviteRow) {
  if (row.blocked) return "Blocked";
  if (row.opened_at) return "Shop open";
  return "Waiting";
}

export function AdminPage() {
  const [ready, setReady] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [signedIn, setSignedIn] = useState(false);
  const [isSeller, setIsSeller] = useState(false);
  const [report, setReport] = useState<Report>(EMPTY_REPORT);
  const [buyerEmail, setBuyerEmail] = useState("");
  const [buyerNote, setBuyerNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [messageOk, setMessageOk] = useState(false);

  const loadReport = useCallback(async () => {
    const { data, error } = await supabase.rpc("platform_admin_report");
    if (error) {
      setMessageOk(false);
      setMessage(error.message);
      return;
    }
    const next = (data ?? EMPTY_REPORT) as Report;
    setReport({
      invited: next.invited ?? 0,
      opened: next.opened ?? 0,
      waiting: next.waiting ?? 0,
      blocked: next.blocked ?? 0,
      rows: Array.isArray(next.rows) ? next.rows : [],
    });
  }, []);

  const refreshRole = useCallback(async () => {
    const { data: sessionData } = await supabase.auth.getSession();
    const sessionUser = sessionData.session?.user;
    const sessionEmail = sessionUser?.email?.trim().toLowerCase() ?? "";
    setSignedIn(Boolean(sessionUser));
    setUserEmail(sessionEmail);
    if (!sessionUser) {
      setIsSeller(false);
      setReport(EMPTY_REPORT);
      setReady(true);
      return;
    }
    if (!sessionEmail) {
      setIsSeller(false);
      setMessageOk(false);
      setMessage("Sign in with an email account.");
      setReady(true);
      return;
    }
    const { data: admin, error: adminError } = await supabase.rpc("is_platform_admin");
    if (adminError) {
      setMessageOk(false);
      setMessage(
        "Invite shops is not ready yet. Deploy the latest update, then open this page again.",
      );
      setIsSeller(false);
      setReady(true);
      return;
    }
    const sellerNow = admin === true;
    setIsSeller(sellerNow);
    if (sellerNow) {
      await supabase.rpc("claim_platform_admin");
      await loadReport();
    } else {
      setReport(EMPTY_REPORT);
    }
    setReady(true);
  }, [loadReport]);

  useEffect(() => {
    void refreshRole();
    const { data: listener } = supabase.auth.onAuthStateChange(() => {
      setTimeout(() => {
        void refreshRole();
      }, 0);
    });
    return () => listener.subscription.unsubscribe();
  }, [refreshRole]);

  const signIn = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) {
      setMessageOk(false);
      setMessage(error.message);
    }
  };

  const addInvite = async (event: FormEvent) => {
    event.preventDefault();
    const next = buyerEmail.trim().toLowerCase();
    if (!EMAIL_OK.test(next)) {
      setMessageOk(false);
      setMessage("Enter a valid email.");
      return;
    }
    setBusy(true);
    setMessage("");
    const { error } = await supabase.from("platform_invites").insert({
      email: next,
      note: buyerNote.trim() || null,
    });
    setBusy(false);
    if (error) {
      setMessageOk(false);
      setMessage(error.code === "23505" ? "That email is already invited." : error.message);
      return;
    }
    setBuyerEmail("");
    setBuyerNote("");
    setMessageOk(true);
    setMessage("Email added. Tell them to create an account with that same email.");
    await loadReport();
  };

  const removeInvite = async (invite: InviteRow) => {
    if (
      !window.confirm(
        `Remove ${invite.email}? They cannot open a new shop with it. An account that already exists can still sign in.`,
      )
    ) {
      return;
    }
    setMessage("");
    if (invite.blocked) {
      const { error: allowError } = await supabase.rpc("set_platform_invite_blocked", {
        invite_id: invite.id,
        is_blocked: false,
      });
      if (allowError) {
        setMessageOk(false);
        setMessage(allowError.message);
        return;
      }
    }
    const { error } = await supabase.from("platform_invites").delete().eq("id", invite.id);
    if (error) {
      setMessageOk(false);
      setMessage(error.message);
      return;
    }
    await loadReport();
  };

  const setBlocked = async (invite: InviteRow, blocked: boolean) => {
    const question = blocked
      ? `Block ${invite.email}? They cannot open the shop until you allow it.`
      : `Allow ${invite.email} to open the shop again?`;
    if (!window.confirm(question)) return;
    setMessage("");
    const { error } = await supabase.rpc("set_platform_invite_blocked", {
      invite_id: invite.id,
      is_blocked: blocked,
    });
    if (error) {
      setMessageOk(false);
      setMessage(error.message);
      return;
    }
    setMessageOk(true);
    setMessage(blocked ? "Email blocked." : "Email allowed.");
    await loadReport();
  };

  const stats = [
    { label: "Invited", value: report.invited },
    { label: "Shop open", value: report.opened },
    { label: "Waiting", value: report.waiting },
    { label: "Blocked", value: report.blocked },
  ];

  if (!ready) {
    return (
      <Shell>
        <p className="text-sm" style={{ color: T.inkSoft }}>
          Loading…
        </p>
      </Shell>
    );
  }

  return (
    <Shell>
      <p className="text-xs font-semibold tracking-wide" style={{ color: T.brass }}>
        Frame & Gifts
      </p>
      <h1
        className="mt-2 text-2xl font-semibold"
        style={{ fontFamily: "'Space Grotesk', sans-serif" }}
      >
        Invite shops
      </h1>
      <p className="mt-2 text-sm leading-6" style={{ color: T.inkSoft }}>
        Only the seller sees this page. Add a buyer email, then tell them to create an account with
        that same address. This page does not send email.
      </p>

      {!signedIn ? (
        <form onSubmit={signIn} className="mt-6 flex flex-col gap-3.5">
          <Field label="Email" required>
            <TextInput
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(event: ChangeEvent<HTMLInputElement>) => setEmail(event.target.value)}
            />
          </Field>
          <Field label="Password" required>
            <TextInput
              type="password"
              required
              minLength={6}
              autoComplete="current-password"
              value={password}
              onChange={(event: ChangeEvent<HTMLInputElement>) => setPassword(event.target.value)}
            />
          </Field>
          {message && (
            <p className="text-xs leading-5" style={{ color: T.danger }}>
              {message}
            </p>
          )}
          <PrimaryButton type="submit" full onClick={() => undefined}>
            {busy ? "Please wait…" : "Sign in"}
          </PrimaryButton>
          <Link to="/app" className="text-center text-xs font-medium" style={{ color: T.brass }}>
            Back to the shop
          </Link>
        </form>
      ) : (
        <div className="mt-6 flex flex-col gap-4">
          <div className="flex items-center justify-between gap-3 text-sm">
            <span style={{ color: T.inkSoft }}>{userEmail}</span>
            <button
              type="button"
              className="text-xs font-medium"
              style={{ color: T.brass }}
              onClick={() => void supabase.auth.signOut()}
            >
              Sign out
            </button>
          </div>

          {message && (
            <p className="text-xs leading-5" style={{ color: messageOk ? T.success : T.danger }}>
              {message}
            </p>
          )}

          {!isSeller && (
            <p className="text-sm leading-6" style={{ color: T.inkSoft }}>
              Invite shops is only for the seller. This account cannot add emails or see shop
              status.
            </p>
          )}

          {isSeller && (
            <>
              <div className="grid grid-cols-2 gap-2">
                {stats.map((stat) => (
                  <div
                    key={stat.label}
                    className="rounded-md border px-3 py-3"
                    style={{ borderColor: T.border, backgroundColor: T.surface }}
                  >
                    <p className="text-xs" style={{ color: T.inkFaint }}>
                      {stat.label}
                    </p>
                    <p className="mt-1 text-xl font-semibold">{stat.value}</p>
                  </div>
                ))}
              </div>

              <form onSubmit={addInvite} className="flex flex-col gap-3.5">
                <Field label="Buyer email" required>
                  <TextInput
                    type="email"
                    required
                    autoComplete="off"
                    value={buyerEmail}
                    onChange={(event: ChangeEvent<HTMLInputElement>) =>
                      setBuyerEmail(event.target.value)
                    }
                    placeholder="shop@example.com"
                  />
                </Field>
                <Field label="Name" required={false}>
                  <TextInput
                    value={buyerNote}
                    onChange={(event: ChangeEvent<HTMLInputElement>) =>
                      setBuyerNote(event.target.value)
                    }
                    placeholder="Optional"
                  />
                </Field>
                <PrimaryButton type="submit" full onClick={() => undefined}>
                  {busy ? "Please wait…" : "Add email"}
                </PrimaryButton>
              </form>

              {report.rows.length === 0 ? (
                <p className="text-sm" style={{ color: T.inkFaint }}>
                  No emails yet.
                </p>
              ) : (
                <ul className="flex flex-col gap-2">
                  {report.rows.map((invite) => (
                    <li
                      key={invite.id}
                      className="rounded-md border px-3 py-3"
                      style={{ borderColor: T.border, backgroundColor: T.surface }}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium">{invite.email}</p>
                          {invite.note && (
                            <p className="truncate text-xs" style={{ color: T.inkFaint }}>
                              {invite.note}
                            </p>
                          )}
                          <p className="mt-1 text-xs" style={{ color: T.inkSoft }}>
                            {statusLabel(invite)}
                            {invite.shop_name ? ` · ${invite.shop_name}` : ""}
                          </p>
                        </div>
                        <div className="flex shrink-0 flex-col gap-2">
                          <GhostButton
                            full={false}
                            onClick={() => void setBlocked(invite, !invite.blocked)}
                          >
                            {invite.blocked ? "Allow" : "Block"}
                          </GhostButton>
                          <GhostButton full={false} onClick={() => void removeInvite(invite)}>
                            Remove
                          </GhostButton>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </>
          )}

          <Link to="/app" className="text-sm font-medium" style={{ color: T.brass }}>
            Back to the shop
          </Link>
        </div>
      )}
    </Shell>
  );
}
