import { Link } from "@tanstack/react-router";
import { SiteChrome } from "./SiteChrome";

const STEPS = [
  { time: "9:10", title: "Check ready orders" },
  { time: "11:40", title: "Take the order. Note what is paid." },
  { time: "2:05", title: "Add stock if something is low" },
  { time: "4:20", title: "Mark ready. Send WhatsApp." },
  { time: "8:15", title: "Count cash, UPI, and card" },
];

export function DayPage() {
  return (
    <SiteChrome>
      <div className="fg-wrap">
        <header className="fg-day-hero">
          <p className="fg-kicker">A day in the shop</p>
          <h1>Do this each day.</h1>
        </header>
        <ol className="fg-steps">
          {STEPS.map((step) => (
            <li key={step.time}>
              <b>{step.time}</b>
              <strong>{step.title}</strong>
            </li>
          ))}
        </ol>
        <div className="fg-hero-actions">
          <Link to="/app" className="fg-btn fg-btn-primary">
            Open the shop
          </Link>
        </div>
        <p className="fg-note">New shops are by invite only. The seller adds your email first.</p>
      </div>
    </SiteChrome>
  );
}
