import { useEffect, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import "./site.css";

const LINKS = [
  { to: "/product", label: "How it works" },
  { to: "/the-day", label: "A day in the shop" },
] as const;

function Mark() {
  return <span className="fg-mark" aria-hidden="true" />;
}

function AuthHandoff() {
  useEffect(() => {
    const hash = window.location.hash;
    const search = window.location.search;
    const query = new URLSearchParams(search);
    const fragment = new URLSearchParams(hash.startsWith("#") ? hash.slice(1) : hash);
    const returningFromAuth =
      fragment.has("access_token") ||
      fragment.has("error") ||
      fragment.has("error_description") ||
      fragment.get("type") === "recovery" ||
      query.has("code") ||
      query.get("type") === "recovery";
    if (returningFromAuth) {
      window.location.replace(`/app${search}${hash}`);
    }
  }, []);
  return null;
}

export function SiteChrome({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <div className="fg shop-theme" data-shop-theme="dark">
      <AuthHandoff />
      <a className="fg-skip" href="#content">
        Skip to content
      </a>
      <header className="fg-nav">
        <Link to="/" className="fg-brand" aria-label="Frame & Gifts, home">
          <Mark />
          <span className="fg-brand-name">
            Frame & Gifts
            <span>For your shop</span>
          </span>
        </Link>
        <nav className="fg-nav-links" aria-label="Primary">
          {LINKS.map((link) => (
            <Link key={link.to} to={link.to} data-active={pathname === link.to}>
              {link.label}
            </Link>
          ))}
        </nav>
        <div className="fg-nav-actions">
          <Link to="/app" className="fg-btn fg-btn-primary">
            Sign in
          </Link>
        </div>
      </header>

      <main id="content">{children}</main>
      <footer className="fg-footer fg-wrap">
        <div>
          <strong>Frame & Gifts</strong>
        </div>
        <div>
          <strong>Pages</strong>
          <ul>
            <li>
              <Link to="/product">How it works</Link>
            </li>
            <li>
              <Link to="/the-day">A day in the shop</Link>
            </li>
            <li>
              <Link to="/app">Sign in</Link>
            </li>
          </ul>
        </div>
      </footer>
    </div>
  );
}

export function Frame({ children }: { children: ReactNode }) {
  return (
    <div className="fg-frame">
      <div className="fg-frame-corners" aria-hidden="true">
        <span />
        <span />
        <span />
        <span />
      </div>
      {children}
    </div>
  );
}
