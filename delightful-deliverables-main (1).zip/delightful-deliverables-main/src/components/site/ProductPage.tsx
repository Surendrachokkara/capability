import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { SiteChrome } from "./SiteChrome";

const STATUSES = ["Pending", "In Progress", "Ready", "Delivered", "Cancelled", "Returned"] as const;
type Status = (typeof STATUSES)[number];

function whatsAppLine(status: Status) {
  const orderNo = "ORD-2627-0018";
  const items = "Teak photo frame 8×10";
  let message = "Hi there, ";
  if (status === "Ready") message += `your order ${orderNo} (${items}) is ready for pickup!`;
  else if (status === "Delivered") message += `thank you for your order ${orderNo}!`;
  else if (status === "Cancelled") message += `following up on your cancelled order ${orderNo}.`;
  else if (status === "Returned")
    message += `confirming your return for order ${orderNo} has been processed — ₹800 refunded.`;
  else message += `a quick update on your order ${orderNo} (${items}) — we're working on it.`;
  if (status !== "Cancelled" && status !== "Returned") message += " Balance due: ₹1,400.";
  return `${message} — Sample shop`;
}

export function ProductPage() {
  const [status, setStatus] = useState<Status>("Ready");

  return (
    <SiteChrome>
      <div className="fg-wrap">
        <header className="fg-product-hero">
          <p className="fg-kicker">How it works</p>
          <h1>Three steps. Then you are in.</h1>
        </header>

        <ol className="fg-steps">
          <li>
            <b>1</b>
            <div>
              <strong>Add stock</strong>
              <span>Wooden, acrylic, LED, gifts.</span>
            </div>
          </li>
          <li>
            <b>2</b>
            <div>
              <strong>Save the order</strong>
              <span>Mark where it is. Take part payment if needed.</span>
            </div>
          </li>
          <li>
            <b>3</b>
            <div>
              <strong>Send WhatsApp</strong>
              <span>Tap a status. The message is ready.</span>
            </div>
          </li>
        </ol>

        <div
          className="fg-status-row"
          role="tablist"
          aria-label="Order status"
          style={{ marginTop: "1.25rem" }}
        >
          {STATUSES.map((item) => (
            <button
              key={item}
              type="button"
              role="tab"
              aria-selected={status === item}
              data-on={status === item}
              onClick={() => setStatus(item)}
            >
              {item}
            </button>
          ))}
        </div>

        <div className="fg-receipt" aria-live="polite" style={{ marginTop: "0.8rem" }}>
          <header>
            <div>
              <strong>Sample shop</strong>
              <span>ORD-2627-0018</span>
            </div>
            <span>{status}</span>
          </header>
          <ul>
            <li>
              <span>Teak photo frame 8×10</span>
              <span>₹2,200</span>
            </li>
            <li>
              <span>Paid · UPI</span>
              <span>₹800</span>
            </li>
          </ul>
          <footer>
            <span>Still to pay</span>
            <span>{status === "Cancelled" || status === "Returned" ? "₹0" : "₹1,400"}</span>
          </footer>
        </div>
        <div className="fg-wa">
          <small>WhatsApp</small>
          {whatsAppLine(status)}
        </div>

        <div className="fg-hero-actions">
          <Link to="/app" className="fg-btn fg-btn-primary">
            Open the shop
          </Link>
        </div>
        <p className="fg-note">New shops are by invite only. The seller adds your email first.</p>
      </div>
    </SiteChrome>
  );
}
