import { Link } from "@tanstack/react-router";
import { Frame, SiteChrome } from "./SiteChrome";

const STEPS = [
  { n: "1", title: "Add your items", detail: "Frames and gifts." },
  { n: "2", title: "Save the order", detail: "Cash, UPI, or card." },
  { n: "3", title: "See who still has to pay", detail: "Send WhatsApp from the order." },
];

export function HomePage() {
  return (
    <SiteChrome>
      <div className="fg-wrap">
        <section className="fg-hero">
          <div>
            <p className="fg-kicker">Frame and gift shops</p>
            <h1>Run your shop in one place.</h1>
            <ol className="fg-steps">
              {STEPS.map((step) => (
                <li key={step.n}>
                  <b>{step.n}</b>
                  <div>
                    <strong>{step.title}</strong>
                    <span>{step.detail}</span>
                  </div>
                </li>
              ))}
            </ol>
            <div className="fg-hero-actions">
              <Link to="/app" className="fg-btn fg-btn-primary">
                Open the shop
              </Link>
            </div>
            <p className="fg-note">
              New shops are by invite only. The seller adds your email first.
            </p>
          </div>
          <Frame>
            <div className="fg-frame-top">
              <p>Example</p>
              <p>Not your shop</p>
            </div>
            <div className="fg-stats">
              <div className="fg-stat">
                <span>Today’s sales</span>
                <strong>₹18,420</strong>
              </div>
              <div className="fg-stat">
                <span>Still to pay</span>
                <strong>
                  <em>₹36,900</em>
                </strong>
              </div>
              <div className="fg-stat">
                <span>Ready</span>
                <strong>6</strong>
              </div>
              <div className="fg-stat">
                <span>Low stock</span>
                <strong>3</strong>
              </div>
            </div>
            <article className="fg-order">
              <div className="fg-order-head">
                <span
                  className="fg-mono"
                  style={{ fontSize: "0.72rem", color: "var(--night-faint)" }}
                >
                  ORD-2627-0018
                </span>
                <span className="fg-pill">In progress</span>
              </div>
              <h2>Teak photo frame, 8×10</h2>
              <p>Paid on UPI</p>
              <div className="fg-payline">
                <span>Paid ₹800</span>
                <span>Due ₹1,400</span>
              </div>
            </article>
          </Frame>
        </section>
      </div>
    </SiteChrome>
  );
}
