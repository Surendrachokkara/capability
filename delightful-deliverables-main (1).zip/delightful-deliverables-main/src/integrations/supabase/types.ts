export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      customers: {
        Row: {
          address: string | null
          created_at: string
          id: string
          name: string
          notes: string | null
          phone: string
          shop_owner_id: string
          updated_at: string
        }
        Insert: {
          address?: string | null
          created_at?: string
          id: string
          name: string
          notes?: string | null
          phone: string
          shop_owner_id: string
          updated_at?: string
        }
        Update: {
          address?: string | null
          created_at?: string
          id?: string
          name?: string
          notes?: string | null
          phone?: string
          shop_owner_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "customers_shop_owner_id_fkey"
            columns: ["shop_owner_id"]
            isOneToOne: false
            referencedRelation: "shop_data"
            referencedColumns: ["user_id"]
          },
        ]
      }
      expenses: {
        Row: {
          amount: number
          category: string
          created_at: string
          description: string | null
          id: string
          payment_mode: string
          shop_owner_id: string
          spent_at: string
          supplier_id: string | null
        }
        Insert: {
          amount?: number
          category: string
          created_at?: string
          description?: string | null
          id: string
          payment_mode?: string
          shop_owner_id: string
          spent_at: string
          supplier_id?: string | null
        }
        Update: {
          amount?: number
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          payment_mode?: string
          shop_owner_id?: string
          spent_at?: string
          supplier_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "expenses_shop_owner_id_fkey"
            columns: ["shop_owner_id"]
            isOneToOne: false
            referencedRelation: "shop_data"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "expenses_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      order_counters: {
        Row: {
          last_no: number
          series: string
          shop_owner_id: string
          updated_at: string
        }
        Insert: {
          last_no?: number
          series: string
          shop_owner_id: string
          updated_at?: string
        }
        Update: {
          last_no?: number
          series?: string
          shop_owner_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_counters_shop_owner_id_fkey"
            columns: ["shop_owner_id"]
            isOneToOne: false
            referencedRelation: "shop_data"
            referencedColumns: ["user_id"]
          },
        ]
      }
      order_items: {
        Row: {
          category: string | null
          created_at: string
          custom_photo: boolean
          custom_photo_data_url: string | null
          custom_photo_note: string | null
          id: string
          name: string
          order_id: string
          product_id: string | null
          qty: number
          sku: string | null
          unit_cost: number | null
          unit_price: number
        }
        Insert: {
          category?: string | null
          created_at?: string
          custom_photo?: boolean
          custom_photo_data_url?: string | null
          custom_photo_note?: string | null
          id?: string
          name: string
          order_id: string
          product_id?: string | null
          qty?: number
          sku?: string | null
          unit_cost?: number | null
          unit_price?: number
        }
        Update: {
          category?: string | null
          created_at?: string
          custom_photo?: boolean
          custom_photo_data_url?: string | null
          custom_photo_note?: string | null
          id?: string
          name?: string
          order_id?: string
          product_id?: string | null
          qty?: number
          sku?: string | null
          unit_cost?: number | null
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      order_payments: {
        Row: {
          amount: number
          id: string
          mode: string
          order_id: string
          paid_at: string
        }
        Insert: {
          amount?: number
          id?: string
          mode: string
          order_id: string
          paid_at?: string
        }
        Update: {
          amount?: number
          id?: string
          mode?: string
          order_id?: string
          paid_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_payments_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          advance: number
          created_at: string
          customer_id: string | null
          customer_name: string | null
          customer_phone: string | null
          delivery_date: string | null
          discount_type: string | null
          discount_value: number
          id: string
          notes: string | null
          order_date: string
          order_no: string
          order_type: string
          payment_mode: string | null
          shop_owner_id: string
          split_payment: boolean
          status: string
          updated_at: string
        }
        Insert: {
          advance?: number
          created_at?: string
          customer_id?: string | null
          customer_name?: string | null
          customer_phone?: string | null
          delivery_date?: string | null
          discount_type?: string | null
          discount_value?: number
          id: string
          notes?: string | null
          order_date: string
          order_no: string
          order_type: string
          payment_mode?: string | null
          shop_owner_id: string
          split_payment?: boolean
          status?: string
          updated_at?: string
        }
        Update: {
          advance?: number
          created_at?: string
          customer_id?: string | null
          customer_name?: string | null
          customer_phone?: string | null
          delivery_date?: string | null
          discount_type?: string | null
          discount_value?: number
          id?: string
          notes?: string | null
          order_date?: string
          order_no?: string
          order_type?: string
          payment_mode?: string | null
          shop_owner_id?: string
          split_payment?: boolean
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "orders_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_shop_owner_id_fkey"
            columns: ["shop_owner_id"]
            isOneToOne: false
            referencedRelation: "shop_data"
            referencedColumns: ["user_id"]
          },
        ]
      }
      product_restocks: {
        Row: {
          created_at: string
          id: string
          note: string | null
          product_id: string
          qty: number
          restocked_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          note?: string | null
          product_id: string
          qty?: number
          restocked_at: string
        }
        Update: {
          created_at?: string
          id?: string
          note?: string | null
          product_id?: string
          qty?: number
          restocked_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_restocks_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          active: boolean
          category: string
          cost_price: number
          created_at: string
          customization: string | null
          gst_rate: number | null
          hsn_code: string | null
          id: string
          name: string
          opening_stock: number
          reorder_level: number
          selling_price: number
          shop_owner_id: string
          size: string | null
          sku: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          category: string
          cost_price?: number
          created_at?: string
          customization?: string | null
          gst_rate?: number | null
          hsn_code?: string | null
          id: string
          name: string
          opening_stock?: number
          reorder_level?: number
          selling_price?: number
          shop_owner_id: string
          size?: string | null
          sku: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          category?: string
          cost_price?: number
          created_at?: string
          customization?: string | null
          gst_rate?: number | null
          hsn_code?: string | null
          id?: string
          name?: string
          opening_stock?: number
          reorder_level?: number
          selling_price?: number
          shop_owner_id?: string
          size?: string | null
          sku?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "products_shop_owner_id_fkey"
            columns: ["shop_owner_id"]
            isOneToOne: false
            referencedRelation: "shop_data"
            referencedColumns: ["user_id"]
          },
        ]
      }
      shop_data: {
        Row: {
          created_at: string
          customers: Json
          expenses: Json
          orders: Json
          products: Json
          settings: Json
          suppliers: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          customers?: Json
          expenses?: Json
          orders?: Json
          products?: Json
          settings?: Json
          suppliers?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          customers?: Json
          expenses?: Json
          orders?: Json
          products?: Json
          settings?: Json
          suppliers?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      platform_admins: {
        Row: {
          claimed_at: string
          email: string
          user_id: string | null
        }
        Insert: {
          claimed_at?: string
          email: string
          user_id?: string | null
        }
        Update: {
          claimed_at?: string
          email?: string
          user_id?: string | null
        }
        Relationships: []
      }
      platform_invites: {
        Row: {
          blocked: boolean
          email: string
          id: string
          invited_at: string
          note: string | null
        }
        Insert: {
          blocked?: boolean
          email: string
          id?: string
          invited_at?: string
          note?: string | null
        }
        Update: {
          blocked?: boolean
          email?: string
          id?: string
          invited_at?: string
          note?: string | null
        }
        Relationships: []
      }
      shop_members: {
        Row: {
          id: string
          invited_at: string
          invited_email: string
          joined_at: string | null
          member_user_id: string | null
          role: string
          shop_owner_id: string
        }
        Insert: {
          id?: string
          invited_at?: string
          invited_email: string
          joined_at?: string | null
          member_user_id?: string | null
          role?: string
          shop_owner_id: string
        }
        Update: {
          id?: string
          invited_at?: string
          invited_email?: string
          joined_at?: string | null
          member_user_id?: string | null
          role?: string
          shop_owner_id?: string
        }
        Relationships: []
      }
      suppliers: {
        Row: {
          address: string | null
          created_at: string
          id: string
          name: string
          notes: string | null
          phone: string | null
          shop_owner_id: string
          supplies: string | null
          updated_at: string
        }
        Insert: {
          address?: string | null
          created_at?: string
          id: string
          name: string
          notes?: string | null
          phone?: string | null
          shop_owner_id: string
          supplies?: string | null
          updated_at?: string
        }
        Update: {
          address?: string | null
          created_at?: string
          id?: string
          name?: string
          notes?: string | null
          phone?: string | null
          shop_owner_id?: string
          supplies?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "suppliers_shop_owner_id_fkey"
            columns: ["shop_owner_id"]
            isOneToOne: false
            referencedRelation: "shop_data"
            referencedColumns: ["user_id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      claim_platform_admin: { Args: Record<string, never>; Returns: boolean }
      email_can_join: { Args: { check_email: string }; Returns: boolean }
      financial_year_short: { Args: { _d: string }; Returns: string }
      is_platform_admin: { Args: Record<string, never>; Returns: boolean }
      platform_admin_report: { Args: Record<string, never>; Returns: Json }
      platform_has_seller: { Args: Record<string, never>; Returns: boolean }
      set_platform_invite_blocked: {
        Args: { invite_id: string; is_blocked: boolean }
        Returns: undefined
      }
      is_shop_member: { Args: { _shop_owner_id: string }; Returns: boolean }
      next_order_no: {
        Args: { _order_date: string; _shop_owner_id: string }
        Returns: string
      }
      save_order: {
        Args: {
          _assign_order_no?: boolean
          _items: Json
          _order: Json
          _payments: Json
          _shop_owner_id: string
        }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
