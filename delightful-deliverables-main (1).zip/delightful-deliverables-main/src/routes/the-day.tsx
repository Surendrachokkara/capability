import { createFileRoute } from "@tanstack/react-router";
import { DayPage } from "@/components/site/DayPage";

export const Route = createFileRoute("/the-day")({
  head: () => ({
    meta: [
      { title: "A day in the shop — Frame & Gifts" },
      {
        name: "description",
        content: "Check orders. Take payment. Send WhatsApp. Count cash, UPI, and card.",
      },
      { property: "og:title", content: "A day in the shop — Frame & Gifts" },
      {
        property: "og:description",
        content: "Five things to do each day. Then open the shop.",
      },
    ],
  }),
  component: DayPage,
});
