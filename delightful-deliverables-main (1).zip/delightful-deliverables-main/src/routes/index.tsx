import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/components/site/HomePage";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Frame & Gifts — Run your shop in one place" },
      {
        name: "description",
        content: "Add items. Save the order. See who still has to pay. Open the shop.",
      },
      { property: "og:title", content: "Frame & Gifts — Run your shop in one place" },
      {
        property: "og:description",
        content: "Add items. Save the order. See who still has to pay.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
});
