import { createFileRoute } from "@tanstack/react-router";
import ShopApp from "@/components/shop/ShopApp";

export const Route = createFileRoute("/app")({
  head: () => ({
    meta: [
      { title: "Frame & Gifts Shop Manager — Stock, Orders & Accounts" },
      {
        name: "description",
        content:
          "Run your frame and gift shop: track stock, orders, customers, payments and expenses in one simple dashboard.",
      },
      { property: "og:title", content: "Frame & Gifts Shop Manager" },
      {
        property: "og:description",
        content:
          "Track stock, orders, customers, payments and expenses for your frame and gift shop.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ShopApp,
});
