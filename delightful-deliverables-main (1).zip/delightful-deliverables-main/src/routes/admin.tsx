import { createFileRoute } from "@tanstack/react-router";
import { AdminPage } from "@/components/site/AdminPage";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Invite shops — Frame & Gifts" },
      {
        name: "description",
        content: "Add the emails that can open a shop.",
      },
      { property: "og:title", content: "Invite shops — Frame & Gifts" },
      {
        property: "og:description",
        content: "Add the emails that can open a shop.",
      },
    ],
  }),
  component: AdminPage,
});
