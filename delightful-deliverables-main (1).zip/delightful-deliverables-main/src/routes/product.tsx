import { createFileRoute } from "@tanstack/react-router";
import { ProductPage } from "@/components/site/ProductPage";

export const Route = createFileRoute("/product")({
  head: () => ({
    meta: [
      { title: "How it works — Frame & Gifts" },
      {
        name: "description",
        content: "Add stock. Save the order. Send WhatsApp. Then open the shop.",
      },
      { property: "og:title", content: "How it works — Frame & Gifts" },
      {
        property: "og:description",
        content: "Add stock. Save the order. Send WhatsApp.",
      },
    ],
  }),
  component: ProductPage,
});
