# Shop Manager — Implementation Roadmap

Approved plan: implement all Necessary & Required items plus Nice-to-Haves from `.lovable/plan.md`.

## Phase 1 — Relational foundation (DONE)
- [x] Design normalized tables: products, customers, suppliers, expenses, orders, order_items, order_payments, product_restocks
- [x] Migrate existing `shop_data` JSONB rows into the new tables
- [x] RLS policies so owners and joined staff keep access
- [x] Security linter clean (no warnings)
- [x] Supabase types regenerated; TypeScript check passes
- [x] App preview still loads with no console errors

## Phase 2 — App integration (DONE)
- [x] `shopRepo` maps the app's arrays to/from the relational tables (RLS-scoped client reads/writes)
- [x] ShopApp reads and writes products, customers, expenses, orders, order items, payments and restocks as rows
- [x] Per-record writes: only changed rows are upserted, removed rows deleted, child rows rewritten only when changed
- [x] Live sync subscribes to the new tables with coalesced refreshes
- [x] `shop_data.settings` remains the shop profile source; JSONB lists kept as a backup for now

## Phase 3 — Integrity (DONE)
- [x] DB-level value constraints (no negative money/stock, quantities of at least 1, percentage discounts capped, names/phones not blank)
- [x] Per-shop order-number counter table so numbers can never collide
- [x] `save_order` database operation: order + items + payments written all-or-nothing, number allocated server-side
- [x] Zod schemas (`shopSchemas.ts`) checked in every form handler and again in `shopRepo` before any write

## Phase 4 — Scale (DONE)
- [x] Paged reads in `shopRepo` (1000-row pages, chunked child lookups) so no records are lost past the first thousand
- [x] Incremental list rendering (50 at a time with "Show more") on stock, orders, customers and expenses
- [ ] Computed views for low-stock, outstanding balances, profit summaries (deferred — current totals compute fine client-side)

## Phase 5 — Operations (DONE)
- [x] Offline write queue with background sync (per-record diffs, auto-flush on reconnect)
- [x] Role-based access: staff can't delete records, change shop settings, manage the team, or see cost prices / profit
- [x] Atomic invoice / bill numbering series per shop (done in Phase 3)
- [x] Printable receipts (already in the app; GST tax invoices out of scope)

## Phase 6 — Polish (Nice-to-Haves)
- [ ] Complete Hindi & Telugu translations
- [x] Bulk CSV/Excel import with preview (products + customers, matched on SKU / phone)
- [x] Owner-held full backup download (.json, paged full read) + restore (merge / replace) + last-backup reminder + header sync status
- [ ] Customer payment reminder drafts (WhatsApp/SMS)
- [ ] Profit & loss per product / customer reports
- [ ] Low-stock alerts and reorder points
- [ ] Keyboard shortcuts
- [ ] Product photo resize/compress on upload
- [ ] Date-range filtering on reports
- [ ] Dashboard summary customization
- [x] Startup speed: local session read, single shop-lookup request, one-wave data load with embedded order lines/payments/restocks, live sync waits for your own saves, team list loads only in Settings
- [x] Startup speed: app split into separate downloads — opening only loads the dashboard; stock, orders, customers, finance and every dialog load the first time they're opened

- [x] Typing/lag pass: search text moved into each list (no whole-app re-render per keystroke) + useDeferredValue filtering; optimistic add/restock/order-customer saves
- [x] Light/dark appearance modes with device persistence and organized section-based Settings screen
- [x] Responsive Settings pass: purpose-built phone navigation and organized layouts for every section
- [x] Clean profile access: one header profile button opens all Settings; language and sign out moved inside
